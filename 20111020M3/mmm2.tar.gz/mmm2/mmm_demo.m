
%% MMM Demo

%% Set directory 
global base
base = [pwd '/'];
addpath([base 'functions']);
addpath([base 'data']);

%% First Method (finite mixture model)

%% Initial values.

file = ['500_SNP_raw_intensity' ];
cut = 0.85;       % cutoff of the posterior probability.
rq  = 0.5;        % initial value of boundary of clusters.
rr = 100000;      
err = 0.00001;

%% First step.

[idx, callrate, idxs] = mmm_step11(file, cut, rq, rr,err);


%% Second Step.

file = ['500_SNP_raw_intensity'];
file1 = ['500_snp_allele'];

step  = 100;                   % the size of reference SNPs.
bei   = ceil(size(idx,1)*0.20);% the sample size of each cluster for the reference SNPs.
cut   = 0.85;                  % cutoff of the posterior probability.
rq    = 0.5;                   % initial value of boundary of clusters.
calrat1 = 0.95;                % lower bound of APR for the reference SNPs. 
calrat2 = 0.99999;             % upper bound of APR for the reference SNPs.
mmaf    = 0.05;                % the minor allele frequency.
APR     = 0.9;                 % the average posterior rate.
err   = 0.00001;

[cc, idxs]= mmm_step22(file, file1, idx, callrate, idxs, step, bei, cut, rq, err, calrat1, calrat2, mmaf, APR);


 % cc is the final genotype file.

