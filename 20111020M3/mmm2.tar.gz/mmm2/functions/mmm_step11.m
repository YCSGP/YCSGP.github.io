function [idx, callrate, idxs]= mmm_step11(file, cut, rq, rr,err)
         cut=cut; rq=rq;
         rr = rr; tt = err; 
         nname0 = [file,'.txt'] ;
         yy=textread(nname0);
         idx=zeros(size(yy,1),size(yy,2)/2);
         idxs=zeros(size(yy,1),size(yy,2)/2);
         callrate=zeros(size(yy,2)/2,1);
         ii=0; 
         
for jj = (1:2:size(yy,2))
    ii = ii+1
    X_log=yy(:,jj:(jj+1));
    options = statset('Display','final','MaxIter',500);
    ind_zero1 = find(X_log(:,1) == 0);
    ind_zero2 = find(X_log(:,2) == 0);
    ind_zero  = union(ind_zero1,ind_zero2);
    ind_nzero = setdiff(1:size(X_log,1),ind_zero');
    X=X_log(ind_nzero,:);
    
    % Initial values for log intensity
    contrast = (X(:,1)-X(:,2))./(X(:,1)+X(:,2));
    strenth = log(X(:,1)+X(:,2));
    con1 = find(contrast < -rq) ;
    con2 = find(contrast < rq & contrast >= -rq) ;
    con3 = find(contrast >= rq) ;

    mu1 = mean((X(con1,1)-X(con1,2))./(X(con1,1)+X(con1,2)));
    mu2 = mean((X(con2,1)-X(con2,2))./(X(con2,1)+X(con2,2)));
    mu3 = mean((X(con3,1)-X(con3,2))./(X(con3,1)+X(con3,2)));    

    maxg = rq; ming = -rq;
    if size(con1,1) > 3 && size(con2,1) > 3 && size(con3,1) > 3,
          maxg = mu2+(mu3-mu2)/2;
          ming = mu2-(mu2-mu1)/2;
          con1 = find(contrast < ming) ;
          con2 = find(contrast < maxg & contrast >= ming) ;
          con3 = find(contrast >= maxg) ;
    end
    if size(con1,1) >= 15 && size(con2,1) >= 15 && isempty(con3),
       maxg = (mu1+(mu2-mu1)/2);
       ming = maxg;
       con1 = find(contrast < ming) ;
       con2 = find(contrast >= ming) ;
    end
    if size(con1,1) < 15 && size(con1,1) > 0 && size(con2,1) >= 15 && isempty(con3),
       maxg = -1;
       ming = maxg;
       con1 = find(contrast < ming) ;
       con2 = find(contrast >= ming) ;
    end
    if size(con1,1) >= 15 && size(con2,1) < 15 && size(con2,1) > 0 && isempty(con3),
       maxg = -0.25;
       ming = maxg;
       con1 = find(contrast < ming) ;
       con2 = find(contrast >= ming) ;
    end
   
    if size(con1,1) >= 15 && size(con3,1) >= 15 && isempty(con2),
       maxg = mu1+(mu3-mu1)/2;
       ming = maxg;
       con1 = find(contrast < ming) ;
       con3 = find(contrast >= ming) ;
    end
    if size(con1,1) < 15 && size(con1,1) > 0 && size(con3,1) >= 15 && isempty(con2),
       maxg = mu1+(mu3-mu1)/2;
       ming = maxg;
       con3 = find(contrast >= ming) ;
       con1 = find(contrast < ming) ;
    end
    if size(con1,1) >= 15 && size(con3,1) < 15 && size(con3,1) > 0 && isempty(con2),
       maxg = mu1+(mu3-mu1)/2;
       ming = maxg;
       con1 = find(contrast < ming) ;
       con3 = find(contrast >= ming) ;
    end
    
    if size(con2,1) >= 15 && size(con3,1) >= 15 && isempty(con1),
       maxg = mu2+(mu3-mu2)/2;
       ming = maxg;
       con3 = find(contrast >= ming) ;
       con2 = find(contrast < ming) ;
    end
    if size(con2,1) < 15 && size(con2,1) > 0 && size(con3,1) >= 15 && isempty(con1),
       maxg = 0.25;
       ming = maxg;
       con3 = find(contrast >= ming) ;
       con2 = find(contrast < ming) ;
    end
    if size(con2,1) >= 15 && size(con3,1) < 15 && size(con3,1) > 0 && isempty(con1),
       maxg = rq*2;
       ming = maxg;
       con3 = find(contrast >= ming) ;
       con2 = find(contrast < ming) ;
    end
    if size(con1,1) > 0 && isempty(con2) && isempty(con3),
       maxg = rq;
       ming = -rq;
       con1 = find(contrast < ming) ;
       con2 = find(contrast < maxg & contrast >= ming) ;
       con3 = find(contrast >= maxg) ;
    end    
    if size(con2,1) > 0 && isempty(con1) && isempty(con3),
       maxg = rq;
       ming = -rq;
       con1 = find(contrast < ming) ;
       con2 = find(contrast < maxg & contrast >= ming) ;
       con3 = find(contrast >= maxg) ;
    end   
    if size(con3,1) > 0 && isempty(con1) && isempty(con2),
       maxg = rq;
       ming = -rq;
       con1 = find(contrast < ming) ;
       con2 = find(contrast < maxg & contrast >= ming) ;
       con3 = find(contrast >= maxg) ;
    end   
    
    %figure(1)
    %strenth = log(X(:,1)+X(:,2));
    %scatter(X_log(:,1), X_log(:,2),10, 'g*');
    %vline(mu2+(mu3-mu2)/2);
    %vline(mu2-(mu2-mu1)/2); 
    
    tot  = length(con1)+length(con2)+length(con3);
    p1 = length(con1)/tot;
    p2 = length(con2)/tot;
    p3 = length(con3)/tot;
      
    if p1 > 0 && p2 > 0 && p3 > 0
        ini.PComponents = [p1,p2,p3]; 
        ini.mu = zeros(3,2); ini.Sigma=zeros(2,2,3);
        ini.mu(1,:) = [mean(X(con1,1)),mean(X(con1,2))];
        ini.mu(2,:) = [mean(X(con2,1)),mean(X(con2,2))];
        ini.mu(3,:) = [mean(X(con3,1)),mean(X(con3,2))];
        if length(con1) > 1 
           ini.Sigma(:,:,1) = cov(X(con1,1),X(con1,2));
        else ini.Sigma(:,:,1) = eye(2,2);
        end;    
    
        if length(con2) > 1
           ini.Sigma(:,:,2) = cov(X(con2,1),X(con2,2));
        else ini.Sigma(:,:,2) = eye(2,2);
        end;    
    
        if length(con3) > 1 
           ini.Sigma(:,:,3) = cov(X(con3,1),X(con3,2));
        else ini.Sigma(:,:,3) = eye(2,2);
        end;
        k=3;
        e1=eig(ini.Sigma(:,:,1)); 
        e2=eig(ini.Sigma(:,:,2));
        e3=eig(ini.Sigma(:,:,3));
        if e1(1,:) < tt || e1(2,:) < tt 
           ini.Sigma(:,:,1)=cholupdate(ini.Sigma(:,:,1),(ini.mu(1,:)/sqrt(rr))')'*cholupdate(ini.Sigma(:,:,1),(ini.mu(1,:)/sqrt(rr))');
        end
        if e2(1,:) < tt || e2(2,:) < tt
           ini.Sigma(:,:,2)=cholupdate(ini.Sigma(:,:,2),(ini.mu(2,:)/sqrt(rr))')'*cholupdate(ini.Sigma(:,:,2),(ini.mu(2,:)/sqrt(rr))');
        end
        if e3(1,:) < tt || e3(2,:) < tt
           ini.Sigma(:,:,3)=cholupdate(ini.Sigma(:,:,3),(ini.mu(3,:)/sqrt(rr))')'*cholupdate(ini.Sigma(:,:,3),(ini.mu(3,:)/sqrt(rr))');
        end
            
    end
    
    if p3 == 0 && p1 > 0 && p2 > 0,
        ini.PComponents = [p1,p2];
        ini.mu = zeros(2,2); ini.Sigma=zeros(2,2,2);
        ini.mu(1,:) = [mean(X(con1,1)),mean(X(con1,2))];
        ini.mu(2,:) = [mean(X(con2,1)),mean(X(con2,2))];
        if length(con1) > 1
           ini.Sigma(:,:,1) = cov(X(con1,1),X(con1,2));
        else ini.Sigma(:,:,1) = eye(2,2);
        end    
    
        if length(con2) > 1 
           ini.Sigma(:,:,2) = cov(X(con2,1),X(con2,2));
        else ini.Sigma(:,:,2) = eye(2,2);
        end;
        k=2; 
        e1=eig(ini.Sigma(:,:,1)); 
        e2=eig(ini.Sigma(:,:,2));
        if e1(1,:) < tt || e1(2,:) < tt
           ini.Sigma(:,:,1)=cholupdate(ini.Sigma(:,:,1),(ini.mu(1,:)/sqrt(rr))')'*cholupdate(ini.Sigma(:,:,1),(ini.mu(1,:)/sqrt(rr))');
        end
        if e2(1,:) < tt || e2(2,:) < tt
           ini.Sigma(:,:,2)=cholupdate(ini.Sigma(:,:,2),(ini.mu(2,:)/sqrt(rr))')'*cholupdate(ini.Sigma(:,:,2),(ini.mu(2,:)/sqrt(rr))');
        end
    end;

    if p2 == 0 && p1 > 0 && p3 > 0,
        ini.PComponents = [p1,p3];
        ini.mu = zeros(2,2); ini.Sigma=zeros(2,2,2);
        ini.mu(1,:) = [mean(X(con1,1)),mean(X(con1,2))];
        ini.mu(2,:) = [mean(X(con3,1)),mean(X(con3,2))];
        if length(con1) > 1
           ini.Sigma(:,:,1) = cov(X(con1,1),X(con1,2));
        else ini.Sigma(:,:,1) = eye(2,2);
        end    
    
        if length(con3) > 1 
           ini.Sigma(:,:,2) = cov(X(con3,1),X(con3,2));
        else ini.Sigma(:,:,2) = eye(2,2);
        end;
        k=2; 
        e1=eig(ini.Sigma(:,:,1)); 
        e2=eig(ini.Sigma(:,:,2));
        if e1(1,:) < tt || e1(2,:) < tt
           ini.Sigma(:,:,1)=cholupdate(ini.Sigma(:,:,1),(ini.mu(1,:)/sqrt(rr))')'*cholupdate(ini.Sigma(:,:,1),(ini.mu(1,:)/sqrt(rr))');
        end
        if e2(1,:) < tt || e2(2,:) < tt
           ini.Sigma(:,:,2)=cholupdate(ini.Sigma(:,:,2),(ini.mu(2,:)/sqrt(rr))')'*cholupdate(ini.Sigma(:,:,2),(ini.mu(2,:)/sqrt(rr))');
        end
    end;

    if p1 == 0 && p2 > 0 && p3 > 0,
        ini.PComponents = [p3,p2];
        ini.mu = zeros(2,2); ini.Sigma=zeros(2,2,2);
        ini.mu(1,:) = [mean(X(con3,1)),mean(X(con3,2))];
        ini.mu(2,:) = [mean(X(con2,1)),mean(X(con2,2))];
        if length(con3) > 1
           ini.Sigma(:,:,1) = cov(X(con3,1),X(con3,2));
        else ini.Sigma(:,:,1) = eye(2,2);
        end    
    
        if length(con2) > 1 
           ini.Sigma(:,:,2) = cov(X(con2,1),X(con2,2));
        else ini.Sigma(:,:,2) = eye(2,2);
        end;
        k=2; 
        e1=eig(ini.Sigma(:,:,1)); 
        e2=eig(ini.Sigma(:,:,2));
        if e1(1,:) < tt || e1(2,:) < tt
           ini.Sigma(:,:,1)=cholupdate(ini.Sigma(:,:,1),(ini.mu(1,:)/sqrt(rr))')'*cholupdate(ini.Sigma(:,:,1),(ini.mu(1,:)/sqrt(rr))');
        end
        if e2(1,:) < tt || e2(2,:) < tt
           ini.Sigma(:,:,2)=cholupdate(ini.Sigma(:,:,2),(ini.mu(2,:)/sqrt(rr))')'*cholupdate(ini.Sigma(:,:,2),(ini.mu(2,:)/sqrt(rr))');
        end
    end;
    
    if p2 == 0 && p3 == 0 && p1 > 0,
        ini.PComponents = p1;
        ini.mu = zeros(1,2); ini.Sigma=zeros(2,2,1);
        ini.mu(1,:) = [mean(X(con1,1)),mean(X(con1,2))];
        if length(con1) > 1 
           ini.Sigma(:,:,1) = cov(X(con1,1),X(con1,2));
        else ini.Sigma(:,:,1) = eye(2,2);
        end    
        k=1; 
        e1=eig(ini.Sigma(:,:,1)); 
        if e1(1,:) < tt || e1(2,:) < tt
           ini.Sigma(:,:,1) = cholupdate(ini.Sigma,(ini.mu/sqrt(rr))')'*cholupdate(ini.Sigma,(ini.mu/sqrt(rr))');
        end
    end;

    if p1 == 0 && p3 == 0 && p2 > 0,
        ini.PComponents = p2;
        ini.mu = zeros(1,2); ini.Sigma=zeros(2,2,1);
        ini.mu(1,:) = [mean(X(con2,1)),mean(X(con2,2))];
        if length(con1) > 1 
           ini.Sigma(:,:,1) = cov(X(con2,1),X(con2,2));
        else ini.Sigma(:,:,1) = eye(2,2);
        end    
        k=1; 
        e1=eig(ini.Sigma(:,:,1)); 
        if e1(1,:) < tt || e1(2,:) < tt
           ini.Sigma(:,:,1) = cholupdate(ini.Sigma,(ini.mu/sqrt(rr))')'*cholupdate(ini.Sigma,(ini.mu/sqrt(rr))');
        end
    end;
    
    if p1 == 0 && p2 == 0 && p3 > 0,
        ini.PComponents = p3;
        ini.mu = zeros(1,2); ini.Sigma=zeros(2,2,1);
        ini.mu(1,:) = [mean(X(con3,1)),mean(X(con3,2))];
        if length(con1) > 1 
           ini.Sigma(:,:,1) = cov(X(con3,1),X(con3,2));
        else ini.Sigma(:,:,1) = eye(2,2);
        end    
        k=1; 
        e1=eig(ini.Sigma(:,:,1)); 
        if e1(1,:) < tt || e1(2,:) < tt
           ini.Sigma(:,:,1) = cholupdate(ini.Sigma,(ini.mu/sqrt(rr))')'*cholupdate(ini.Sigma,(ini.mu/sqrt(rr))');
        end
    end;
    
    S = struct('PComponents',ini.PComponents,'mu',ini.mu,'Sigma',ini.Sigma);

    %%  test
    if k > 1,
         gm = gmdistribution.fit(X,k,'Regularize',1e-4,'Replicates',1,'Start',S,'Options',options);
    else gm = gmdistribution.fit(X,k,'Regularize',1e-4,'Replicates',20,'Options',options);
    end
    
    %% assigning cluster
       P=zeros(size(yy,1),k);
       idx(ind_nzero,ii) = cluster(gm,X);
       idx(ind_zero,ii) = -9; 
       k = size(tabulate(idx(ind_nzero,ii)),1);
       cluster1 = 0; cluster2 = 0; cluster3 = 0; 
       cluster1 = find(idx(:,ii) == 1);
       cluster2 = find(idx(:,ii) == 2);
       cluster3 = find(idx(:,ii) == 3);
       P(ind_nzero,:) = posterior(gm,X);
    
    if k == 3
       r = zeros(k,1);
       if ~isempty(cluster1)
          r(1,1) = sum(P(cluster1,1))/length(cluster1);
       end
       if ~isempty(cluster2)
          r(2,1) = sum(P(cluster2,2))/length(cluster2);
       end
       if ~isempty(cluster3)
          r(3,1) = sum(P(cluster3,3))/length(cluster3);
       end
    end

    if k == 2
       r = zeros(k,1);
       if ~isempty(cluster1)
          r(1,1) = sum(P(cluster1,1))/length(cluster1);
       end
       if ~isempty(cluster2)
          r(2,1) = sum(P(cluster2,2))/length(cluster2);
       end

    end
    if k == 1
       r = zeros(k,1);
       if ~isempty(cluster1)
          r(1,1) = sum(P(cluster1,1))/length(cluster1);
       end
    end
        callrate(ii) = sum(r)/k;

    % assigning genotype to snps
         tab=tabulate(idx(ind_nzero,ii));
         if k == 3,
            if tab(1,2) > tab(3,2),
               idxs(cluster1,ii) = 0;
               idxs(cluster3,ii) = 2;
            else idxs(cluster1,ii) = 2;
                 idxs(cluster3,ii) = 0;
            end
            idxs(cluster2,ii) = 1;
         end
         if  k==2,
             if tab(1,2) > tab(2,2),
                 idxs(cluster1,ii) = 0;
                 idxs(cluster2,ii) = 1;
             else idxs(cluster1,ii) = 1;
                  idxs(cluster2,ii) = 0;
             end
         end
         if k == 1,
              idxs(ind_nzero,ii) = 0;
         end
        
    cutoff = cut;
    if k == 3
       cc1 = find(P(:,1)> cutoff);
       cc2 = find(P(:,2)> cutoff);
       cc3 = find(P(:,3)> cutoff);
       idx(setdiff(cluster1,cc1),ii) = -9;
       idx(setdiff(cluster2,cc2),ii) = -9;
       idx(setdiff(cluster3,cc3),ii) = -9;
       idxs(setdiff(cluster1,cc1),ii) = -9;
       idxs(setdiff(cluster2,cc2),ii) = -9;
       idxs(setdiff(cluster3,cc3),ii) = -9;
    end;
    
    if k == 2
    cc1 = find(P(:,1)> cutoff);
    cc2 = find(P(:,2)> cutoff);
    idx(setdiff(cluster1,cc1),ii) = -9;
    idx(setdiff(cluster2,cc2),ii) = -9;
    idxs(setdiff(cluster1,cc1),ii) = -9;
    idxs(setdiff(cluster2,cc2),ii) = -9;
    end;
    
    if k == 1
    cc1 = find(P(:,1)> cutoff);
    idx(setdiff(cluster1,cc1),ii) = -9;
    idxs(setdiff(cluster1,cc1),ii) = -9;
    end;
    
    
end

end
 


 