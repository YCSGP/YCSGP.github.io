fid=fopen('Output.txt','w');
for i=1:size(cc,1)
    fprintf(fid, cc(i,:));
    fprintf(fid,'\n');
end
fclose(fid);

