########################################################
# GAM correction with an arbitrary number of PC, or minimal
# number of PC explaining 95% variance in X 
# calling group_fitting
########################################################
gampc<-function(ymat, xmat1, xmat2, num.pc=NULL){
 require(gam)
 ymat <- data.frame(ymat)
 xmat1 <- data.frame(xmat1) # X that does not need PC
 xmat2 <- data.frame(xmat2) # X that needs PC
 
 pcaX <- prcomp(xmat2, scale=TRUE, center=TRUE)
 
  if (is.null(num.pc)){
    pcs <- which(cumsum((pcaX$sdev)^2)/(length(pcaX$sdev)) < .95)
    num.pc <- max(which(cumsum((pcaX$sdev)^2)/(length(pcaX$sdev)) < .95)) + 1 
      
  }#is.null(num.pc)
  
  toRegX <- data.frame(xmat1, pcaX$x[,1:num.pc])
 
  
  for (rep in 1:dim(ymat)[2]){
  
   pcmat <- cbind(ymat[,rep], toRegX)
   
   formu <- "pcmat[,1]~ s(pcmat[,2])"
   
   for (i in 3:dim(pcmat)[2]){ 
    formu <- paste(formu, "+ s(pcmat[,", toString(i)  ,"]) ", sep="") 
   }
   
   m2 <- gam( as.formula(formu) )
   
ymat[,rep] <- mean(pcmat[,1]) + m2$residuals
   
  } #for rep
 
 ;
 return(ymat)
} 




#########################################
# group bias factors into bins, and make a bias plot
# calling function plotk
#########################################
group_plot <- function(mat, minval = NULL, maxval = NULL, type="median", grpn=500, spec = -1, titleon=TRUE){

#input a matrix of 19 columns, first column is the log(FPKM), 2nd to 19th column is bias factors
#output a bias plot for the FPKM ratio for each bin
#if type="median", will plot bias vs. median of each bin

  a <- NULL
  if (spec == -1){
    par(mfrow=c(3,6), mar=c(2,2,2,2))
    for (k in 2:dim(mat)[2]){#plot for each bias factor
    
    tmp <- plotk(mat[,k], mat[,1], minval, maxval, type, grpn)
    
    if (titleon) {title(main=colnames(mat)[k])}
    
    a <- cbind(a,tmp) 
  }
  }else{
  
    a <- plotk(mat[,spec], mat[,1], minval, maxval, type, grpn)
    
    if (titleon) {title(main=colnames(mat)[k])}
  }
  ;
  data.frame(a)
}

############################################
# cut bias factors into bins and make a plot
############################################
plotk <- function(x, y, minval, maxval, type, grpn=500){

# x is a vector which you make a partition (e.g., gene length)
# y is a vector which you want to plot on y-axis (e.g., transcript expression)
# foo is a function to summarize y-values in each bin

       ord <- order(x)
       n.bins <- floor(length(y)/grpn)

        ind <- rep(1:n.bins, each = grpn)
        ind <- c(ind, rep(n.bins+1, length(y) - length(ind))) # add in last bin
        
        res <- list("index"  = 1:(length(unique(ind))), "xvalues" = tapply(x[ord], INDEX = ind, FUN = median),
                       "yvalues" = tapply(y[ord], INDEX = ind, FUN = median))

        if (type == "bin"){
        
        plot(res$index, res$yvalues,ylim=c(minval, maxval), cex=0.5)
        lines(lowess(res$index, res$yvalues))
        
        ;
  return(cbind(res$index, res$yvalues))
        
        }else if (type=="median"){
        
        plot(res$xvalues, res$yvalues,ylim=c(minval, maxval), cex=0.5)
        lines(lowess(res$xvalues, res$yvalues))
        
        ;
  return(cbind(res$xvalues, res$yvalues))
        }
        
}

############################################################
# make overlapping group plots to compare
# the matrices are output from group_plot function
############################################################
group_plotm <- function(toCmp, minval = NULL, maxval = NULL, titl=rep("not specified", 18)){

    nmat <- length(toCmp) #toCmp is a list of group_plot objects to compare
    mat1 <- data.frame(toCmp[1])
    
    par(mfrow=c(3,6), mar=c(2,2,2,2))
    
    for (k in 1:18){#plot for each bias factor
    
        plot(mat1[,(2*k-1)], mat1[,(2*k)], ylim=c(minval, maxval), pch=19, cex=0.5, cex.axis=1.2)
        lines(lowess(mat1[,(2*k-1)], mat1[,(2*k)]), lwd=2)
        
        if ( nmat >1 ){
        
         for (j in 2:nmat){
         mat2 <- data.frame(toCmp[j])
         
         points(mat2[,(2*k-1)], mat2[,(2*k)], pch=19, cex=0.5, col=j)
         lines(lowess(mat2[,(2*k-1)], mat2[,(2*k)]), col=j, lwd=2)
         }
        }
        title(list(titl[k], cex=1.5))
    
    }#end of for
}

###############################
### check agreement between RTPCR data and seq data
### input a dataframe with col 1: RTPCR result, col 2: uncorrected seq data, col 3: corrected seq data
### output the correlation matrix for improvement in each quantile
###############################
check_agreement <- function(checkdat, grpn=3, cor.method="pearson"){
 checkdat <- data.frame(checkdat)
 fc.cor <- checkdat[,3] - checkdat[,2]

 require(gtools)
 fcbin <- quantcut(abs(fc.cor),seq(0,1,by=1/grpn)) 
 cormat <- matrix(0, grpn, 2)

 for (k in 1:grpn){
   l <- levels(fcbin)[k]
   cormat[k,1]<- round(cor(checkdat[fcbin==l,1], checkdat[fcbin==l,2], method = cor.method),3) #uncorrected cor 
   cormat[k,2]<- round(cor(checkdat[fcbin==l,1], checkdat[fcbin==l,3], method = cor.method),3)  #corrected
 }
 
 imp <- round((cormat[,2]-cormat[,1])*100/cormat[,1],1)
 cormat <- cbind(cormat, imp)
 cor1<- round(cor(checkdat[,1], checkdat[,2], method = cor.method),3) #uncorrected
 cor2<- round(cor(checkdat[,1], checkdat[,3], method = cor.method),3)  #corrected
 cor.imp<- round((cor2-cor1)*100/cor1,1)
 cormat <-rbind(cormat,c(cor1, cor2, cor.imp))
 colnames(cormat) <- c("Uncorrected", "Corrected", "%Improvement")
 rownames(cormat) <- c(levels(fcbin), "Overall")
 ;
 cormat
 }

#################################################################
## prime_reweight_counts is a fucntion to calculate counts from bam files
## write necessary info in an input file with two columns:
## 1. label: identifier of each sample
## 2. bam: path to the bam file corresponding to each sample
## the function will match the bam file to given annotation and chrMap,
## collect counts and reweighted counts in a list to return
###################################################################

prime.reweight.counts <- function(infile, annotation, chrMap, group_fac){

require(ShortRead)
require(Genominator)

n <- dim(infile)[1]
allreads <- list(n)

 for (i in 1:n){
 allreads[[i]] <- readAligned(as.character(infile[i, 2]), type="BAM")
 }

names(allreads) <- as.character(infile[,1])

### annotation must have chr, start, end field

###################################################
### computePrimingWeights
###################################################
weightsList <- lapply(allreads, computePrimingWeights)

###################################################
### addPrimingWeights
###################################################
reads2 <- mapply(addPrimingWeights, allreads, weightsList)

###################################################
### importWithWeights
###################################################
dataO <- importFromAlignedReads(allreads, chrMap = chrMap, dbFilename = tempfile(), tablename = "raw")
dataW <- importFromAlignedReads(reads2, chrMap = chrMap, dbFilename = tempfile(), tablename = "raw")

###################################################
### reweightedCounts
###################################################
Counts <- summarizeByAnnotation(dataO, annotation, ignoreStrand = TRUE, groupBy = group_fac)
reweightedCounts <- summarizeByAnnotation(dataW, annotation, ignoreStrand = TRUE, groupBy = group_fac)
colnames(reweightedCounts) <- paste(colnames(reweightedCounts), "_RW", sep="")
allCounts <- data.frame(Counts, reweightedCounts)

## convert counts to RPKM
trExp <- apply(allCounts * 10^9, 1, `/`, colSums(allCounts)) #multiply by 10^9, divide by total number of reads
colnames(trExp) <- rownames(allCounts)
exonl <- (annotation$end - annotation$start + 1)
transl <- ave(exonl, annotation[, match(group_fac, colnames(annotation))], FUN = sum)
transl <- data.frame(annotation[, match(group_fac, colnames(annotation))], transl)
transl <- unique(transl)

trExp <- apply(trExp, 1, `/`, transl[match(colnames(trExp), transl[,1]), 2]) #divide by length
colnames(trExp) <- colnames(allCounts)

list(allCounts, trExp)

}

