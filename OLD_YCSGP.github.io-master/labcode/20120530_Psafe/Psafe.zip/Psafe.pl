#!/usr/bin/perl -w

# Author: Xiaowei Chen @ Yale Univ.

use strict;
use Getopt::Std;
#use Getopt::Long;
use List::Util qw(first max maxstr min minstr reduce shuffle sum);

&main;
exit;

sub main {
  &usage if (@ARGV < 1);
  my $command = shift(@ARGV);
  my %func = (rawpilese=>\&rawpilese, rawpilepe=>\&rawpilepe, rawpilepeV2=>\&rawpilepeV2, 
  			  unipilese=>\&unipilese, unipilepe=>\&unipilepe,
              mlecount=>\&mlecount, refbias=>\&refbias);
  die("Unknown command \"$command\".\n") if (!defined($func{$command}));
  &{$func{$command}};
}

sub rawpilese{
  my %opts = (t=>'none');
  getopts('t:',\%opts);
  
  die(qq/
  Usage: Psafe.pl rawpilese [options] <path of Psafe> <in.sam> <out.txt>\n
  Options:	-t Sorted non-overlapping target region file <FORMAT: chr start end>\n 
  Note: in.sam has to be sorted.\n\n/) if (@ARGV != 3 && -t STDIN);
  my($dir, $filein, $fileout) = @ARGV;
  
  $dir =~ s/\/$//;
  my (@ascs, %asc, %reasc, $char, $dec, $oct, $hex, %qcs, @sangers, $sanger);
  my ($line, @info, $length, %H, @sets, $m, $n, $flag, $tarout);
  my (@nts, @qs, @poss, %pileups, $prechr);
  my ($cov, $nt, $q, $pos, @sorted_pos, $readpos, $i, $count, $num);
  my (@infotar, %snps, $prepos, $ccmm);
  
  if($opts{t} ne 'none') {$tarout = $fileout; $fileout ="$tarout.temp";}

  open(ASC, "$dir/resource/ASCIItable.txt") || die "cannot find ASCII table\n";

  $line = <ASC>;
  $line = <ASC>;
  while( !eof(ASC) ) {
    $line = <ASC>;
    $line =~ s/\s+$//; # trim the newline.
    chomp $line;

    @ascs = split(/\|/, $line);
    for($i=0; $i<=3; $i++) {
      ($char, $dec, $oct, $hex) = split(/ /, $ascs[$i]);
      $asc{$char} = $dec;
      $reasc{$dec} = $char;
    }
  }
  close ASC;
  
  %H = (
         "1" => "the read is paired in sequencing",
         "2" => "the read is mapped in a proper pair",
         "3" => "the query sequence itself is unmapped",
         "4" => "the mate is unmapped",
         "5" => "strand of the query (1 for reverse)",
         "6" => "strand of the mate",
         "7" => "the read is the first read in a pair",
         "8" => "the read is the second read in a pair",
         "9" => "the alignment is not primary",
         "10" => "QC failure",
         "11" => "optical or PCR duplicate",
         );

  open (IN, "$filein") || die "cannot open $filein\n";
  open (OUT, ">$fileout") || die "cannot generate $fileout\n";

  $prechr = 'startpile';
  %pileups = ();
  $count=0;
  while(!eof(IN)) {
    $line = <IN>;
    $line =~ s/\s+$//; # trim the newline.
    chomp $line;
    if($line =~ m/^\@/) {next;}

    @info = split(/\t/, $line);
    $flag = $info[1];
    $m=1;
    for ($n=0; $n<11; $n++) {
      $sets[$n] = ($flag & $m);
      $m <<= 1;
    }

    if($sets[2] != 0) {next;}  # not mapped.
    @nts = split(//, $info[9]);
    $length = scalar (@nts);
    if($info[5] ne $length.'M') {next;} # clipped reads. 
    $info[9] =~ tr/[a-z]/[A-Z]/;
  
    if($prechr ne $info[2])  {
      @sorted_pos = sort {$a <=> $b} ( keys %pileups );
      foreach $pos (@sorted_pos) {
        $cov = scalar @{$pileups{$pos}{nts}};
        $nt = join('', @{$pileups{$pos}{nts}});
        $q = join('', @{$pileups{$pos}{qs}});
        $readpos = join(',', @{$pileups{$pos}{pos}});
        print OUT "$prechr	$pos	$cov	$nt	$q	$readpos\n";
      }

      %pileups = ();
      $prechr = $info[2];
      $count=0;
      print "pile up $prechr...\n";
    }

    if($count==30000)  {
      @sorted_pos = sort {$a <=> $b} ( keys %pileups );
      $num = scalar @sorted_pos;
      for($i=0; $i<$num-$length-2; $i++) {
        $pos = $sorted_pos[$i];
        $cov = scalar @{$pileups{$pos}{nts}};
        $nt = join('', @{$pileups{$pos}{nts}});
        $q = join('', @{$pileups{$pos}{qs}});
        $readpos = join(',', @{$pileups{$pos}{pos}});
        print OUT "$prechr	$pos	$cov	$nt	$q	$readpos\n";
        delete $pileups{$pos};
      }

      $count=0;
    }

    $count++;
    @nts = split(//, $info[9]);
    @qs = split(//, $info[10]);
    if($sets[4] == 0) { # plus
      for($i=0; $i<scalar @nts; $i++) {
        push(@{$pileups{$info[3]+$i}{nts}}, $nts[$i]);
        push(@{$pileups{$info[3]+$i}{qs}}, $qs[$i]);
        push(@{$pileups{$info[3]+$i}{pos}}, $i+1);

      }
    }

    if($sets[4] != 0) { # minus
      $info[9] =~ tr/[A-Z]/[a-z]/; # minus strand is lower letter.
      @nts = split(//, $info[9]);

      for($i=0; $i<scalar @nts; $i++) {
        push(@{$pileups{$info[3]+$i}{nts}}, $nts[$i]);
        push(@{$pileups{$info[3]+$i}{qs}}, $qs[$i]);
        push(@{$pileups{$info[3]+$i}{pos}}, $length-$i);
      }
    }


  }

  @sorted_pos = sort {$a <=> $b} ( keys %pileups );
  foreach $pos (@sorted_pos) {
      $cov = scalar @{$pileups{$pos}{nts}};
      $nt = join('', @{$pileups{$pos}{nts}});
      $q = join('', @{$pileups{$pos}{qs}});
      $readpos = join(',', @{$pileups{$pos}{pos}});

      print OUT "$prechr	$pos	$cov	$nt	$q	$readpos\n";
  }

  close IN;
  close OUT;

  if($opts{t} eq 'none') {exit;}
  print "...\nExtract pileup in target regions...\ntarget region is $opts{t}\n";

  %snps = ();
  open (TAR, "$opts{t}") || die "cannot open target region file\n";
  while(!eof(TAR)) {
    $line = <TAR>;
    $line =~ s/\s+$//; # trim the newline.
    chomp $line;
  
    @infotar = split(/\t/, $line);
    $snps{$infotar[0]}{$infotar[1]}{start}=1;
    $snps{$infotar[0]}{$infotar[2]}{end}=1;
  }
  close TAR;
  
  $flag=0;

  $count=0;
  $prechr = 'startchr';
  $prepos = 0;
  $ccmm=0;
  
  open (IN, "$fileout") || die "cannot open $fileout\n";

  open (OUT, ">$tarout") || die "cannot generate $tarout\n";

  while(!eof(IN)) {
    $line = <IN>;
    $line =~ s/\s+$//; # trim the newline.
    chomp $line;
    @info = split(/\t/, $line);

    if($prechr ne $info[0])  {
      $prechr = $info[0];
      if(!exists($snps{$prechr})) {delete $snps{$prechr}; $prechr = "startchr"; next;}

      @sorted_pos = sort {$a <=> $b} ( keys %{$snps{$prechr}} ); 
      $i=0;  
      $prepos = $sorted_pos[0];
      print "Start $prechr...\n";
    }

    while($i+1 <= scalar @sorted_pos && $info[1] > $sorted_pos[$i+1]) {$i=$i+2;}
    if($i+1 <= scalar @sorted_pos && $snps{$prechr}{$sorted_pos[$i+1]}{end}!=1) {print "Error: $line\n Error: not end ... $prechr	$sorted_pos[$i+1]\n";exit;}
    if($i+1 <= scalar @sorted_pos && $info[1] >= $sorted_pos[$i] && $info[1]<=$sorted_pos[$i+1]) {print OUT "$line\n"; $count++;}
    if($i+1 <= scalar @sorted_pos && $info[1] < $sorted_pos[$i]) {next;}
  }
  close IN;
  close OUT;

  unlink("$fileout");

}

sub rawpilepe{
  my %opts = (t=>'none');
  getopts('t:',\%opts);
  
  die(qq/
  Usage: Psafe.pl rawpilese [options] <path of Psafe> <in.sam> <out.txt>\n
  Options:	-t Sorted non-overlapping target region file <FORMAT: chr start end>\n 
  Note: in.sam has to be sorted.
        clipped mapping is removed in the pileup step.(require both ends mapped without clipping)\n\n/) if (@ARGV != 3 && -t STDIN);
  my($dir, $filein, $fileout) = @ARGV; 
  
  $dir =~ s/\/$//;

  my (@info, $length, %H, @sets, $m, $n, $flag, $tarout);
  my (@nts, @qs, @poss, %pileups, $prechr, %goods);
  my (@ascs, %asc, %reasc, $char, $dec, $oct, $hex, %qcs, @sangers, $sanger);
  my ($cov, $nt, $q, $pos, @sorted_pos, $readpos, $i, $line, $count, $num, $readpos2);
  my (@infotar, %snps, $prepos, $ccmm);
  
  if($opts{t} ne 'none') {$tarout = $fileout; $fileout ="$tarout.temp";}

  # read ASCII table and build char to dec and dec to char hashes.
  open(ASC, "/$dir/resource/ASCIItable.txt") || die "cannot find ASCII table\n";

  $line = <ASC>;
  $line = <ASC>;
  while( !eof(ASC) ) {
    $line = <ASC>;
    $line =~ s/\s+$//; # trim the newline.
    chomp $line;

    @ascs = split(/\|/, $line);
    for($i=0; $i<=3; $i++) {
      ($char, $dec, $oct, $hex) = split(/ /, $ascs[$i]);
      $asc{$char} = $dec;
      $reasc{$dec} = $char;
    }
  }
  close ASC;
  
  %H = (
         "1" => "the read is paired in sequencing",
         "2" => "the read is mapped in a proper pair",
         "3" => "the query sequence itself is unmapped",
         "4" => "the mate is unmapped",
         "5" => "strand of the query (1 for reverse)",
         "6" => "strand of the mate",
         "7" => "the read is the first read in a pair",
         "8" => "the read is the second read in a pair",
         "9" => "the alignment is not primary",
         "10" => "QC failure",
         "11" => "optical or PCR duplicate",
         );

  open (IN, "$filein") || die "cannot open $filein\n";

  $prechr = 'startpile';

  %goods = ();
  print "Get paired end mapping information...\n";
  while(!eof(IN)) {
    $line = <IN>;
    $line =~ s/\s+$//; # trim the newline.
    chomp $line;
    if($line =~ m/^\@/) {next;}

    @info = split(/\t/, $line);
    $flag = $info[1];
    $m=1;
    for ($n=0; $n<11; $n++) {
      $sets[$n] = ($flag & $m);
      $m <<= 1;
    }
    if($sets[2] != 0) {next;}  # not mapped.
    @nts = split(//, $info[9]);
    $length = scalar @nts;
    if($info[5] ne $length.'M') {next;} # soft clipping.

    $goods{$info[0]}++;
  }
  close IN;

  open (IN, "$filein") || die "cannot open $filein\n";
  open (OUT, ">$fileout") || die "cannot generate $fileout\n";

  print "start pileup...\n";
  %pileups = ();
  $count=0;
  while(!eof(IN)) {
    $line = <IN>;
    $line =~ s/\s+$//; # trim the newline.
    chomp $line;
    if($line =~ m/^\@/) {next;}

    @info = split(/\t/, $line);
    $flag = $info[1];
    $m=1;
    for ($n=0; $n<11; $n++) {
      $sets[$n] = ($flag & $m);
      $m <<= 1;
    }
    if($sets[2] != 0) {next;}  # not mapped.
    @nts = split(//, $info[9]);
    $length = scalar @nts;
    if($info[5] ne $length.'M') {next;} # clipped.  
    if($goods{$info[0]} != 2) {next;} # Not both ends mapped withouto clipping.

    if($prechr ne $info[2])  {
      @sorted_pos = sort {$a <=> $b} ( keys %pileups );
      foreach $pos (@sorted_pos) {
        $cov = scalar @{$pileups{$pos}{nts}};
        $nt = join('', @{$pileups{$pos}{nts}});
        $q = join('', @{$pileups{$pos}{qs}});
        $readpos = join(',', @{$pileups{$pos}{pos}});
        $readpos2 = join(',', @{$pileups{$pos}{pos2}});
        print OUT "$prechr	$pos	$cov	$nt	$q	$readpos	$readpos2\n";

      }

      %pileups = ();
      $prechr = $info[2];
      $count=0;
      print "pile up $prechr...\n";
    }

    if($count==30000)  {
      @sorted_pos = sort {$a <=> $b} ( keys %pileups );
      $num = scalar @sorted_pos;
      for($i=0; $i<$num-$length-2; $i++) {
        $pos = $sorted_pos[$i];
        $cov = scalar @{$pileups{$pos}{nts}};
        $nt = join('', @{$pileups{$pos}{nts}});
        $q = join('', @{$pileups{$pos}{qs}});
        $readpos = join(',', @{$pileups{$pos}{pos}});
        $readpos2 = join(',', @{$pileups{$pos}{pos2}});

        print OUT "$prechr	$pos	$cov	$nt	$q	$readpos	$readpos2\n";
        delete $pileups{$pos}; # some positions remain.
      }

      $count=0;
    }

    $count++;
    @nts = split(//, $info[9]);
    @qs = split(//, $info[10]);
    if($sets[4] == 0) { # plus
      for($i=0; $i<scalar @nts; $i++) {
        push(@{$pileups{$info[3]+$i}{nts}}, $nts[$i]);
        push(@{$pileups{$info[3]+$i}{qs}}, $qs[$i]);
        push(@{$pileups{$info[3]+$i}{pos}}, $i+1);
        push(@{$pileups{$info[3]+$i}{pos2}}, $info[7]);
      }
    }

    if($sets[4] != 0) { # minus
      $info[9] =~ tr/[A-Z]/[a-z]/; # minus strand is lower letter.
      @nts = split(//, $info[9]);

      for($i=0; $i<scalar @nts; $i++) {
        push(@{$pileups{$info[3]+$i}{nts}}, $nts[$i]);
        push(@{$pileups{$info[3]+$i}{qs}}, $qs[$i]);
        push(@{$pileups{$info[3]+$i}{pos}}, $length-$i);
        push(@{$pileups{$info[3]+$i}{pos2}}, $info[7]);
      }
    }
       
  }

  @sorted_pos = sort {$a <=> $b} ( keys %pileups );
  foreach $pos (@sorted_pos) {
      $cov = scalar @{$pileups{$pos}{nts}};
      $nt = join('', @{$pileups{$pos}{nts}});
      $q = join('', @{$pileups{$pos}{qs}});
      $readpos = join(',', @{$pileups{$pos}{pos}});
      $readpos2 = join(',', @{$pileups{$pos}{pos2}});

      print OUT "$prechr	$pos	$cov	$nt	$q	$readpos	$readpos2\n";
  }

  close IN;
  close OUT;
  
  if($opts{t} eq 'none') {exit;}
  print "...\nExtract pileup in target regions...\ntarget region is $opts{t}\n";
  %snps = ();
  open (TAR, "$opts{t}") || die "cannot open target region file\n";
  while(!eof(TAR)) {
    $line = <TAR>;
    $line =~ s/\s+$//; # trim the newline.
    chomp $line;
  
    @infotar = split(/\t/, $line);
    $snps{$infotar[0]}{$infotar[1]}{start}=1;
    $snps{$infotar[0]}{$infotar[2]}{end}=1;
  }
  close TAR;
  
  $flag=0;

  $count=0;
  $prechr = 'startchr';
  $prepos = 0;
  $ccmm=0;
  @sorted_pos = ();
  open (IN, "$fileout") || die "cannot open $fileout\n";

  open (OUT, ">$tarout") || die "cannot generate $tarout\n";

  while(!eof(IN)) {
    $line = <IN>;
    $line =~ s/\s+$//; # trim the newline.
    chomp $line;
    @info = split(/\t/, $line);

    if($prechr ne $info[0])  {
      $prechr = $info[0];

      if(!exists($snps{$prechr})) {delete $snps{$prechr}; $prechr = "startchr"; next;}
      @sorted_pos = sort {$a <=> $b} ( keys %{$snps{$prechr}} ); 
      $i=0;  
      $prepos = $sorted_pos[0];
      print "Start $prechr...\n";
    }

    while($i+1 <= scalar @sorted_pos && $info[1] > $sorted_pos[$i+1]) {$i=$i+2;}
    if($i+1 <= scalar @sorted_pos && $snps{$prechr}{$sorted_pos[$i+1]}{end}!=1) {print "Error: $line\nError: not end ... $prechr	$sorted_pos[$i+1]\n";exit;}
    if($i+1 <= scalar @sorted_pos && $info[1] >= $sorted_pos[$i] && $info[1]<=$sorted_pos[$i+1]) {print OUT "$line\n"; $count++;}
    if($i+1 <= scalar @sorted_pos && $info[1] < $sorted_pos[$i]) {next;}
  }
  close IN;
  close OUT;

  unlink("$fileout");
}

sub rawpilepeV2{
  my %opts = (t=>'none');
  getopts('t:',\%opts);
  
  die(qq/
  Usage: Psafe.pl rawpilepeV2 [options] <path of Psafe> <in.sam> <out.txt>\n
  Options:	-t Sorted non-overlapping target region file <FORMAT: chr start end>\n 
  Note: in.sam has to be sorted.
        Clipped mapping is removed in the pileup step.\n\n/) if (@ARGV != 3 && -t STDIN);
  my($dir, $filein, $fileout) = @ARGV; 
  
  $dir =~ s/\/$//;

  my (@info, $length, %H, @sets, $m, $n, $flag, $tarout);
  my (@nts, @qs, @poss, %pileups, $prechr, %goods);
  my (@ascs, %asc, %reasc, $char, $dec, $oct, $hex, %qcs, @sangers, $sanger);
  my ($cov, $nt, $q, $pos, @sorted_pos, $readpos, $i, $line, $count, $num, $readpos2);
  my (@infotar, %snps, $prepos, $ccmm);
  
  if($opts{t} ne 'none') {$tarout = $fileout; $fileout ="$tarout.temp";}

  # read ASCII table and build char to dec and dec to char hashes.
  open(ASC, "/$dir/resource/ASCIItable.txt") || die "cannot find ASCII table\n";

  $line = <ASC>;
  $line = <ASC>;
  while( !eof(ASC) ) {
    $line = <ASC>;
    $line =~ s/\s+$//; # trim the newline.
    chomp $line;

    @ascs = split(/\|/, $line);
    for($i=0; $i<=3; $i++) {
      ($char, $dec, $oct, $hex) = split(/ /, $ascs[$i]);
      $asc{$char} = $dec;
      $reasc{$dec} = $char;
    }
  }
  close ASC;
  
  %H = (
         "1" => "the read is paired in sequencing",
         "2" => "the read is mapped in a proper pair",
         "3" => "the query sequence itself is unmapped",
         "4" => "the mate is unmapped",
         "5" => "strand of the query (1 for reverse)",
         "6" => "strand of the mate",
         "7" => "the read is the first read in a pair",
         "8" => "the read is the second read in a pair",
         "9" => "the alignment is not primary",
         "10" => "QC failure",
         "11" => "optical or PCR duplicate",
         );

  open (IN, "$filein") || die "cannot open $filein\n";

  $prechr = 'startpile';

  open (IN, "$filein") || die "cannot open $filein\n";
  open (OUT, ">$fileout") || die "cannot generate $fileout\n";

  print "start pileup...\n";
  %pileups = ();
  $count=0;
  while(!eof(IN)) {
    $line = <IN>;
    $line =~ s/\s+$//; # trim the newline.
    chomp $line;
    if($line =~ m/^\@/) {next;}

    @info = split(/\t/, $line);
    $flag = $info[1];
    $m=1;
    for ($n=0; $n<11; $n++) {
      $sets[$n] = ($flag & $m);
      $m <<= 1;
    }
    if($sets[2] != 0) {next;}  # not mapped.
    @nts = split(//, $info[9]);
    $length = scalar @nts;
    if($info[5] ne $length.'M') {next;} # clipped.  
    if($sets[1] ==0 ) {next;} # Not both ends mapped.

    if($prechr ne $info[2])  {
      @sorted_pos = sort {$a <=> $b} ( keys %pileups );
      foreach $pos (@sorted_pos) {
        $cov = scalar @{$pileups{$pos}{nts}};
        $nt = join('', @{$pileups{$pos}{nts}});
        $q = join('', @{$pileups{$pos}{qs}});
        $readpos = join(',', @{$pileups{$pos}{pos}});
        $readpos2 = join(',', @{$pileups{$pos}{pos2}});
        print OUT "$prechr	$pos	$cov	$nt	$q	$readpos	$readpos2\n";

      }

      %pileups = ();
      $prechr = $info[2];
      $count=0;
      print "pile up $prechr...\n";
    }

    if($count==30000)  {
      @sorted_pos = sort {$a <=> $b} ( keys %pileups );
      $num = scalar @sorted_pos;
      for($i=0; $i<$num-$length-2; $i++) {
        $pos = $sorted_pos[$i];
        $cov = scalar @{$pileups{$pos}{nts}};
        $nt = join('', @{$pileups{$pos}{nts}});
        $q = join('', @{$pileups{$pos}{qs}});
        $readpos = join(',', @{$pileups{$pos}{pos}});
        $readpos2 = join(',', @{$pileups{$pos}{pos2}});

        print OUT "$prechr	$pos	$cov	$nt	$q	$readpos	$readpos2\n";
        delete $pileups{$pos}; # some positions remain.
      }

      $count=0;
    }

    $count++;
    @nts = split(//, $info[9]);
    @qs = split(//, $info[10]);
    if($sets[4] == 0) { # plus
      for($i=0; $i<scalar @nts; $i++) {
        push(@{$pileups{$info[3]+$i}{nts}}, $nts[$i]);
        push(@{$pileups{$info[3]+$i}{qs}}, $qs[$i]);
        push(@{$pileups{$info[3]+$i}{pos}}, $i+1);
        push(@{$pileups{$info[3]+$i}{pos2}}, $info[7]);
      }
    }

    if($sets[4] != 0) { # minus
      $info[9] =~ tr/[A-Z]/[a-z]/; # minus strand is lower letter.
      @nts = split(//, $info[9]);

      for($i=0; $i<scalar @nts; $i++) {
        push(@{$pileups{$info[3]+$i}{nts}}, $nts[$i]);
        push(@{$pileups{$info[3]+$i}{qs}}, $qs[$i]);
        push(@{$pileups{$info[3]+$i}{pos}}, $length-$i);
        push(@{$pileups{$info[3]+$i}{pos2}}, $info[7]);
      }
    }
       
  }

  @sorted_pos = sort {$a <=> $b} ( keys %pileups );
  foreach $pos (@sorted_pos) {
      $cov = scalar @{$pileups{$pos}{nts}};
      $nt = join('', @{$pileups{$pos}{nts}});
      $q = join('', @{$pileups{$pos}{qs}});
      $readpos = join(',', @{$pileups{$pos}{pos}});
      $readpos2 = join(',', @{$pileups{$pos}{pos2}});

      print OUT "$prechr	$pos	$cov	$nt	$q	$readpos	$readpos2\n";
  }

  close IN;
  close OUT;
  
  if($opts{t} eq 'none') {exit;}
  print "...\nExtract pileup in target regions...\ntarget region is $opts{t}\n";
  %snps = ();
  open (TAR, "$opts{t}") || die "cannot open target region file\n";
  while(!eof(TAR)) {
    $line = <TAR>;
    $line =~ s/\s+$//; # trim the newline.
    chomp $line;
  
    @infotar = split(/\t/, $line);
    $snps{$infotar[0]}{$infotar[1]}{start}=1;
    $snps{$infotar[0]}{$infotar[2]}{end}=1;
  }
  close TAR;
  
  $flag=0;

  $count=0;
  $prechr = 'startchr';
  $prepos = 0;
  $ccmm=0;
  @sorted_pos = ();
  open (IN, "$fileout") || die "cannot open $fileout\n";

  open (OUT, ">$tarout") || die "cannot generate $tarout\n";

  while(!eof(IN)) {
    $line = <IN>;
    $line =~ s/\s+$//; # trim the newline.
    chomp $line;
    @info = split(/\t/, $line);

    if($prechr ne $info[0])  {
      $prechr = $info[0];

      if(!exists($snps{$prechr})) {delete $snps{$prechr}; $prechr = "startchr"; next;}
      @sorted_pos = sort {$a <=> $b} ( keys %{$snps{$prechr}} ); 
      $i=0;  
      $prepos = $sorted_pos[0];
      print "Start $prechr...\n";
    }

    while($i+1 <= scalar @sorted_pos && $info[1] > $sorted_pos[$i+1]) {$i=$i+2;}
    if($i+1 <= scalar @sorted_pos && $snps{$prechr}{$sorted_pos[$i+1]}{end}!=1) {print "Error: $line\nError: not end ... $prechr	$sorted_pos[$i+1]\n";exit;}
    if($i+1 <= scalar @sorted_pos && $info[1] >= $sorted_pos[$i] && $info[1]<=$sorted_pos[$i+1]) {print OUT "$line\n"; $count++;}
    if($i+1 <= scalar @sorted_pos && $info[1] < $sorted_pos[$i]) {next;}
  }
  close IN;
  close OUT;

  unlink("$fileout");
}

sub unipilese{
  die(qq/
  Usage: Psafe.pl unipilese <path of Psafe> <in.rawpileup> <out.txt>\n\n/) if (@ARGV != 3);
  my($dir, $filein, $fileout) = @ARGV; 
  
  my ($foldername, $line, @info, %piles, @temp1, @temp2, @nts, $i, $nt, $qs, $pos, @qss, @poss, $j, $cov, @geno);
  my (@ascs, %asc, %reasc, $char, $dec, $oct, $hex, %qcs, @sangers, $sanger);
  $dir =~ s/\/$//;

  # read ASCII table and build char to dec and dec to char hashes.
  open(ASC, "/$dir/resource/ASCIItable.txt") || die "cannot find ASCII table\n";

  $line = <ASC>;
  $line = <ASC>;
  while( !eof(ASC) ) {
    $line = <ASC>;
    $line =~ s/\s+$//; # trim the newline.
    chomp $line;

    @ascs = split(/\|/, $line);
    for($i=0; $i<=3; $i++) {
      ($char, $dec, $oct, $hex) = split(/ /, $ascs[$i]);
      $asc{$char} = $dec;
      $reasc{$dec} = $char;
    }
  }
  close ASC;
  
  open (IN, "$filein") || die "cannot open $filein\n";
  open (OUT, ">$fileout") || die "cannot generate $fileout\n";
  while(!eof(IN)) {
    $line = <IN>;
    $line =~ s/\s+$//; # trim the newline.
    chomp $line;

    @info = split(/\t/, $line);
    print OUT "$info[0]	$info[1]	";
    @nts = split(//, $info[3]);
    @qss = split(//, $info[4]);
    @poss = split(/,/, $info[5]);
    %piles =();

    for($i=0; $i<scalar @nts; $i++) {
      push(@{$piles{$nts[$i]}{$poss[$i]}}, $asc{$qss[$i]});
    }
    @nts=();
    @qss=();
    @poss=();
    @temp1 = keys %piles;
    for($i=0; $i<scalar @temp1; $i++) {
      @temp2 = keys %{$piles{$temp1[$i]}};
      for($j=0; $j<scalar @temp2; $j++) {
        push(@nts, $temp1[$i]);
        push(@poss, $temp2[$j]);
        $qs = $reasc{mymedian(@{$piles{$temp1[$i]}{$temp2[$j]}})};
        push(@qss, $qs);
      }
    }

    $nt = join('', @nts);
    $qs = join('', @qss);
    $pos = join(',', @poss);
    $cov = scalar @nts;
    print OUT "$cov	$nt	$qs	$pos\n";
  }
  close OUT;
  close IN;

}


sub unipilepe{
  die(qq/
  Usage: Psafe.pl unipilepe <path of Psafe> <in.rawpileup> <out.txt>\n\n/) if (@ARGV != 3);
  my($dir, $filein, $fileout) = @ARGV; 
  
  my (@poss2, $line, @info, %piles, @temp1, @temp2, @nts, $i, $nt, $qs, $pos, $pos2, @qss, @temp3, $k, @poss, $j, $cov, @geno);
  my (@ascs, %asc, %reasc, $char, $dec, $oct, $hex, %qcs, @sangers, $sanger);
  $dir =~ s/\/$//;

  # read ASCII table and build char to dec and dec to char hashes.
  open(ASC, "/$dir/resource/ASCIItable.txt") || die "cannot find ASCII table\n";

  $line = <ASC>;
  $line = <ASC>;
  while( !eof(ASC) ) {
    $line = <ASC>;
    $line =~ s/\s+$//; # trim the newline.
    chomp $line;

    @ascs = split(/\|/, $line);
    for($i=0; $i<=3; $i++) {
      ($char, $dec, $oct, $hex) = split(/ /, $ascs[$i]);
      $asc{$char} = $dec;
      $reasc{$dec} = $char;
    }
  }
  close ASC;

  open (IN, "$filein") || die "cannot open 2\n";
  open (OUT, ">$fileout") || die "cannot open 2\n";
  while(!eof(IN)) {
    $line = <IN>;
    $line =~ s/\s+$//; # trim the newline.
    chomp $line;

    @info = split(/\t/, $line);
    print OUT "$info[0]	$info[1]	";
    @nts = split(//, $info[3]);
    @qss = split(//, $info[4]);
    @poss = split(/,/, $info[5]);
    @poss2 = split(/,/, $info[6]);

    %piles =();
    for($i=0; $i<scalar @nts; $i++) {
      push(@{$piles{$nts[$i]}{$poss[$i]}{$poss2[$i]}}, $asc{$qss[$i]});
    }
    @nts=();
    @qss=();
    @poss=();
    @poss2=();
    @temp1 = keys %piles;
    for($i=0; $i<scalar @temp1; $i++) {
      @temp2 = keys %{$piles{$temp1[$i]}};
      for($j=0; $j<scalar @temp2; $j++) {
        @temp3 = keys %{$piles{$temp1[$i]}{$temp2[$j]}};

        for($k=0; $k<scalar @temp3; $k++) {
          push(@nts, $temp1[$i]);
          push(@poss, $temp2[$j]);
          push(@poss2, $temp3[$k]);
          $qs = $reasc{mymedian(@{$piles{$temp1[$i]}{$temp2[$j]}{$temp3[$k]}})};
          push(@qss, $qs);
        }
      }
    }

    $nt = join('', @nts);
    $qs = join('', @qss);
    $pos = join(',', @poss);
    $pos2 = join(',', @poss2);
    $cov = scalar @nts;
    print OUT "$cov	$nt	$qs	$pos	$pos2\n";
  }
  close OUT;
  close IN;

}

sub mlecount {
  my %opts = (p=>0.1, c=>5, a=>0, n=>10, k=>0.1);
  getopts('p:c:a:n:k:',\%opts);

  die(qq/
  Usage: Psafe.pl mlecount [options] <path of Psafe> <in.pileup> <out.txt> <number of individuals in one pool>\n\n
  Options:	-p The sites with lowest quality scores more than a certain percentage(p: 0-1) are not fully subjected to mle (default 0.5)\n
		-c Coverage for lowest quality scores not subjected to mle(default 5)\n
		-a quality score cutoff(default 0). If 0, disable this function.
		-n coverage for -q of each individual(dafault 10)
		-k percentage for quality score -q(default 0.1)\n/) if (@ARGV != 4  && -t STDIN);
  my($dir, $filein, $fileout, $indnum) = @ARGV; 
  
  my ($line, $i, $j, @info, $error, @bqs, $count, $maxc, $cutoff);
  my ($oritotal, @sorted, @unsorted);
  my (@ascs, %asc, %reasc, $char, $dec, $oct, $hex, %qcs, @sangers, $sanger);
  my ($base, $nea, $nec, $net, $neg, @bases, @bqa, @bqc, @bqt, @bqg, $pre, $flag, $num, $numpass);
  my (%chrs, $chr, $pre1, $indel);
  my ($errora, $errort, $errorc, $errorg, $low);
  
  $dir =~ s/\/$//;

  # read ASCII table and build char to dec and dec to char hashes.
  open(ASC, "/$dir/resource/ASCIItable.txt") || die "cannot find ASCII table\n";

  $line = <ASC>;
  $line = <ASC>;
  while( !eof(ASC) ) {
    $line = <ASC>;
    $line =~ s/\s+$//; # trim the newline.
    chomp $line;

    @ascs = split(/\|/, $line);
    for($i=0; $i<=3; $i++) {
      ($char, $dec, $oct, $hex) = split(/ /, $ascs[$i]);
      $asc{$char} = $dec;
      $reasc{$dec} = $char;
    }
  }
  close ASC;
  
  $maxc=0;
  open (IN, "$filein") || die "cannot open $filein\n";
  while(!eof(IN)) {
    $line = <IN>;
    $line =~ s/\s+$//; # trim the newline.
    chomp $line;
 
    @info = split(/\t/, $line);
    $info[3] =~ tr/[a-z]/[A-Z]/;
    @bases = split(//, $info[3]);
    $nea = grep(/A/, @bases); 
    $net = grep(/T/, @bases);
    $nec = grep(/C/, @bases);
    $neg = grep(/G/, @bases);
    @bases= sort($nea, $net, $nec, $neg);
    #if($bases[2]==0) {next;} ## at least two nts.
    if($info[2]>$maxc ) {$maxc  = $info[2]; }

  }
  close IN;

  $num=0;
  $numpass=0;
  open (IN, "$filein") || die "cannot open $filein\n";
  open (OUT, ">$dir/tempmle.txt" ) || die "cannot generate tempmle file\n";
  open (TOUT, ">$dir/tempnotcallset.txt") || die "cannot generate notcallset temp file\n";
  open (QOUT, ">$dir/tempquacallset.txt") || die "cannot generate notcallset temp file\n";

  while(!eof(IN)) {
    $line = <IN>;
    $line =~ s/\s+$//; # trim the newline.
    chomp $line;

    @info = split(/\t/, $line);
    
    $info[3] =~ tr/[a-z]/[A-Z]/;
    @bases = split(//, $info[3]);
    @bqs = split(//, $info[4]);
    $low = grep(/#/, @bqs);
    $oritotal = scalar @bases;

    $nea = 0;
    $nec = 0;
    $net = 0;
    $neg = 0;
    @bqa = ();
    @bqt = ();
    @bqc = ();
    @bqg = ();
    $nea = grep(/A/, @bases); 
    $net = grep(/T/, @bases);
    $nec = grep(/C/, @bases);
    $neg = grep(/G/, @bases);
    @unsorted = ($nea, $net, $nec, $neg);
    @sorted = sort { $a <=> $b } @unsorted;
    $nea = 0;
    $nec = 0;
    $net = 0;
    $neg = 0;
    @bqa = ();
    @bqt = ();
    @bqc = ();
    @bqg = ();

    if($sorted[2]>($indnum*$opts{n}) && ($sorted[2]/($sorted[2]+$sorted[3]))>$opts{k}) {
      for($i=0; $i<scalar @bases; $i++) {
        if($bqs[$i] eq '#') {next;}
        if(($bases[$i] eq 'A' || $bases[$i] eq 'a') && ($asc{$bqs[$i]}-33)<=$opts{a}) {$nea++; splice(@bases, $i, 1); splice(@bqs, $i, 1);$i--;}
        elsif(($bases[$i] eq 'T' || $bases[$i] eq 't') && ($asc{$bqs[$i]}-33)<=$opts{a}) {$net++; splice(@bases, $i,1); splice(@bqs, $i,1);$i--;}
        elsif(($bases[$i] eq 'C' || $bases[$i] eq 'c') && ($asc{$bqs[$i]}-33)<=$opts{a}) {$nec++; splice(@bases, $i, 1); splice(@bqs, $i, 1);$i--;}
        elsif(($bases[$i] eq 'G' || $bases[$i] eq 'g') && ($asc{$bqs[$i]}-33)<=$opts{a}) {$neg++; splice(@bases, $i, 1); splice(@bqs, $i, 1);$i--;}
      }
      print QOUT "$info[0]	$info[1]	$oritotal	$nea	$net	$nec	$neg\n";
    }
    else {
      print QOUT "$info[0]	$info[1]	$oritotal	0	0	0	0\n";
    }
    
    $nea = 0;
    $nec = 0;
    $net = 0;
    $neg = 0;
    @bqa = ();
    @bqt = ();
    @bqc = ();
    @bqg = ();
    if($low/$oritotal>=$opts{p} && $low>=$opts{c}) {
      for($i=0; $i<scalar @bases; $i++) {
        if(($bases[$i] eq 'A' || $bases[$i] eq 'a') && $bqs[$i] eq '#') {$nea++; splice(@bases, $i, 1); splice(@bqs, $i, 1);$i--;}
        elsif(($bases[$i] eq 'T' || $bases[$i] eq 't') && $bqs[$i] eq '#') {$net++; splice(@bases, $i,1); splice(@bqs, $i,1);$i--;}
        elsif(($bases[$i] eq 'C' || $bases[$i] eq 'c') && $bqs[$i] eq '#') {$nec++; splice(@bases, $i, 1); splice(@bqs, $i, 1);$i--;}
        elsif(($bases[$i] eq 'G' || $bases[$i] eq 'g') && $bqs[$i] eq '#') {$neg++; splice(@bases, $i, 1); splice(@bqs, $i, 1);$i--;}
      }
      print TOUT "$info[0]	$info[1]	$oritotal	$nea	$net	$nec	$neg\n";
    }
    else {
      print TOUT "$info[0]	$info[1]	$oritotal	0	0	0	0\n";
    }
    $nea = 0;
    $nec = 0;
    $net = 0;
    $neg = 0;
    @bqa = ();
    @bqt = ();
    @bqc = ();
    @bqg = ();
    $nea = grep(/A/, @bases); 
    $net = grep(/T/, @bases);
    $nec = grep(/C/, @bases);
    $neg = grep(/G/, @bases);
    $oritotal = $nea+$neg+$nec+$net; 


    @unsorted = ($nea, $net, $nec, $neg);
    @sorted = sort { $a <=> $b } @unsorted;
    
    #if($sorted[2]==0) {next;} ## at least two nts.

    for($i=0; $i<scalar @bases; $i++) {
      if($bases[$i] eq 'A' || $bases[$i] eq 'a') {push(@bqa, $bqs[$i]);}
      if($bases[$i] eq 'T' || $bases[$i] eq 't') {push(@bqt, $bqs[$i]);}
      if($bases[$i] eq 'C' || $bases[$i] eq 'c') {push(@bqc, $bqs[$i]);}
      if($bases[$i] eq 'G' || $bases[$i] eq 'g') {push(@bqg, $bqs[$i]);}
    }

  
    print OUT "$info[0]	$info[1]	$oritotal";
    for($j=0; $j<$nea; $j++) {
      $error = 10 ** (-($asc{$bqa[$j]}-33)/10);
      $error = $error;
      print OUT "	$error";
    }
    for($j=0; $j<$net; $j++) {
      $error = 10 ** (-($asc{$bqt[$j]}-33)/10);
      $error = $error+1;
      print OUT "	$error";
    }
    for($j=0; $j<$nec; $j++) {
      $error = 10 ** (-($asc{$bqc[$j]}-33)/10);
      $error = $error+2;
      print OUT "	$error";
    }
    for($j=0; $j<$neg; $j++) {
      $error = 10 ** (-($asc{$bqg[$j]}-33)/10);
      $error = $error+3;
      print OUT "	$error";
    }
    for($j=$oritotal+1; $j<=$maxc; $j++) {
      print OUT "	0";
    }

    print OUT "\n";
  

  }
  close IN;
  close OUT;
  close TOUT;
  close QOUT;
  
  ## MLE on allele account with R
  open (RS, ">$dir/Rscriptmle.r") || die "cannot generate Rscript\n";
  print RS "
  mlefnmy <- function(th,x) {
    logl <- sum(log(th[1]-2*th[1]*x[x>0 & x<1]+x[x>0 & x<1])) + sum(log(th[2]-2*th[2]*(x[x>1 & x<2]-1)+(x[x>1 & x<2]-1))) + sum(log(th[3]-2*th[3]*(x[x>2 & x<3]-2)+(x[x>2 & x<3]-2))) +sum(log((1-th[1]-th[2]-th[3])-2*(1-th[1]-th[2]-th[3])*(x[x>3 & x<4]-3)+(x[x>3 & x<4]-3)))
    return (-logl)
  }\n";

  print RS '
  myprocess <- function(x) {
    a<-array(0,4)
    col <- length(x)
    y<-as.numeric(x[4:col])
    y<- y[y!=0]

    total <- sum(y>0 & y<4)
    A <- (sum(y>0 & y<1)+1)/(total+4)
    T <- (sum(y>1 & y<2)+1)/(total+4)
    C <- (sum(y>2 & y<3)+1)/(total+4)
    G <- (sum(y>3 & y<4)+1)/(total+4)

#    a[1:3]<-constrOptim(c(0.25,0.25,0.25),mlefnmy, x=y, NULL, ui=u, ci=c)$par
    a[1:3]<-constrOptim(c(A,T,C),mlefnmy, x=y, NULL, ui=u, ci=c)$par

    a[4]<-1-sum(a[1:3])
    if(sum(y>0 & y<1)==0) {a[1]=0} 
    if(sum(y>1 & y<2)==0) {a[2]=0} 
    if(sum(y>2 & y<3)==0) {a[3]=0} 
    if(sum(y>3 & y<4)==0) {a[4]=0}

    return(a)
  }'."\n";

  print RS "
  u <- matrix(c(1,0,0,-1,0,1,0,-1,0,0,1,-1),4,3)
  c <- c(0,0,0,-1)\n\n";

  print RS 'x <- read.table("'.$dir.'/tempmle.txt", as.is=T, header=F)'."\n";
  
  print RS '
  col<-ncol(x)
  par <- as.matrix(t(apply(x, 1, myprocess)))
 
  par <- round(par*x[,3])
  x[,3]=apply(par,1,sum)
  par <- cbind(x[,c(1:3)], par)
  colnames(par) <- c("chr","pos","cov","A","T","C","G")

  y <- read.table("'.$dir.'/tempnotcallset.txt", as.is=T, header=F)
  colnames(y) <- c("chr","pos","cov","A","T","C","G")

  par <- merge(par, y, by=c("chr", "pos"))
  par$cov <- apply(par[,c(4:7,9:12)],1,sum)
  par$A <- par[,4]+par[,9]
  par$T <- par[,5]+par[,10]
  par$C <- par[,6]+par[,11]
  par$G <- par[,7]+par[,12]

  par <- par[,-3:-12]
  colnames(par) <- c("chr","pos","cov","A","T","C","G")
  z <- read.table("'.$dir.'/tempquacallset.txt", as.is=T, header=F)
  colnames(z) <- c("chr","pos","cov","A","T","C","G")
  par <- merge(par, z, by=c("chr", "pos"))
  par$cov <- apply(par[,c(4:7,9:12)],1,sum)
  par$A <- par[,4]+par[,9]
  par$T <- par[,5]+par[,10]
  par$C <- par[,6]+par[,11]
  par$G <- par[,7]+par[,12]

  par <- par[,-3:-12]
  colnames(par) <- c("chr","pos","cov","A","T","C","G")
  
  par <- par[order(par$chr,par$pos),]'."\n";
  
  print RS 'write.table(par, file="'.$fileout.'",quote=F,sep="\t",row.names=F,col.names=T)'."\n";
  
  close RS;
  
  system("R < $dir/Rscriptmle.r --vanilla");
  
  unlink ("$dir/Rscriptmle.r");
  unlink("$dir/tempmle.txt");
  unlink("$dir/tempnotcallset.txt");
  unlink("$dir/tempquacallset.txt");

}

sub refbias {
  my %opts = (r=>1.02);
  getopts('r:',\%opts);

  die(qq/
  Usage: Psafe.pl refbias [options] <RefGenome.> <in.rawpileup> <out.txt>\n
  Options:	-r Reference allele bias <DEFAULT: 1.02>\n 
  Note: Make sure the chromosome order of reference genome is the same with pileup file\n\n/) if (@ARGV != 3  && -t STDIN);
  my($ref, $filein, $fileout) = @ARGV; 

  my ($line, $line2, @info, @info2, $chr, $pos, $length, $nt);
  open(IN, "$filein") || die "cannot open $filein\n";
  open(REF, "$ref") || die "cannot open $ref\n";
  open(OUT, ">$fileout") || die "cannot generate $fileout\n";
  
  $line2 = <REF>;
  $line2 =~ s/\s+$//; # trim the newline.
  chomp $line2;

  if($line2 =~ m/^\>/) {$chr = $line2; $chr =~ s/^\>//;$pos=0;}
  print "Start $chr...\n";
  $line2 = <REF>;
  $line2 =~ s/\s+$//; # trim the newline.
  chomp $line2;
  @info2 = split(//, $line2);
  $length = scalar @info2;
  $pos += $length;
  $line = <IN>;      
  while(!eof(IN)) {
    $line = <IN>;
    $line =~ s/\s+$//; # trim the newline.
    chomp $line;

    @info = split(/\t/, $line);
    if($line !~ m/^ch/i) {next;}
    if(eof(REF)) {last;}
    if($chr ne $info[0]) {
      if($line2 =~ m/^\>/) {
          $line2 =~ s/\s+$//; # trim the newline.
          chomp $line2;
          $chr = $line2; $chr =~ s/^\>//;$pos=0;
          print "start $chr...\n";
      }
      while(($line2 !~ m/^\>/ || $chr ne $info[0]) && !eof(REF)) {
        $line2 = <REF>;
        if($line2 =~ m/^\>/) {
          $line2 =~ s/\s+$//; # trim the newline.
          chomp $line2;
          $chr = $line2; $chr =~ s/^\>//;$pos=0;
          print "start $chr...\n";
        }
      }
      
      $line2 = <REF>;
      $line2 =~ s/\s+$//; # trim the newline.
      chomp $line2;
      @info2 = split(//, $line2);
      $length = scalar @info2;
      $pos += $length;
    }
    
    if($chr eq $info[0]) {
      if($line2=~m/^\>/) {next;}
      while($info[1] > $pos && !eof(REF)) {
        $line2 = <REF>;
        $line2 =~ s/\s+$//; # trim the newline.
        chomp $line2;
        
        if($line2=~m/^\>/) {last;}
        @info2 = split(//, $line2);
        $length = scalar @info2;
        $pos += $length;
      }
      if($info[1] <= $pos) {
        $nt = $info2[$info[1]-$pos+$length-1];
         $nt =~ tr/[a-z]/[A-Z]/;
	 if($nt eq 'A') {$info[4] *= $opts{r};$info[5] *= $opts{r};$info[6] *= $opts{r};}
         if($nt eq 'T') {$info[3] *= $opts{r};$info[5] *= $opts{r};$info[6] *= $opts{r};}
	 if($nt eq 'C') {$info[3] *= $opts{r};$info[4] *= $opts{r};$info[6] *= $opts{r};}
	 if($nt eq 'G') {$info[3] *= $opts{r};$info[4] *= $opts{r};$info[5] *= $opts{r};}
         $info[4] = sprintf "%.0f", $info[4];
	 $info[5] = sprintf "%.0f", $info[5];
	 $info[6] = sprintf "%.0f", $info[6];
	 $info[3] = sprintf "%.0f", $info[3];
	 $info[2] = $info[3] +  $info[4] + $info[5] + $info[6];
        print OUT "$info[0]	$info[1]	$nt	$info[2]	$info[3]	$info[4]	$info[5]	$info[6]\n";

      }
    }
   
  }
  
  close IN;
  close REF;
  close OUT;
}

sub mymedian {
    my @pole = @_;

    my $ret;

    @pole = sort(@pole);

    if( (@pole % 2) == 1 ) {
        $ret = $pole[((@pole+1) / 2)-1];
    } else {
        $ret = $pole[@pole / 2];
    }

    return $ret;
}
sub delmedian {
    my @pole = @_;

    my ($i, $ret, @newp);

    @pole = sort(@pole);

    if( ((scalar @pole) % 2) == 1 ) {
        $ret = $pole[((@pole+1) / 2)-1];
        delete $pole[((@pole+1) / 2)-1];

    } else {
        $ret = $pole[@pole / 2];
        delete $pole[@pole / 2];
    }
    $ret=0;
    foreach (0..$#pole) {
      if (exists $pole[$_]) {$newp[$ret]=$pole[$_]; $ret++;}
    }
    return @newp;
}

sub usage {
  die(qq/
Usage:   Psafe.pl <command> [<arguments>]\n
Command: rawpilese      pileup mapped reads (sam file) of single end sequencing
         rawpilepe      pileup mapped reads (sam file) of paired end sequencing
         rawpilepeV2      pileup mapped reads (sam file) of paired end sequencing (do not care the mate is soft clipping or not)
         unipilese      unique reads pileup of single end sequencing
         unipilepe      unique reads pileup of paired end sequencing
         mlecount       Adjust allele count by base quality score 
                        with Maximum likelihood estimation and output the 
                        adjusted count results
         refbias	Control the reference allele alignment bias

\n/);
}