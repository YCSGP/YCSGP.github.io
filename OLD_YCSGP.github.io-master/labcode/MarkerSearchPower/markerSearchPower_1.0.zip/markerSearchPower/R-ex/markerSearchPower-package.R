### Name: markerSearchPower-package
### Title: Package of power calculation for marker detection strategies
### Aliases: markerSearchPower-package
### Keywords: package

### ** Examples

markerSearchPower (mainEff1=0.1, mainEff2=0.1, epistasisEff=2.4, noiseSD=sqrt(3), alleleFreq1=0.7, 
            alleleFreq2=0.7, strategy = "marginal", powerDef = "both", DetectionN=10,
            obsN=1000, markerN=300000);




