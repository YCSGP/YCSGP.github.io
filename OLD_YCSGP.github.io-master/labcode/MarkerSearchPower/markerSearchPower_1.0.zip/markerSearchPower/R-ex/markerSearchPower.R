### Name: markerSearchPower
### Title: Function of power calculation
### Aliases: markerSearchPower
### Keywords: htest

### ** Examples


markerSearchPower (mainEff1=0.1, mainEff2=0.1, epistasisEff=2.4, noiseSD=sqrt(3), 
     alleleFreq1=0.7, alleleFreq2=0.7, DetectionN=2, obsN=100, markerN=300);
markerSearchPower (mainEff1=0.1, mainEff2=0.1, epistasisEff=2.4, noiseSD=sqrt(3), 
     alleleFreq1=0.7, alleleFreq2=0.7, DetectionN=1, obsN=100, markerN=300, 
     powerDef = "either");
markerSearchPower (mainEff1=0.1, mainEff2=0.1, epistasisEff=1.4, noiseSD=sqrt(3), 
     alleleFreq1=0.7, alleleFreq2=0.7, DetectionN=1, obsN=100, markerN=300, 
     strategy = "exhaustive", powerDef = "either");
markerSearchPower (mainEff1=0.1, mainEff2=0.1, epistasisEff=1.4, noiseSD=sqrt(3), 
     alleleFreq1=0.7, alleleFreq2=0.7, DetectionN=1, obsN=100, markerN=300, 
     strategy = "exhaustive", powerDef = "both");
markerSearchPower (mainEff1=0.1, mainEff2=0.1, epistasisEff=1.4, noiseSD=sqrt(3), 
     alleleFreq1=0.7, alleleFreq2=0.7, DetectionN=5, obsN=100, markerN=300, 
     strategy = "forward", powerDef = "both");
markerSearchPower (mainEff1=0.1, mainEff2=0.1, epistasisEff=1.4, noiseSD=sqrt(3), 
     alleleFreq1=0.7, alleleFreq2=0.7, DetectionN=5, obsN=100, markerN=300, 
     strategy = "forward", powerDef = "either");




