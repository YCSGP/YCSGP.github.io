#include <stdio.h>
#include <math.h>

long RX=123,RY=456,RZ=789;

// definition for beta function
#define MAXIT 100
#define EPS 3.0e-7
#define FPMIN 1.0e-30
#define SWAP(a,b) {temp=(a);(a)=(b);(b)=temp;}
// #include "subfunction.c"

main()
{
	int		i,j;
    int     nmice;
	int     itemp,itemp1,itemp2;
	int     ** mouse, **gmouse;
	int		jfather,jmother;
	int     nsimu,isimu,threshold;
	int		** kout;
	double  dtemp,pp53,pe2f;

	int     ** imatrix(), *ivector();
	double  rand1();

	void	skipline();

	FILE	*fp_mating;
	FILE    *fp_resultd, *fp_resultr;

// open file to read in mating types

	printf("Please type in the probability of homozygosity for the first line of mice: \n");
	scanf("%lf",&pp53);
	printf("Please type in the probability of homozygosity for the second line of mice: \n");
	scanf("%lf",&pe2f);
	printf("Please type in the number of simulations to be undertaken: \n");
	scanf("%d",&nsimu);
	printf("Please type in the number of mice due to non-modifier gene effects: \n");
	scanf("%d",&threshold);

//	pp53 = 0.97;
//	pe2f = 0.75;

	fp_mating=fopen("mating.txt","r");
	if(fp_mating==NULL) { printf("Can not open mating.txt file."); }

	skipline(fp_mating,1);
    fscanf(fp_mating, "%d", &nmice);
	mouse = imatrix(1,nmice,1,4);
	gmouse = imatrix(1,nmice,1,2);

	skipline(fp_mating,2);
	for(i=1;i<=nmice;i++)
	{
		for(j=1;j<=4;j++)
		{
			fscanf(fp_mating,"%d",&itemp);
			mouse[i][j]=itemp;
		}
	}

	fclose(fp_mating);

	nsimu = 1000000;
	kout = imatrix(1,nsimu,1,6);

	for (isimu=1;isimu<=nsimu;isimu++)
	{
		for (j=1;j<=2;j++)
		{
			gmouse[j][1]=1;
			dtemp=rand1();
			if (dtemp<pp53)
			{
				gmouse[j][2]=1;
			}
			else
			{
				gmouse[j][2]=2;
			}
		}
		for (j=3;j<=4;j++)
		{
			gmouse[j][1]=1;
			dtemp=rand1();
			if (dtemp<pe2f)
			{
				gmouse[j][2]=1;
			}
			else
			{
				gmouse[j][2]=2;
			}
		}
		for (j=5;j<=nmice;j++)
		{
			jfather=mouse[j][2];
			jmother=mouse[j][3];
			dtemp=rand1();
			if (dtemp < 0.5)
			{
				itemp=1;
			}
			else
			{
				itemp=2;
			}
			gmouse[j][1]=gmouse[jfather][itemp];
			dtemp=rand1();
			if (dtemp < 0.5)
			{
				itemp=1;
			}
			else
			{
				itemp=2;
			}
			gmouse[j][2]=gmouse[jmother][itemp];
		}

		for (j=1;j<=6;j++)
		{
			kout[isimu][j]=0;
		}
		for (j=1;j<=nmice;j++)
		{
			itemp=gmouse[j][1]+gmouse[j][2]-1;
			if (mouse[j][4]==1) kout[isimu][itemp]=kout[isimu][itemp]+1;
			if (mouse[j][4]==2) kout[isimu][itemp+3]=kout[isimu][itemp+3]+1;
		}
//    fp_result=fopen("result.txt","a");
//    for(i=1;i<=nmice;i++)
//	{
//		for (j=1;j<=4;j++)
//		{
//			fprintf(fp_result,"%d \t",mouse[i][j]);
//		}
//		for (j=1;j<=2;j++)
//		{
//			fprintf(fp_result,"%d \t",gmouse[i][j]);
//		}
//  fprintf(fp_result,"\n");
//	}
//	fclose(fp_result);
	}
	fp_resultd=fopen("resultd.txt","w");
	fp_resultr=fopen("resultr.txt","w");
    for(isimu=1;isimu<=nsimu;isimu++)
	{
		itemp1 = kout[isimu][2]+kout[isimu][3];
		itemp2 = kout[isimu][4];
		if (itemp1<=threshold && itemp2<=threshold)
		{
		for (j=1;j<=6;j++)
		{
			fprintf(fp_resultd,"%d \t",kout[isimu][j]);
		}
		fprintf(fp_resultd,"\n");
		}
		itemp1 = kout[isimu][3];
		itemp2 = kout[isimu][4]+kout[isimu][5];
		if (itemp1<=threshold && itemp2<=threshold)
		{
		for (j=1;j<=6;j++)
		{
			fprintf(fp_resultr,"%d \t",kout[isimu][j]);
		}
		fprintf(fp_resultr,"\n");
		}
	}
	fclose(fp_resultd);
	fclose(fp_resultr);
}

//==============================================
//function to generate the uniformly distributed sample on (0,1) 
//long RX=1,RY=1,RZ=1;
 
 double rand1()
 {    
	
	 double t;
     int t1;
     RX=(171*RX)%30269; 
     RY=(172*RY)%30309;
     RZ=(170*RZ)%30323;
     t=(double)(RX/30269.0+RY/30309.0+RZ/30323.0);
     t1=(int)(t);
     return(t-t1);
}

void nrerror(error_text)
char error_text[];
{
	void exit();

	fprintf(stderr,"Numerical Recipes run-time error...\n");
	fprintf(stderr,"%s\n",error_text);
	fprintf(stderr,"...now exiting to system...\n");
	exit(1);
}



float *vector(nl,nh)
int nl,nh;
{
	float *v;

	v=(float *)malloc((unsigned) (nh-nl+1)*sizeof(float));
	if (!v) nrerror("allocation failure in vector()");
	return v-nl;
}

int *ivector(nl,nh)
int nl,nh;
{
	int *v;
/*        char *malloc(); */
	v=(int *)malloc((unsigned) ((nh-nl+1)*sizeof(int)));
	if (!v) nrerror("allocation failure in ivector()");
	return v-nl;
}


double *dvector(nl,nh)
int nl,nh;
{
	double *v;
        /* char *malloc(); */
	v=(double *)malloc((unsigned) ((nh-nl+1)*sizeof(double)));
	if (!v) nrerror("allocation failure in dvector()");
	return v-nl;
}



float **matrix(nrl,nrh,ncl,nch)
int nrl,nrh,ncl,nch;
{
	int i;
	float **m;

	m=(float **) malloc((unsigned) (nrh-nrl+1)*sizeof(float*));
	if (!m) nrerror("allocation failure 1 in matrix()");
	m -= nrl;

	for(i=nrl;i<=nrh;i++) {
		m[i]=(float *) malloc((unsigned) (nch-ncl+1)*sizeof(float));
		if (!m[i]) nrerror("allocation failure 2 in matrix()");
		m[i] -= ncl;
	}
	return m;
}

double **dmatrix(nrl,nrh,ncl,nch)
int nrl,nrh,ncl,nch;
{
	int i;
	double **m;
        /*char *malloc();*/
	m=(double **) malloc((unsigned) ((nrh-nrl+1)*sizeof(double*)));
	if (!m) nrerror("allocation failure 1 in dmatrix()");
	m -= nrl;

	for(i=nrl;i<=nrh;i++) {
		m[i]=(double *) malloc((unsigned) ((nch-ncl+1)*sizeof(double)));
		if (!m[i]) nrerror("allocation failure 2 in dmatrix()");
		m[i] -= ncl;
	}
	return m;
}

int **imatrix(nrl,nrh,ncl,nch)
int nrl,nrh,ncl,nch;
{
	int i,**m;

	m=(int **)malloc((unsigned) (nrh-nrl+1)*sizeof(int*));
	if (!m) nrerror("allocation failure 1 in imatrix()");
	m -= nrl;

	for(i=nrl;i<=nrh;i++) {
		m[i]=(int *)malloc((unsigned) (nch-ncl+1)*sizeof(int));
		if (!m[i]) nrerror("allocation failure 2 in imatrix()");
		m[i] -= ncl;
	}
	return m;
}



float **submatrix(a,oldrl,oldrh,oldcl,oldch,newrl,newcl)
float **a;
int oldrl,oldrh,oldcl,oldch,newrl,newcl;
{
	int i,j;
	float **m;

	m=(float **) malloc((unsigned) (oldrh-oldrl+1)*sizeof(float*));
	if (!m) nrerror("allocation failure in submatrix()");
	m -= newrl;

	for(i=oldrl,j=newrl;i<=oldrh;i++,j++) m[j]=a[i]+oldcl-newcl;

	return m;
}



void free_vector(v,nl,nh)
float *v;
int nl,nh;
{
	free((char*) (v+nl));
}

void free_ivector(v,nl,nh)
int *v,nl,nh;
{
	free((char*) (v+nl));
}

void free_dvector(v,nl,nh)
double *v;
int nl,nh;
{
	free((char*) (v+nl));
}



void free_matrix(m,nrl,nrh,ncl,nch)
float **m;
int nrl,nrh,ncl,nch;
{
	int i;

	for(i=nrh;i>=nrl;i--) free((char*) (m[i]+ncl));
	free((char*) (m+nrl));
}

void free_dmatrix(m,nrl,nrh,ncl,nch)
double **m;
int nrl,nrh,ncl,nch;
{
	int i;

	for(i=nrh;i>=nrl;i--) free((char*) (m[i]+ncl));
	free((char*) (m+nrl));
}

void free_imatrix(m,nrl,nrh,ncl,nch)
int **m;
int nrl,nrh,ncl,nch;
{
	int i;

	for(i=nrh;i>=nrl;i--) free((char*) (m[i]+ncl));
	free((char*) (m+nrl));
}



void free_submatrix(b,nrl,nrh,ncl,nch)
float **b;
int nrl,nrh,ncl,nch;
{
	free((char*) (b+nrl));
}



float **convert_matrix(a,nrl,nrh,ncl,nch)
float *a;
int nrl,nrh,ncl,nch;
{
	int i,j,nrow,ncol;
	float **m;

	nrow=nrh-nrl+1;
	ncol=nch-ncl+1;
	m = (float **) malloc((unsigned) (nrow)*sizeof(float*));
	if (!m) nrerror("allocation failure in convert_matrix()");
	m -= nrl;
	for(i=0,j=nrl;i<=nrow-1;i++,j++) m[j]=a+ncol*i-ncl;
	return m;
}



void free_convert_matrix(b,nrl,nrh,ncl,nch)
float **b;
int nrl,nrh,ncl,nch;
{
	free((char*) (b+nrl));
}


void skipline(FILE *fp, int fi)
{
	int k=0;
	char ch;
	while (k<fi){
		for (;;)
		{
			ch=getc(fp);
			if (ch=='\n') k++;
			break;
		}
		}
}

		

