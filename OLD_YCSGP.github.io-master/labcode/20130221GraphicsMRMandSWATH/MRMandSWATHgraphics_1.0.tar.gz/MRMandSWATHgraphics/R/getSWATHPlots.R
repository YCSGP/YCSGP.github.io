getSWATHPlots <-
function(...){
input.file <- file.choose()

dd <- read.delim(input.file, stringsAsFactors = FALSE)


dd$id <- paste(dd$protein_id, dd$pep_seq, dd$mz, sep = "_")

rt <- dd$update_rt
sn <- dd$s_n
fdr <- dd$fdr
sn.cat <- cut(sn, breaks  = c(-1, 3, 5, 10, Inf))

dd$sn.cat <- sn.cat

names(rt) <- names(sn) <- names(fdr) <- names(sn.cat) <- dd$id

filenames <- names(table(dd$file_name))


rt.mat <- sn.cat.mat <- sn.mat <- fdr.mat <- matrix(NA, nc =
length(filenames), nr = length(table(dd$id)), dimnames = list(
names(table(dd$id)), filenames))


# make matrices..
for(i in 1:ncol(rt.mat)){
   
   
   sub <- subset(dd, file_name == filenames[i])
   rownames(sub) <- sub$id
   
   rt.mat[,i] <- (sub[rownames(rt.mat), ])$update_rt
   sn.mat[,i] <- (sub[rownames(rt.mat), ])$s_n
   sn.cat.mat[,i] <- as.numeric( (sub[rownames(rt.mat), ])$sn.cat )
       
   fdr.mat[,i] <- (sub[rownames(rt.mat), ])$fdr
   
   
}


pep.seq <- sapply( strsplit(rownames(rt.mat), "_"),
function(x){paste(x[1:3], collapse = "_")})

# peptide.level sn.cat
sn.cat.pep <- apply(  sn.cat.mat , 2,  function(x, ind){tapply(x,
INDEX = ind, FUN = mean)}, ind = pep.seq)
fdr.cat.pep <-  apply(  fdr.mat < 0.05 , 2,  function(x,
ind){tapply(x, INDEX = ind, FUN = mean)}, ind = pep.seq)

protein.id <- sapply( strsplit(rownames(sn.cat.pep), "_"), function(x){x[1]})

pep.label <- protein.id
for(i in 1:length(protein.id)){
   
   ind <- which(protein.id  == unique(protein.id)[i])
   pep.label[ind] <- 1:length(ind)
   
}


bar.graph <- list()

for(i in 1:ncol(sn.cat.pep)){

	df <- data.frame("protein" = protein.id, "pep" = rownames(sn.cat.pep), 
				"sn.cat" = sn.cat.pep[,i], "pep.label" = pep.label, 
				"fdr.cat" = fdr.cat.pep[,i])


	cols <- c("red", "green3")
           
           
           bar.graph[[i]] <- barchart(sn.cat ~ pep.label | protein, groups= factor(fdr.cat),
               data = df, ylim = c(-0.2, 4.5),
               layout = c(10, 12), ylab = "Average categorized S/N", xlab = "Peptides",
               stack = TRUE,  col = cols,   main = colnames(sn.cat.pep)[i],
               auto.key = list(space = "top", columns = 1, col = cols,
               text = c("FDR > 0.05", "FDR < 0.05"), rectangles = FALSE,  font = 2, cex =1))
   


}



output.file <- paste(dirname(input.file), "/", "swathBarChart", strsplit(basename(input.file), ".", fixed = TRUE)[[1]][1], ".pdf", sep = "")




pdf(output.file, height = 10, width = 10)
for(i in 1:length(bar.graph)){

	print(bar.graph[[i]])

	cat(colnames(sn.cat.pep)[i]); cat("\n")


}
dev.off()

}

