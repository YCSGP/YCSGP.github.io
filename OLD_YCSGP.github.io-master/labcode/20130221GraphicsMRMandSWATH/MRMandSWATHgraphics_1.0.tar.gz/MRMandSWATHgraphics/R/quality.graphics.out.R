quality.graphics.out <-
function(qualityGraphicsObj){


	hh <- qualityGraphicsObj$height + 3

	if( (length(qualityGraphicsObj$sample) > 0)  & qualityGraphicsObj$labeled){

		pdf("runSpecific_barchart_heavy_light.pdf", width = 24, height = hh)
		for(kk in 1:length(qualityGraphicsObj$sample)){
			print(qualityGraphicsObj$sample[[kk]][[1]], more = TRUE, split = c(1,1,2,1))
			print(qualityGraphicsObj$sample[[kk]][[2]], more = FALSE, split = c(2,1,2,1))
		}
		dev.off()

	}

	if( (length(qualityGraphicsObj$group) > 0)  & qualityGraphicsObj$labeled){
		pdf("combined_barchart_heavy_light.pdf", width = 24, height = hh)
		for(kk in 1:length(qualityGraphicsObj$group)){
			print(qualityGraphicsObj$group[[kk]][[1]], more = TRUE, split = c(1,1,2,1))
			print(qualityGraphicsObj$group[[kk]][[2]], more = FALSE, split = c(2,1,2,1))
		}
		dev.off()

	}

	if( (length(qualityGraphicsObj$sample) > 0)  & !qualityGraphicsObj$labeled){

		pdf("runSpecific_barchart.pdf", width = 12, height = hh)
		for(kk in 1:length(qualityGraphicsObj$sample)){
			print(qualityGraphicsObj$sample[[kk]])
		}
		dev.off()

	}


	if( (length(qualityGraphicsObj$group) > 0)  & !qualityGraphicsObj$labeled){

		pdf("combined_barchart.pdf", width = 12, height = hh)
		for(kk in 1:length(qualityGraphicsObj$group)){
			print(qualityGraphicsObj$group[[kk]])
		}
		dev.off()

	}

}

