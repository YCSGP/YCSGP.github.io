getMRMplots <-
function( ){



	cat("Hit ENTER to choose the (MULTIQUANT)DATA file")
	readline()
	data.file <- file.choose()
	cat(paste("Multiquant output data to use:", data.file))

	
	cat("\n \n")

	
	chart.option <- readline("Want to get results for 'group only'/'sample only'/'both'? [g/s/b]: \n")

	


	cat("Select Transition naming option \n")
	cat("1 if Protein.Peptide.ChargeAndTransition (Q1mass/Q3mass) \n")
	cat("  of Protein.Peptide.ChargeAndTransition.light/heavy (Q1mass/Q3mass) \n")
	cat("2 if Transition_Peptide_Charge_Protein (Q1mass/Q3mass) \n")
	
	name.option <- readline("Type (1/2):")
	
	cat("\n \n")
	


	cat("Is it labeled experiment \n and do you want to make a separate figures for heavy and light labeled peptides? \n")
	is.labeled <- readline("Type [y] or [Y] for labeled experiment, just hit enter for label-free \n")

	is.labeled <- if(is.labeled %in% c("y", "Y")){TRUE}else{FALSE}



	cat("\n \n")
	
	
	
	output.nms <- strsplit(data.file, ".txt")[[1]][1]
	
	current.dir <- getwd()
	
	setwd( dirname(data.file) ) 

	new.dir.nms <- paste( basename(output.nms), "_MRMplots_Result", sep = "")
	
	cat("Hit ENTER to check the output directory setting..")
	readline()
	
	if(  basename(new.dir.nms) %in% dir( dirname(data.file) )){
		
		cat(  paste(new.dir.nms, "ALREADY EXISTS.  \n \n Do you want to proceed with this directory name? \n Files in the directory may be overwritten.. [y/n]:  \n"))
		
		answer.dir <- readline()
		
		if(answer.dir != "y"){
			
			cat("Please specify the new directory name: \n")
			new.dir.nms <- readline()
			
			
		}
		
	}
	
	cat(paste("Output files are saved at", new.dir.nms , "\n under", getwd(), "\n\n"))

	
	dir.create(new.dir.nms, showWarnings = FALSE)

	setwd(new.dir.nms)

	cat("\n \n")


	# Read multiquant data
	dd <- read.multiquant(data.file)

	# Get transition-level data
	transition.output <- data.transition(dd, name.option = name.option, is.labeled)

	# Get peptide-level data
	peptide.output <- data.peptide(transition.output, is.labeled)

	# Get sample information
	sample.info.matrix <- sample.info(transition.output)

	

	cat("Making traces of peak area, signal-to-noise ratio, and retention time across all proteins/peptides/transitions.. \n")

	# area, s/n, retention time chart for every protein/peptide/transition
	if( nrow(sample.info.matrix) == 1){

		warning("Only one run in the data set. Skip transition-level graphics for area, RT, and S/N ratio and scatter plots and Venn diagrams..\n")

	}else{

		cat("Making scatter plots with correlation and Venn diagrams..\n")

		# Protein summary plot
		ProteinSummary(transition.output, peptide.output, 
			is.labeled = is.labeled, sample.info.mat = sample.info.matrix)




		foo1 <- graphics.transition(transition.output, is.labeled = is.labeled, 
				sample.info.mat = sample.info.matrix)

		graphics.transition.out(foo1)
	}




	cat("Making bar charts using signal-to-noise ratio..\n")
	cat("It may take a while... \n")
	# quality graphics

	foo2 <- quality.graphics(peptide.output, is.labeled = is.labeled, name.option = name.option,
						chart.option = chart.option, sample.info.mat = sample.info.matrix)

	quality.graphics.out(foo2)


	if( nrow(sample.info.matrix) == 1){

		warning("Only one run in the data set. Skip other graphical summary..\n")

	}else{
		cat("Making other graphics.. \n")
		# other graphics
		make.otherGraphics(transition.output, sample.info.mat = sample.info.matrix)

	}

	cat("Done..\n")

	 

}

