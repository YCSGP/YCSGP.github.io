data.transition <-
function(dd, name.option, is.labeled = FALSE){

	## get transition names and sample names
	#transition.nms <-sapply(strsplit(unique(dd$Component.Name), " "), function(x){x[1]})

	transition.nms <- unique(dd$Component.Name)
	sample.nms <- names(table(dd$Sample.Name)) 


	## get matrices of intersting features
	## : observed and expected retention time, peak with at half height,
	##   normalized group area ratio,
	##   Area, Height, SignalToNoise, Mass info

	num.transitions <- length(transition.nms)
	num.samples <- length(sample.nms)

	RT.obs <- PWHH <- NGAR <- 
		Area <- Height <- SignalToNoise <- RT.exp <- Mass.info <- 
	matrix(0, nr = num.transitions, nc = num.samples, 
		dimnames = list(transition.nms, sample.nms))


	for(i in 1:num.samples){
	
		sub <- subset(dd,  Sample.Name == sample.nms[i])

		#rownames(sub) <- sapply(strsplit(sub$Component.Name, " "), function(x){x[1]})
		rownames(sub) <- sub$Component.Name

		sub <- sub[transition.nms, ] # ordered by the transition name..

		RT.obs[,i] <- (sub[, which(colnames(sub) == "Retention.Time")])
		PWHH[,i]   <- (sub[, which(colnames(sub) == "Width.at.50.")])
		#NGAR[,i] <- as.numeric(sub[, which(colnames(sub) ==  "Normalised.Group.Area.Ratio")])
		Area[,i]   <- (sub[, which(colnames(sub) == "Area")])
		Height[,i]   <- (sub[, which(colnames(sub) == "Height")])
		SignalToNoise[,i]   <- (sub[, which(colnames(sub) == "Signal.Noise")])
		RT.exp[,i] <- (sub[, which(colnames(sub) == "Expected.RT")])
		#Mass.info[,i] <- sub[, which(colnames(sub) == "Mass.Info")]
	}




	## categorized S\N
	SignalToNoise2 <- SignalToNoise

	### missing peaks
	SignalToNoise2[is.na(SignalToNoise)] <- 1

	### noise level
	SignalToNoise2[!is.na(SignalToNoise) & SignalToNoise < 3] <- 2

	### above detection
	SignalToNoise2[!is.na(SignalToNoise) & SignalToNoise > 3] <- 3

	### above quantification
	SignalToNoise2[!is.na(SignalToNoise) & SignalToNoise > 5] <- 4

	### good quality
	SignalToNoise2[!is.na(SignalToNoise) & SignalToNoise > 10] <- 5


	if(is.labeled){	


		unlabeled.transition.nms <- sapply(strsplit(transition.nms, ".light"), function(x){x[1]})
		unlabeled.transition.nms <- sapply(strsplit(unlabeled.transition.nms, ".heavy"), function(x){x[1]})

		tailer <-  strsplit(transition.nms, " (", fixed = TRUE)
		

		tailer <- sapply(tailer, function(x){paste(x[-1], collapse = " (")})
		tailer <- paste("(", tailer, sep = "")


		names(tailer) <- sapply(strsplit(transition.nms, " "), function(x){x[1]})
	
		labeled.transition.nms <- rep(unique(unlabeled.transition.nms), 2)

		labeled.transition.nms <- paste(labeled.transition.nms, ".", 
										rep(c("heavy", "light"), each = length(unique(unlabeled.transition.nms))),
										sep = "")


		labeled.tailer <- rep("", length(labeled.transition.nms))
		names(labeled.tailer) <- labeled.transition.nms

		labeled.tailer[names(tailer)] <- tailer

		labeled.transition.nms <- paste(labeled.transition.nms, labeled.tailer)



		if(any(!(transition.nms %in% labeled.transition.nms))){

			print(transition.nms[!(transition.nms %in% labeled.transition.nms)])
			cat("\n These transition names are not following the required convention. \n")
			stop("Please check the transition (component names). \n")

		}

		RT.obs.labeled <- PWHH.labeled <- NGAR.labeled  <- 
			Area.labeled  <- Height.labeled  <- SignalToNoise.labeled  <- 
			RT.exp.labeled  <- Mass.info.labeled  <- SignalToNoise2.labeled <- 
			matrix(NA, nr = length(labeled.transition.nms), nc = num.samples, 
				dimnames = list(labeled.transition.nms, sample.nms))

		RT.obs.labeled[transition.nms, ] <- RT.obs
		RT.exp.labeled[transition.nms, ] <- RT.exp

		PWHH.labeled[transition.nms, ] <- PWHH
		#NGAR.labeled[transition.nms, ] <- NGAR
		Area.labeled[transition.nms, ] <- Area
		Height.labeled[transition.nms, ] <- Height
		SignalToNoise.labeled[transition.nms, ] <- SignalToNoise
		SignalToNoise2.labeled[transition.nms, ] <- SignalToNoise2
		#Mass.Info.labeled[transition.nms, ] <- Mass.Info

		transition.nms <- labeled.transition.nms

	}




	### get protein names and peptide sequences from transition IDs..
	if(name.option == "1"){ # new naming convention used for RBC
		
		
		tmp <- strsplit(transition.nms, ".", fixed = TRUE)
		seq <- sapply(tmp, function(x){x[2]})
		protein.nms <- strsplit(sapply(tmp, function(x){(x[1])}), "_")
		wil <- which(sapply(protein.nms, length) ==1)

		protein.nms <- sapply(protein.nms, function(x){x[1]})		
	
		protein.nms[wil] <- "WIL"

		peptide.nms <- paste(protein.nms, seq, sep = "_")



			
	}else if(name.option == "2"){ # usual naming convention
		
		##############################################
		## SHOULD FIX THIS!!! ########################
		##############################################
		tmp <- strsplit(transition.nms, "_")
		seq <- sapply(tmp, function(x){x[2]})
		protein.nms <- sapply(tmp, function(x){x[4]})

		protein.nms[is.na(protein.nms)] <- "WIL"
		peptide.nms <- paste(protein.nms, seq, sep = "_")

	}




		if(is.labeled){

			unlabeled.transition.nms <- sapply(strsplit(transition.nms, ".light"), function(x){x[1]})
			unlabeled.transition.nms <- sapply(strsplit(unlabeled.transition.nms, ".heavy"), function(x){x[1]})

	
			is.light <- sapply(strsplit(transition.nms, ".light"), length) == 2
							
			label <- rep("heavy", length(transition.nms))
			label[is.light] <- "light"
	
			labeled.protein.nms <- paste(protein.nms, label, sep = ".")
			labeled.peptide.nms <- paste(peptide.nms, label, sep = ".")

			



		}



	


	transition.info <- cbind("protein" = protein.nms, "peptide" = peptide.nms, "transition" = transition.nms)
	rownames(transition.info) <- transition.nms

	transition.data <- list("RT.obs" = RT.obs, "Area" = Area, "Height" = Height, 
		"SignalToNoise" = SignalToNoise, "RT.exp" = RT.exp,
		"SignalToNoise2" = SignalToNoise2)




	if(is.labeled){  

		transition.info <- cbind(transition.info, "labeled.peptide" = labeled.peptide.nms, 
			"labeled.protein" = labeled.protein.nms, "label" = label)

		labeled.transition.data <- list("RT.obs" = RT.obs.labeled, "Area" = Area.labeled, "Height" = Height.labeled, 
		"SignalToNoise" = SignalToNoise.labeled, "RT.exp" = RT.exp.labeled,
		"SignalToNoise2" = SignalToNoise2.labeled)

		list("data" = transition.data, "labeled.data" = labeled.transition.data, "info" = transition.info)

	}else{

		list("data" = transition.data, "info" = transition.info)
	}

}

