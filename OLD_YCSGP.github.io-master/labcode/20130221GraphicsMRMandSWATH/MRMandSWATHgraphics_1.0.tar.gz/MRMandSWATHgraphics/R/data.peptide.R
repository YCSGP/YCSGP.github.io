data.peptide <-
function(transition.output, is.labeled = FALSE){

	## transition.output = output from data.transition( )
	## two object, "data" has area, retention time, signal to noise ratio, and so on..
    ##             "info" has transition/peptide/protein level names


	## construct a matrix for the categorized Signal to Noise ratio
	# average categorized S\N

	num.samples <- ncol(transition.output$data$SignalToNoise2)
	SignalToNoise2 <- transition.output$data$SignalToNoise2



	if(is.labeled){
		peptide.nms <- transition.output$info[rownames(transition.output$data$SignalToNoise2), "labeled.peptide"]
	}else{
		peptide.nms <- transition.output$info[rownames(transition.output$data$SignalToNoise2), "peptide"]
	}

	
	unique.peptide.nms <- unique(peptide.nms)

	peptide.catSN <- freq.peaks <- matrix(0, nr = length(unique.peptide.nms), nc = ncol(SignalToNoise2))
	rownames(peptide.catSN) <- rownames(freq.peaks) <- unique.peptide.nms
	colnames(peptide.catSN) <- colnames(freq.peaks) <- colnames(SignalToNoise2)

	for(i in 1:num.samples){

		## get categorized score, averaged over 5 transitions corresponding to each peptide
		tmp <- tapply(SignalToNoise2[,i], INDEX = peptide.nms, mean)
		peptide.catSN[,i] <- tmp[unique.peptide.nms]
	
		## get the NUMBER of detected peaks	
		ind <- (SignalToNoise2[,i] > 1)	
		nump <- tapply(ind, INDEX = peptide.nms, FUN = sum)
		freq.peaks[ names(nump) , i] <- nump

	}


	if(is.labeled){

		peptide.id.labeled <- unique(transition.output$info[, "labeled.peptide"])
		peptide.catSN.labeled <- freq.peaks.labeled <- 
			matrix(0, nr = length(peptide.id.labeled), nc = ncol(peptide.catSN),
				dimnames = list(peptide.id.labeled, colnames(peptide.catSN)))


		peptide.catSN.labeled[rownames(peptide.catSN), ] <- peptide.catSN
		freq.peaks.labeled[rownames(freq.peaks), ] <- freq.peaks


	}




	# should check for PSD naming !!!
	protein.id <- sapply(strsplit(rownames(peptide.catSN), "_"), function(x){x[1]})

	df.peptide <- data.frame("protein.id" = protein.id, "peptide.id" = rownames(peptide.catSN), 
						stringsAsFactors = FALSE)

	rownames(df.peptide) <- df.peptide$peptide.id

	peptide.id2 <- df.peptide$peptide.id
	names(peptide.id2) <- peptide.id2

	ord.peptide.id2 <- peptide.id2[order(df.peptide$protein.id)]
	ord.protein.id2 <- df.peptide$protein.id[order(df.peptide$protein.id)]

	peptide.index <- factor(unlist(tapply(ord.peptide.id2, INDEX = ord.protein.id2, function(x){1:length(x)})))
	names(peptide.index) <- ord.peptide.id2

	peptide.index.unord <- peptide.index[peptide.id2]
	df.peptide$peptide.index <- peptide.index.unord
	
	output <- 	list("catSN" = peptide.catSN, "peakFreq" = freq.peaks, "info" = df.peptide)







	if(is.labeled){

		protein.id.unlabeled <- sapply(strsplit(rownames(peptide.catSN.labeled), "_"), function(x){x[1]})
		peptide.id.labeled <- rownames(peptide.catSN.labeled)
		peptide.id.unlabeled <- sapply(strsplit(rownames(peptide.catSN.labeled), ".heavy"), function(x){x[1]})
		peptide.id.unlabeled <- sapply(strsplit(peptide.id.unlabeled, ".light"), function(x){x[1]})



			is.light <- sapply(strsplit(rownames(peptide.catSN.labeled), ""), 
							function(x){paste(x[(-4:0) + length(x)], collapse = "")}) == "light"
			label <- rep("heavy", nrow(peptide.catSN.labeled))
			label[is.light] <- "light"
	
		protein.id.labeled <- paste(protein.id.unlabeled, label, sep = ".")


		df.peptide.labeled <- data.frame("protein.id.labeled" = protein.id.labeled, 
								"protein.id.unlabeled" = protein.id.unlabeled,
								"peptide.id.labeled" = peptide.id.labeled, 
								"peptide.id.unlabeled" = peptide.id.unlabeled, "label" = label, stringsAsFactors = FALSE)

		rownames(df.peptide.labeled) <- df.peptide.labeled$peptide.id.labeled

		peptide.id2.labeled <- df.peptide.labeled$peptide.id.labeled
		names(peptide.id2.labeled) <- peptide.id2.labeled

		ord.peptide.id2.labeled <- peptide.id2.labeled[order(df.peptide.labeled$protein.id.labeled)]
		ord.protein.id2.labeled <- df.peptide.labeled$protein.id.labeled[order(df.peptide.labeled$protein.id.labeled)]

		peptide.index.labeled <- factor(unlist(tapply(ord.peptide.id2.labeled, INDEX = ord.protein.id2.labeled, function(x){1:length(x)})))
		names(peptide.index.labeled) <- ord.peptide.id2.labeled

		peptide.index.unord.labeled <- peptide.index.labeled[peptide.id2.labeled]
		df.peptide.labeled$peptide.index.labeled <- peptide.index.unord.labeled
	

		unlabeled.output <- output
		labeled.output = list("catSN" = peptide.catSN.labeled, "peakFreq" = freq.peaks.labeled, "info" = df.peptide.labeled)

		output <- list("unlabeled" = unlabeled.output, "labeled" = labeled.output)
		
	}
	
	
	
	output

}

