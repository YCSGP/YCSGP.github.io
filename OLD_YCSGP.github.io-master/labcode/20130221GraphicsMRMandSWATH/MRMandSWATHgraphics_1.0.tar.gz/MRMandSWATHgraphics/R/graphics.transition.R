graphics.transition <-
function(transition.output, is.labeled = FALSE, sample.info.mat){

	# make various transition-level graphics
	# get sample information
	sample.nms <- sample.info.mat[, "sample.nms"]
	biorep <- sample.info.mat[, "biorep"]
	techrep <- sample.info.mat[, "techrep"]
	unique.biorep <- unique(biorep)




	protein.plot <- function(protein.nms, peptide.nms, data, main.title, yscale = "same", layout.input = c(1,3), ylabel = "values"){

		

		protein <- unique(protein.nms)

		res <- list()

		for(i in 1:length(protein)){

			ind <- protein.nms == protein[i]
			sub.data <- data[ind, ]
			
			if(sum(ind) == 1){

				sub.data <- as.matrix(t(sub.data))
				rownames(sub.data) <- rownames(data)[ind]

			}

			
		

			colnames(sub.data) <- techrep

			peptide.id <- peptide.nms[ind]


			df <- stack(as.data.frame(sub.data))
			df$transition <- rep(rownames(sub.data), ncol(sub.data))
			df$peptide <- rep(peptide.id, ncol(sub.data))

			res[[i]] <- xyplot(values ~ ind|peptide, groups = transition, data = df, 
				ylab = ylabel, xlab = "", 
				scales = list(x = list(rot = 90, cex = 0.7), y = list(relation = yscale)), 
				main = paste(main.title, protein[i]),
				type = c("g", "o"), col = rainbow(15), layout = layout.input, 
				auto.key = list(col = rainbow(15), space = "right", columns = 1, font = 2, cex = 0.7, points = FALSE))

		}

		res

	}


	plot.obj <- list()

	if(is.labeled){ 

		area.protein <- protein.plot(protein.nms = transition.output$info[, "protein"], 
						peptide.nms = transition.output$info[,"labeled.peptide"],
						data = log2(transition.output$labeled.data$Area), 
						ylabel = "log2(transition peak area)",
						main.title = "Area: ", yscale = "same", layout.input = c(2,3))


		rt.protein <- protein.plot(protein.nms = transition.output$info[, "protein"], 
						peptide.nms = transition.output$info[,"labeled.peptide"],
						data = (transition.output$labeled.data$RT.obs), 
						ylabel = "transition retention time (mins)",
						main.title = "Retention Time: ", yscale = "free", layout.input = c(2,3))

		sn.protein <- protein.plot(protein.nms = transition.output$info[, "protein"], 
						peptide.nms = transition.output$info[,"labeled.peptide"],
						data = log(transition.output$labeled.data$SignalToNoise, 5),
						ylabel = "log5(transition S/N)",  
						main.title = "Signal-To-Noise Ratio: ", yscale = "same", layout.input = c(2,3))



		area.protein.collapsed <- protein.plot(protein.nms = transition.output$info[, "protein"], 
						peptide.nms = transition.output$info[,"peptide"],
						data = log2(transition.output$labeled.data$Area), 
						ylabel = "log2(transition peak area)",
						main.title = "Area: ")


		rt.protein.collapsed <- protein.plot(protein.nms = transition.output$info[, "protein"], 
						peptide.nms = transition.output$info[,"peptide"],
						data = (transition.output$labeled.data$RT.obs), 
						ylabel = "transition retention time (mins)",
						main.title = "Retention Time: ", yscale = "free")


		sn.protein.collapsed <- protein.plot(protein.nms = transition.output$info[, "protein"], 
						peptide.nms = transition.output$info[,"peptide"],
						data = log(transition.output$labeled.data$SignalToNoise, 5),
						ylabel = "log5(transition S/N)",   
						main.title = "Signal-To-Noise Ratio: ", yscale = "same")


		plot.obj <- list("area.protein" = area.protein, 
							"rt.protein" = rt.protein, 
							"sn.protein" = sn.protein,
						    "area.protein.collapsed" = area.protein.collapsed, 
							"rt.protein.collapsed" =  rt.protein.collapsed, 
							"sn.protein.collapsed" = sn.protein.collapsed)


	}else{

		# label-free experiment
		area.protein <- protein.plot(protein.nms = transition.output$info[, "protein"], 
						peptide.nms = transition.output$info[,"peptide"],
						data = log2(transition.output$data$Area), 
						ylabel = "log2(transition peak area)",
						main.title = "Area: ")


		sn.protein <- protein.plot(protein.nms = transition.output$info[, "protein"], 
						peptide.nms = transition.output$info[,"peptide"],
						data = log(transition.output$data$SignalToNoise, 5),
 						ylabel = "log5(transition S/N)",  						
						main.title = "Signal-To-Noise Ratio: ", yscale = "same")



		rt.protein <- protein.plot(protein.nms = transition.output$info[, "protein"], 
						peptide.nms = transition.output$info[,"peptide"],
						data = (transition.output$data$RT.obs), 
						ylabel = "transition retention time (mins)",
						main.title = "Retention Time: ", yscale = "free")


		plot.obj <- list("area.protein" = area.protein, 
							"rt.protein" = rt.protein, 
							"sn.protein" = sn.protein)



	}


	plot.obj

}

