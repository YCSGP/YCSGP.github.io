ProteinSummary <-
function(transition.output , peptide.output,
					is.labeled = FALSE,
					 sample.info.mat){


	label.separate <- FALSE

	if(is.labeled){

		cat("This is labeled-experiment, do you want to plot heavy and light peptides, separately? \n")
		label.separate <- readline("Enter [y/n] \n")

		label.separate <- if(label.separate %in% c("y", "Y")){TRUE}else{FALSE}


	}


	# make various transition-level graphics
	# get sample information
	sample.nms <- sample.info.mat[, "sample.nms"]
	biorep <- sample.info.mat[, "biorep"]
	techrep <- sample.info.mat[, "techrep"]
	unique.biorep <- unique(biorep)



	
	area <- log2(transition.output$data$Area)
	area[is.na(area)] <- -1

	SN <- transition.output$data$SignalToNoise
	SN2 <- SN
	SN2[is.na(SN) | SN < 5] <- 2
	SN2[SN2 != 2] <- 1



	if(!is.labeled){
		peptide.score.all <- peptide.output$catSN		
		protein.score.all <- apply(peptide.score.all, 2, function(x){tapply(x, INDEX = peptide.output$info$protein.id, mean)}) 
	}else{ 

		peptide.score.all <- peptide.output$labeled$catSN
		protein.score.all <- apply(peptide.score.all, 2, function(x){tapply(x, INDEX = peptide.output$labeled$info$protein.id.labeled, mean)}) 

	}

	

	if(is.labeled & label.separate){

		transition.label <- transition.output$info[rownames(area), "label"]
		area.light <- area[transition.label == "light", ]
		area.heavy <- area[transition.label == "heavy", ]

		SN2.light <- SN2[transition.label == "light", ]
		SN2.heavy <- SN2[transition.label == "heavy", ]


		peptide.label <- peptide.output$label$info$label
		peptide.score.all.light <- peptide.score.all[peptide.label == "light", ]
		peptide.score.all.heavy <- peptide.score.all[peptide.label == "heavy", ]


		tmp <- peptide.output$label$info[, c("protein.id.labeled", "label")]
		tmp <- unique(tmp, MARGIN = 1)
		protein.label <- tmp[,2]
		names(protein.label) <- tmp[,1]
		protein.label <- protein.label[rownames(protein.score.all)]

		protein.score.all.light <- protein.score.all[protein.label == "light" , ]
		protein.score.all.heavy <- protein.score.all[protein.label == "heavy" , ]
	
	}



	summary.plots <- function(biorep, unique.biorep, techrep, 
									area, SN2, peptide.score.all, protein.score.all){

		par(mfrow = c(2, 3))

		for(i in 1:length(unique.biorep)){

			ind1 <- which(biorep %in% unique.biorep[i])
		
			if(length(ind1) == 1){cat(paste(unique.biorep[i], "has no replicate, skip this sample.. \n"))
			}else{
	
			

				plot(area[,ind1[1]], area[,ind1[2]],
					xlab = techrep[ind1[1]], ylab = techrep[ind1[2]], cex.lab = 1.5, 
					main = paste("log2(peak area), cor =", signif(cor(area[,ind1[1]], area[,ind1[2]]), 2)), 
					font.lab = 2, col = (SN2[,ind1[1]] + SN2[,ind1[2]])-1 )


				legend(0, max(area[,ind1[2]]), c("SN < 5 in one of samples", "SN < in both"), col = c(2,3), pch = 1)

				abline(0,1, col = "red")
				mtext(unique.biorep[i], line = 2, cex = 1.2, col = "navy", font = 1.2)

				if(length(ind1) == 2){
					cat(paste(unique.biorep[i], "has two technical replicates.. \n"))
					plot(1:10, 1:10, pch = "", axes = FALSE, xlab = "", ylab = "")
					plot(1:10, 1:10, pch = "", axes = FALSE, xlab = "", ylab = "")
				}else{

					plot(area[,ind1[1]], area[,ind1[3]], 
					xlab = techrep[ind1[1]], ylab = techrep[ind1[3]],cex.lab = 1.5, 
					main = paste("log2(peak area), cor =", signif(cor(area[,ind1[1]], area[,ind1[3]]), 2)), 
					font.lab = 2, col = (SN2[,ind1[1]] + SN2[,ind1[3]])-1 )
					abline(0,1, col = "red")

					plot(area[,ind1[2]], area[,ind1[3]], 
					xlab = techrep[ind1[2]], ylab = techrep[ind1[3]],cex.lab = 1.5, 
					main = paste("log2(peak area), cor =", signif(cor(area[,ind1[2]], area[,ind1[3]]), 2)), 
					font.lab = 2, col = (SN2[,ind1[2]] + SN2[,ind1[3]])-1 )
					abline(0,1, col = "red")

					if(length(ind1) > 3){

						cat(paste(unique.biorep[i], "has more than 3 technical replicates, graphics only with the first three runs.. \n"))

					}

				}

			
			}



			peptide.score <- peptide.score.all[,ind1]
			protein.score <- protein.score.all[,ind1]

			nms.venn <- techrep[ind1]
		
			if(length(ind1) == 2 | length(ind1) == 3){
				vennD(vennCounts(SN2[,ind1] == 1), names = nms.venn, cex = 1.2)
				mtext("transition-level", line = 0.7)

				vennD(vennCounts(peptide.score > 4), names = nms.venn, cex = 1.2)
				mtext("peptide-level", line = 0.7)
		
				vennD(vennCounts(protein.score > 4), names = nms.venn, cex = 1.2)
				mtext("protein-level", line = 0.7)
	


			}else{
				cat(paste(unique.biorep[i], "has no or more than 3 technical replicates.. \n"))
			}

		}

	}


	output.filenms <- "sampleScatterPlotAndVennDiagram.pdf"

	pdf(output.filenms, width = 14, height = 8)
		summary.plots(biorep, unique.biorep, techrep, 
			 	area, SN2, peptide.score.all, protein.score.all)
	dev.off()


	if(is.labeled & label.separate){

		pdf(paste("Light_only_", output.filenms, sep = ""), width = 14, height = 8)
		summary.plots(biorep, unique.biorep, techrep, 
			area.light, SN2.light, peptide.score.all.light, protein.score.all.light)
		dev.off()

		pdf(paste("Heavy_only_", output.filenms, sep = ""), width = 14, height = 8)
		summary.plots(biorep, unique.biorep, techrep, 
			area.heavy, SN2.heavy, peptide.score.all.heavy, protein.score.all.heavy)
		dev.off()

	}


}# end of protein summary..

