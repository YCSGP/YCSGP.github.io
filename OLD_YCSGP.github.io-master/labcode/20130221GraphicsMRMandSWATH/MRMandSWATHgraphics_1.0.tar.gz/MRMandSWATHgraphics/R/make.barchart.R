make.barchart <-
function(protein.id, peptide.index, pepSN,  peakFreq, main.title, num.r){
		
		is.single <- is.null(nrow(pepSN))
		if(is.single){avg.num.peaks <- peakFreq }else{avg.num.peaks <- rowMeans(peakFreq)}
		
		# convert SN score
		if(is.single){ avg.SN <- pepSN}else{avg.SN <- rowMeans(pepSN)}
		
		
		avg.SN2 <- avg.SN
		avg.SN2[ avg.SN <= 3] <- 1
		avg.SN2[ avg.SN > 3 & avg.SN <= 4] <- 2
		avg.SN2[ avg.SN > 4 & avg.SN <= 5] <- 3
		avg.SN2[ avg.SN  == 5] <- 4
		
		foo <- data.frame("peakFreq" = avg.num.peaks, "avg.catSN" = avg.SN, "score" = avg.SN2)
		foo <- cbind(peptide.index, protein.id, foo)
		

		tmp.tbl <- table(foo$score)
		names(tmp.tbl)[names(tmp.tbl) == "4"] <- "great (cat.SN = 5)"
		names(tmp.tbl)[names(tmp.tbl) == "3"] <- "quant (4 < cat.SN < 5)"
		names(tmp.tbl)[names(tmp.tbl) == "2"] <- "detect (3 < cat.SN < 4)"
		names(tmp.tbl)[names(tmp.tbl) == "1"] <- "noise (cat.SN <= 3)"
		percent.labs <- round(100*tmp.tbl/sum(tmp.tbl) , 1)

		labs <- paste(names(tmp.tbl), ": ", tmp.tbl, "( ", percent.labs , "%)", sep= "")
	


		cols <- c("red", "darkorange3", "gold", "green4")
		cols2 <- cols[tmp.tbl > 0]	

		bar.graph <- barchart(peakFreq ~ peptide.index | protein.id, groups= factor(score), 
				data = foo, ylim = c(-0.2, 5.8),  
				layout = c(10, num.r), ylab = "Number of detected peaks", xlab = "Peptides", 
				stack = TRUE,  col = cols2,   main = paste(main.title, " (", (percent.labs[length(cols2)]+percent.labs[length(cols2)-1]), " %)", sep = ""), 
				auto.key = list(space = "top", columns = 1, col = cols2[length(cols2):1], 
				text = labs[length(cols2):1], rectangles = FALSE,  font = 2, cex =2))
	
		bar.graph
		
}

