sample.info <-
function(transition.output){

	sample.nms <- colnames(transition.output$data$SignalToNoise)


	cat("Do you want to import the sample information file? \n")
	make.mat <- readline("If so, enter [y] or [Y] (Otherwise, hit ENTER. The sample infomation will be generated from Multiquant output.): \n")

	if((make.mat %in% c("y", "Y"))){

		readline <- ("If you would like to import the sample information (text file), please hit ENTER")
		
		cat("Choose the text file containing the sample information:\n")
		sample.file <- file.choose()

		sample.info.read <- read.delim(sample.file, stringsAsFactors = FALSE)
		rownames(sample.info.read) <- sample.info.read[,1]

		if(any(is.na(match(sample.info.read[,1], sample.nms)))){
			stop("Sample names in the sample information file and multiquant data file do not match each other. \n")
		}

		sample.info <- sample.info.read[sample.nms, ]

	}else{	

		sample.nms.split <- strsplit(sample.nms, "_")
		biorep <- sapply( sample.nms.split , function(x){ind2 <- length(x)-1; paste(x[c(2,ind2)], collapse = "_")})	
		techrep <- paste(biorep, sapply(sample.nms.split, function(x){x[length(x)]}), sep = "_")
		unique.biorep <- unique(biorep)

		sample.info <- cbind("sample.nms" = sample.nms, "biorep" = biorep, "techrep" = techrep)
	}

	print(as.data.frame(sample.info))
	sample.info

}

