graphics.transition.out <-
function(graphicsTransitionObj){

	nms <- names(graphicsTransitionObj)


	for(i in 1:length(nms)){

		pdf(paste(nms[i], ".pdf", sep = ""), height = 8, width = 14)
			
		for(j in 1:length(graphicsTransitionObj[[i]])){

			print(graphicsTransitionObj[[i]][[j]])
		}		

		dev.off()

	}



}

