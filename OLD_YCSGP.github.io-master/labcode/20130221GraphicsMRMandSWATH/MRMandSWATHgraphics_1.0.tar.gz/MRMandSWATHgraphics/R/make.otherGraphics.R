make.otherGraphics <-
function(transition.output, sample.info.mat){



	# make various transition-level graphics
	# get sample information
	sample.nms <- sample.info.mat[, "sample.nms"]
	biorep <- sample.info.mat[, "biorep"]
	techrep <- sample.info.mat[, "techrep"]
	unique.biorep <- unique(biorep)


	num.unique.samples <- length(unique.biorep)



	RT.obs <- transition.output$data$RT.obs
	Area <- transition.output$data$Area
	SignalToNoise <- transition.output$data$SignalToNoise

	num.samples <- ncol(Area)

	colnames(RT.obs) <- colnames(Area) <- colnames(SignalToNoise) <- techrep


	### Observed RT
	RT.df <- stack(data.frame(RT.obs))
	RT.df$med <- rep( apply(RT.obs, 1, median), num.samples)



	g3.all <- xyplot((values-med) ~ med, groups= ind, 
				data = RT.df, col = rainbow(num.samples +2), type = c("g", "p"), 
				xlab= "Median Retention Time", ylab = "Observed - Median", main = "All Transitions")
				
				
	max.range <- quantile(RT.df$values - RT.df$med, prob = c(0.1, 0.9), na.rm = TRUE)
	
	g3.sub <- xyplot((values-med) ~ med, groups= ind, 
				data = subset(RT.df,   ( values - med > max.range[1]  & values-med < max.range[2])), col = rainbow(num.samples +2), type = c("g", "p"), 
				xlab= "Median Retention Time", ylab = "Observed - Median", main = "90% Transitions")
			
	
	## normalized group area ratio
	
	Area2 <- log2(Area); 
	dst <- dist(t(Area2)) ; if(num.samples > 2){ hh <- hclust(dst, method = "average")}; 
	
	
	Area.norm <- normalize.quantiles(Area2)
	colnames(Area.norm) <- colnames(Area2)
	
	dst2 <- dist(t(Area.norm)) ; if(num.samples > 2){ hh2 <- hclust(dst2, method = "average")}; 
	
	
	if (num.samples > 1){cor_non_norm.mat <- cor(Area2, use = "pair")}
	if(num.samples > 1){cor.mat <- cor(Area.norm, use = "pair")}
	


	RT.ord <- g3.RT <- list()
	
 	for(k in 1:length(unique.biorep)){ 
		ind.sample <- which(biorep == unique.biorep[k])
		if(length(ind.sample) > 1){RT.ord[[k]] <-  table(apply(t(apply(RT.obs[,ind.sample], 1, rank)), 1, function(x){paste(x, collapse = ", ")}))}
	
		g3.RT[[k]] <- barchart(RT.ord[[k]], main = unique.biorep[k])

	}









	pdf("otherGraphics.pdf", height = 8, width = 12)
		print(g3.all);print(g3.sub); 
		
	 	plot(log10(values) ~ ind , stack(data.frame(SignalToNoise)), col = rep(rainbow( (ncol(SignalToNoise) %/% 3)+1), each = 3), main = "Overall signal.to.noise across all the transitions", ylab = "log10(Signal.To.Noise)")
	
	
	
		plot(log2(values) ~ ind, stack(data.frame(Area)), col = rep(rainbow( (ncol(SignalToNoise) %/% 3)+1), each = 3), main = "Peak area across all the transitions, BEFORE normalization", xlab = "log2(Peak Area)")

	
		plot(log2(values) ~ ind, stack(data.frame(Area.norm)), col = rep(rainbow( (ncol(SignalToNoise) %/% 3)+1), each = 3), main = "Peak area across all the transitions, AFTER quantile normalization",  ylab = "log2(Peak Area)")

	
					
		 if(num.samples > 2){plot(hh, main = "Area BEFORE quantile normalization"); plot(hh2, main = "Area AFTER quantile quantile normalization")}
		
		if(num.samples > 1){
heatmap.2(cor_non_norm.mat, dendrogram = "none", main = "Heatmap Before quantile normalization", Colv = FALSE, Rowv= FALSE, trace= "none", col =grey((15:3)*0.05), 
			colsep = (1:	num.unique.samples)*3,  rowsep = (1:	num.unique.samples)*3, margins=c(20,15)+0.1, cexRow = 1, cexCol = 1);
heatmap.2(cor.mat, dendrogram = "none", main = "Heatmap AFTER quantile normalization", Colv = FALSE, Rowv= FALSE, trace= "none", col =grey((15:3)*0.05), colsep = (1:	num.unique.samples)*3,  rowsep = (1:	num.unique.samples)*3, margins=c(20,15)+0.1, cexRow = 1, cexCol = 1)
}
		
		if(length(g3.RT) >= 1){
			for(i in 1:length(g3.RT)){
				print(g3.RT[[i]], more = TRUE,  split = c(  (i +2)%% 3 + 1,  (i-1) %/% 3 +1    , 3, ceiling(length(g3.RT)/ 3))) 
	
			}
		}
		



	dev.off()
	

	

	
}

