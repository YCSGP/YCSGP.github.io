read.multiquant <-
function(data.file){

	### read data file as a data frame #####################################
	### N/A is considered as a missing value
 
	dd <- read.delim(data.file, stringsAsFactors  = FALSE, na.strings = c("NA", "N/A"))



	## I had a trouble with Signal...Noise column name, 
    ## so I transformed it to Signal.Noise
	c.nms <- colnames(dd)
	c.nms <- strsplit(c.nms, "")

	ind1 <- which(sapply(c.nms, function(x){paste(x[1:6], collapse = "") == "Signal"   & paste(x[10:14], collapse = "") == "Noise"}))

	colnames(dd)[ind1] <- "Signal.Noise"


	## check num.transitions and file names..

	if(is.null(dd$Original.Filename)){  # may need to change this to sample index!!
		warning("Original file names are missing, can't check for duplicated sample names. \n\n", immediate. = TRUE)
	}else{

		tbl.sample.file <- table(dd$Sample.Name, dd$Original.Filename)
		if( length( unique(tbl.sample.file[tbl.sample.file > 0]) ) > 1 ){   
		
			tmp <- t(t(table(paste( dd$Original.Filename, ":", dd$Sample.Name, ":"))))
			colnames(tmp) <- "number of transitions"
			print(tmp)
		
			stop("Number of transitions per Original.Filename/Sample is DIFFERENT!  Please check the input file!")
		}
	
	
		tbl.sample.file2 <- table(dd$Sample.Name, dd$Original.Filename)
		ind.dup <- which(rowSums(tbl.sample.file2 > 0) > 1)
	
		cat("Hit ENTER to check for duplicated sample names")
		readline()

		if(  length(ind.dup) > 0 ){ 
			
			cat("Some sample names are duplicated. Do you want to switch the sample names automatically? (y/n) \n")	
			answer.dup <- readline()

			if(answer.dup == "n"){stop("Please check the input file for duplicated sample names..\n")
			}else{		
		
				dd$Sample.Name2 <- dd$Sample.Name

				# automatic switch
				for(i in 1:length(ind.dup)){
		
					ind.dup2 <- which(tbl.sample.file2[ind.dup[i], ] > 0)
					cat(  paste( names(ind.dup)[i], "is Duplicated: \n", paste(names(ind.dup2), collapse = ", ") ))
					cat("\n \n")
		
		
			
					for(j in 2:length(ind.dup2)){
						
						ind.dup3 <- which(dd$Sample.Name == names(ind.dup)[i]  & dd$Original.Filename == names(ind.dup2)[j]  )
						new.nms <- paste(names(ind.dup)[i], ": DUP", j, sep = "")
					
						cat(paste( "Sample Name: ",  names(ind.dup)[i], "from File: ", names(ind.dup2)[j], "\n will be switched to: \n ", new.nms, "\n \n") )
						dd$Sample.Name[ind.dup3] <- new.nms

					} # end of for j from 2 to length(ind.dup2)
				} # end of i from 1 to length(ind.dup)			
			}# end of else statement
		} # end of !is.null(ind.dup)
	}# end of !is.null(original file name)
	
	dd

}

