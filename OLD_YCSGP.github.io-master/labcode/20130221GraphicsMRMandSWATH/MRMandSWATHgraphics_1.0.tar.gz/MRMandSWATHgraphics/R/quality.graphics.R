quality.graphics <-
function(peptide.output, is.labeled = FALSE,
			 name.option, chart.option = "b", add.title = NULL, sample.info.mat){


	# make various transition-level graphics
	# get sample information
	sample.nms <- sample.info.mat[, "sample.nms"]
	biorep <- sample.info.mat[, "biorep"]
	techrep <- sample.info.mat[, "techrep"]
	unique.biorep <- unique(biorep)



	if(!is.labeled){
		peptide.output2 <- peptide.output		
		protein.id1 <- peptide.output2$info$protein.id
		peptide.index1 <- peptide.output2$info$peptide.index

	}else{ 
		peptide.output2 <- peptide.output$labeled
		protein.id1 <- peptide.output2$info$protein.id.unlabeled
		peptide.index1 <- peptide.output2$info$peptide.index.labeled
		labeled.label <- peptide.output2$info$label
	}



	peptide.catSN <- peptide.output2$catSN
	freq.peaks <- peptide.output2$peakFreq

	# get sample information
	sample.nms <- colnames(peptide.output2$catSN)
	sample.nms.split <- strsplit(sample.nms, "_")
	biorep <- sapply( sample.nms.split , function(x){ind2 <- length(x)-1; paste(x[c(2,ind2)], collapse = "_")})	
	techrep <- paste(biorep, sapply(sample.nms.split, function(x){x[length(x)]}), sep = "_")
	unique.biorep <- unique(biorep)

	sample.info <- list("biorep" = biorep, "techrep" = techrep)

	
	##############################################################################
	## make a bar chart for both biorep and techrep level ########################
    ##############################################################################
	g2 <- g2.sample <- list()	

 	if(chart.option %in% c("g", "b")){
 	
 		if(!is.labeled){
		
			for(k in 1:length(unique.biorep)){
		
				ind.sample <- which(biorep == unique.biorep[k])

				num.r <- length(unique(protein.id1)) %/% 10 + 1			

				barchart.obj <- make.barchart(protein.id = protein.id1, peptide.index = peptide.index1, pepSN = peptide.catSN[, ind.sample], 
						peakFreq = freq.peaks[, ind.sample], main.title = paste(add.title, unique.biorep[k], ": Average categorized S/N"), num.r = num.r)
			
				g2[[k]] <- barchart.obj
			}
		}else{

		
			for(k in 1:length(unique.biorep)){
		
				g2[[k]] <- list()
				ind.sample <- which(biorep == unique.biorep[k])
			

				ind.light <- labeled.label == "light"

				num.r <- length(unique(protein.id1[ind.light])) %/% 10 + 1			

				barchart.obj.light <- make.barchart(protein.id = protein.id1[ind.light], 
						peptide.index = peptide.index1[ind.light], pepSN = peptide.catSN[ind.light, ind.sample], 
						peakFreq = freq.peaks[ind.light, ind.sample], num.r = num.r,
						main.title = paste(add.title, unique.biorep[k], ": Average categorized S/N (LIGHT)"))
			
				barchart.obj.heavy <- make.barchart(protein.id = protein.id1[!ind.light], 
						peptide.index = peptide.index1[!ind.light], pepSN = peptide.catSN[!ind.light, ind.sample], 
						peakFreq = freq.peaks[!ind.light, ind.sample], num.r = num.r,
						main.title = paste(add.title, unique.biorep[k], ": Average categorized S/N (HEAVY)"))
			
				g2[[k]][[1]] <- barchart.obj.light

				g2[[k]][[2]] <- barchart.obj.heavy
			}

		}

	
	}


	

	if(chart.option %in% c("s", "b")){
	
	
 		if(!is.labeled){
		
			for(k in 1:length(techrep)){
		
				ind.sample <- k

				num.r <- length(unique(protein.id1)) %/% 10 + 1			

				barchart.obj <- make.barchart(protein.id = protein.id1, peptide.index = peptide.index1, pepSN = peptide.catSN[, ind.sample], 
						peakFreq = freq.peaks[, ind.sample], main.title = paste(add.title, techrep[k], ": Average categorized S/N"), num.r = num.r)
			
				g2.sample[[k]] <- barchart.obj
			
			}

		}else{

		
			for(k in 1:length(techrep)){
		
				ind.sample <- k
				g2.sample[[k]] <- list()

				ind.light <- labeled.label == "light"

				num.r <- length(unique(protein.id1[ind.light])) %/% 10 + 1			

				barchart.obj.light <- make.barchart(protein.id = protein.id1[ind.light], 
						peptide.index = peptide.index1[ind.light], pepSN = peptide.catSN[ind.light, ind.sample], 
						peakFreq = freq.peaks[ind.light, ind.sample], num.r = num.r,
						main.title = paste(add.title, techrep[k], ": Average categorized S/N (LIGHT)"))
			
				barchart.obj.heavy <- make.barchart(protein.id = protein.id1[!ind.light], 
						peptide.index = peptide.index1[!ind.light], pepSN = peptide.catSN[!ind.light, ind.sample], 
						peakFreq = freq.peaks[!ind.light, ind.sample], num.r = num.r,
						main.title = paste(add.title, techrep[k], ": Average categorized S/N (HEAVY)"))
			
				g2.sample[[k]][[1]] <- barchart.obj.light

				g2.sample[[k]][[2]] <- barchart.obj.heavy

			}
	
		}

	}

	list("group" = g2, "sample" = g2.sample, "labeled" = is.labeled, "height" = num.r)

}

