library(lattice)
library(MASS)
library(affy)
library(limma)



transition.weights <-
function(mrm.data){

	
	if(  !all(   c("Protein", "Peptide", "Transition") %in% colnames(mrm.data) )  ){stop("Transition names are not in an appropriate format. \n")}
	
	if(  !( "Weights" %in% colnames(mrm.data))){ stop("Peak weights does not exist. \n ")}
	
	if(  !( "Sample" %in% colnames(mrm.data))){ stop("SampleName does not exist. \n ")}

	component.name <- paste( mrm.data$Protein, mrm.data$Peptide, mrm.data$Transition, sep = "::" )

	med.weights <- tapply( mrm.data$Weights, INDEX = component.name, median, na.rm = TRUE)
	q3.weights <-  tapply( mrm.data$Weights, INDEX = component.name, quantile, prob = 0.75,  na.rm = TRUE)
	q1.weights <-  tapply( mrm.data$Weights, INDEX = component.name, quantile, prob = 0.25,  na.rm = TRUE)

	tmp.name <- strsplit(names(med.weights), "::")
	
	
	
	
	res <- data.frame("Protein" = sapply(tmp.name, function(x){x[1]}),
								"Peptide" = sapply(tmp.name, function(x){x[2]}),
								"Transition" = sapply(tmp.name, function(x){x[3]}), 
								"Median.Weights" = med.weights, 
								"IQR.Weights" = q3.weights - q1.weights, 
								stringsAsFactors = FALSE)								
				
     res			

}
