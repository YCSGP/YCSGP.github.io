library(lattice)
library(MASS)
library(affy)
library(limma)



normalize.area <-
function(mrm.data, method = c("Global.Median", "IS.Median", "Quantile", "CyclicLoess", "RankInv"), IS = NULL){


	if(  !all(   c("Protein", "Peptide", "Transition") %in% colnames(mrm.data) )  ){stop("Transition names are not in an appropriate format. \n")}
	
	if(  !( "Area" %in% colnames(mrm.data))){ stop("Peak Area does not exist. \n ")}
	
	if(  !( "Sample" %in% colnames(mrm.data))){ stop("SampleName does not exist. \n ")}



	component.name <- paste( mrm.data$Protein, mrm.data$Peptide, mrm.data$Transition, sep = "::" )
	sample.name <- mrm.data$Sample

	component.id <- unique(component.name)
	sample.id <- unique(sample.name)
	
	Area <- matrix(NA, nr = length(component.id), nc = length(sample.id))
	rownames(Area) <- component.id
	colnames(Area) <- sample.id
	
	
	for(i in 1:ncol(Area)){
		
		ind1 <- which( sample.name == sample.id[i] )
		area.ind1 <- mrm.data$Area[ ind1]
		names(area.ind1) <- component.name[ind1]
			
		Area[ component.name[ ind1], i ] <- area.ind1
	}
	
		
	log2.area <- log2(Area)
	
	if(method == "Global.Median"){
		
		med.factor <- 		apply(log2.area, 2, median, na.rm = TRUE)  - median(log2.area, na.rm = TRUE)
		norm.area <- t(  t(log2.area) - med.factor )
		
	}else if(method == "Quantile"){
		
		norm.area <- normalize.quantiles( log2.area )
		
	}else if(method == "CyclicLoess"){
		
		norm.area <- normalizeCyclicLoess(log2.area)
		
	}else if(method == "RankInv"){
		
		
		
		norm.area <- log2.area
		norm.area[,] <- NA
		area.ref <- apply(log2.area, 1, median, na.rm = TRUE)
		inv.set <- list()

		for(j in 1:ncol(norm.area)){

			y1 <- log2.area[,j]
			ind.na <- is.na(y1)

			ref1 <- area.ref[ !ind.na ]
			yy1 <- y1[ !ind.na ]

			foo <- normalize.invariantset(data = yy1, ref = ref1, prd.td = c(0.003, 0.007))
			foo2 <- approx(foo$n.curve$y, foo$n.curve$x, xout = yy1, rule = 2)$y 

			inv.set[[j]] <- foo$i.set

			norm.area[ names(yy1), j ] <- foo2

		}

	}else if(method == "IS.Median"){
		
		
		is.peps <- NULL
		for(j in 1:length(IS)){
			
			is.peps <- c(is.peps, grep(IS[j], rownames(Area)))
			
		}
		
		if(is.null(is.peps)){ 
			
			stop("No Internal Standard Peptide is specified.\n")
			norm.area <- NA
		
		}else{ 
			
			area.IS <- log2( Area[is.peps, ]  )
		
			med.factor <-  apply(area.IS, 2, median, na.rm = TRUE) - median(area.IS, na.rm= TRUE)

			norm.area <- t(t(log2.area) - med.factor)

		}
		
		
	}
	
	
	
	norm.area
	
	
}
