library(lattice)
library(MASS)
library(affy)
library(limma)



calc.NUSE <-
function(mrm.data, graph = TRUE){
	
	if(  !all(   c("Protein", "Peptide", "Transition") %in% colnames(mrm.data) )  ){stop("Transition names are not in an appropriate format. \n")}
	
	if(  !( "Weights" %in% colnames(mrm.data))){ stop("Peak weights does not exist. \n ")}
	
	if(  !( "Sample" %in% colnames(mrm.data))){ stop("SampleName does not exist. \n ")}

	peptide.name <- paste( mrm.data$Protein, mrm.data$Peptide, sep = "::" )
	sample.name <- mrm.data$Sample

	id1 <- paste(peptide.name, sample.name, sep = "__")

	## calculate summed weight for each peptide
	WW <- tapply( mrm.data$Weights, INDEX = id1 , sum, na.rm = TRUE)
	WW <- 1/sqrt(WW)
	
	WW.peptide.id <- sapply( strsplit(names(WW), "__") , function(x){x[1]} )
	
	
	
	
	med.WW <- tapply(WW, INDEX = WW.peptide.id, median , na.rm = TRUE)
	med.WW.aug <-med.WW[ WW.peptide.id ]
	
	nuse <- WW/med.WW.aug
	
	sample.name.nuse <- sapply( strsplit(names(nuse), "__"), function(x){x[2]} )
	peptide.name.nuse <- sapply( strsplit(names(nuse), "__"), function(x){x[1]} )


	if(graph){
		
		
		plot(nuse ~ as.factor(sample.name.nuse), xlab = "Samples", ylab = "NUSE", ylim = c(0, 2))
		
	}



	res <- data.frame("Protein" = sapply(strsplit(peptide.name.nuse, "::"), function(x){x[1]}),
								"Peptide" = sapply(strsplit(peptide.name.nuse, "::"), function(x){x[2]}),
								"Sample" = sample.name.nuse, 
								"NUSE"  = nuse, stringsAsFactors = FALSE)

	res

	
}
