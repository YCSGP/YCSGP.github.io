library(lattice)
library(MASS)
library(affy)
library(limma)



calc.weight <-
function(mrm.data, graph = "Transition_Weights.pdf"){
	

  ## Weight calculation to assess the quality of each peak

	if(  !all(   c("Protein", "Peptide", "Transition") %in% colnames(mrm.data) )  ){stop("Transition names are not in an appropriate format. \n")}
	
	if(  !( "Area" %in% colnames(mrm.data))){ stop("Peak Area does not exist. \n ")}
	
	if(  !( "Sample" %in% colnames(mrm.data))){ stop("SampleName does not exist. \n ")}

	
	tmp.data <- mrm.data
	tmp.data$wts <- rep(NA, nrow(tmp.data))
	
	peptide.name <- paste(tmp.data$Protein, tmp.data$Peptide, sep = "::") 
	peptide.id <- unique(peptide.name)
	num.peps <- length( peptide.id )
	
	rownames(tmp.data) <-  paste(tmp.data$Protein, tmp.data$Peptide, tmp.data$Transition, tmp.data$Sample, sep = "::") 
	
	tmp.data$peptide.name <- peptide.name
	
	
	for(i in 1:num.peps){
		
			sub <- subset(tmp.data, peptide.name == peptide.id[i])
		

			sub$Area[ sub$Area <= 0 ] <- NA
			
			sub <- subset(sub, !is.na(Area))
	
	
			m1 <- rlm( log2(Area) ~ as.factor(Sample) + as.factor(Transition), sub, maxit = 50)
	
			sub$wts <- m1$w
			tmp.data[ rownames(sub) , ]$wts <- sub$wts

	}	
		
		
		
		
	
	
	if(!is.null(graph)){
		
		pdf(graph, height = 5, width = 5)
			
	    for(i in 1:num.peps){
					
				sub <- subset(tmp.data, peptide.name == peptide.id[i])
				
				plot( wts ~ as.factor(Transition), sub, xlab = "Transition", main = peptide.id[i])								
				
		 }
			
	   dev.off()
			
		
	}
	
		
		
	mrm.data$Weights <- tmp.data$wts
	
	mrm.data
	
}
