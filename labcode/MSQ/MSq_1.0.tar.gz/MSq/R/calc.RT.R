library(lattice)
library(MASS)
library(affy)
library(limma)



calc.RT <-
function(mrm.data, graph = TRUE){
	
	## calculate median, CV, adj CV of Retention Time for each transition
	
	if(  !all(   c("Protein", "Peptide", "Transition") %in% colnames(mrm.data) )  ){stop("Transition names are not in an appropriate format. \n")}
	
	if(  !( "RetentionTime" %in% colnames(mrm.data))){ stop("Retention Time does not exist. \n ")}
	
	if(  !( "Sample" %in% colnames(mrm.data))){ stop("SampleName does not exist. \n ")}

	
	
	component.name <- paste( mrm.data$Protein, mrm.data$Peptide, mrm.data$Transition, sep = "::" )
	sample.name <- mrm.data$Sample
		
	RT <- mrm.data$RetentionTime
	
	med.RT <- tapply(RT, INDEX = component.name, median, na.rm = TRUE)

	med.RT.aug <- med.RT[ component.name ]
	
	
	if(graph){

	
		RT.dev <- RT - med.RT.aug
	
	
		mrm.data$RT.dev <- RT.dev
		mrm.data$RT.med <- med.RT.aug

		num.samples <- length(unique(sample.name))
		cols <- rainbow(num.samples + 3)[ 1:num.samples] 
		rt.plot <- xyplot(  RT.dev ~ RT.med , groups =  Sample, mrm.data,  
						col = cols, type = c("g", "p"), 
						xlab = "Median RT (mins) for each transition", ylab = "RT deviation from the median",
						main = "Retention Time Analysis", auto.key = list(space = "right", col = cols, type = "n"))
						
		print(rt.plot)
	
	}
	
	# original CV
	cv.RT <- tapply( RT , INDEX = component.name, function(x){ sd(x, na.rm = TRUE) / mean(x, na.rm = TRUE)})
	
	# adjusted CV
	med.factor <- tapply(RT, INDEX = sample.name, median, na.rm = TRUE) - median(RT, na.rm = TRUE)
	med.factor.aug <- med.factor[ sample.name ]
	
	adj.RT <- RT - med.factor.aug
	
	adj.cv.RT <- tapply( adj.RT , INDEX = component.name, function(x){ sd(x, na.rm = TRUE) / mean(x, na.rm = TRUE)})

	tmp.name <- strsplit(names(cv.RT), "::")
	
	res <- data.frame("Protein" = sapply(tmp.name, function(x){x[1]}),
								"Peptide" = sapply(tmp.name, function(x){x[2]}),
								"Transition" = sapply(tmp.name, function(x){x[3]}), 
								"Median.RT" = med.RT, 
								"Original.CV" = cv.RT,
								"Adj.CV" = adj.cv.RT, stringsAsFactors = FALSE)
								
								
								
	res
	
	
	
}
