
#include <math.h>
#include<stdio.h>
#include<time.h>
#include<stdlib.h>
#include<conio.h>
#include <math.h>
#include <stdio.h>
#include <iostream.h>
#define NP 4
#define MP 5
#define ftol 1.0e-7

//==========declaration of globe variable====================
int MU,M,*m,*K,sampleD,sampled; //the array with m[i] is the allelic number of mark i
              // K[index] is the number of haplotype with index
int *HH;//HH[k]the number index of kth haplotype in the dataset 
long N,  A0; //number of total possible haplotype
int maxA, ancindex;//maxmum number of allele
double *m1;//the distance of M markers from origin
double *ttran;
double *Fret,//pr(H(k,k+1))=Fret[k+M*H[k+1]+M*maxA*H[k]]
      *Fre;//Pr(H(k))=Fre[k+M*H[k])
long RX,RY,RZ;
char filename[50];
int Dhap; //number of distinct disease haplotype
int Nhap; //number of distinct normal haplotype
int indiallele; //=0 means file contain normal haplotype =1 mean only contain allele frequency.
double *Dist;//the location of markers in kb

/*=========declaration of subfunction======*/
long INdex(int*);
void Arrayindex( long, int *);
double likelihood(double *);
double ** matrix( int, int, int,int);
double * dvector(int ,long );
int * ivector(int,int);
void free_ivector(int *,int,int);
void free_dvector(double *,int,int);
void free_matrix(double **,int , int , int , int );
void nrerror(char *);
void transition();//give the value of mutation matrix
void read_pre();//read the value of m, m1, A0, maxA,
void read_hap();// read haplotype data and give the vulue of HH, K,Fret,Fre,sampleD
void amoeba(double**,double[],int,double,double (*likelihood)(double []),int *);
void pass_char(FILE *p,int length);
void pass_line(FILE *p, int noline);
double correlation(int N0, int N1, int T, int sample);
double rand1();

/*==========================================*/

main()
{

 /*========declararion of local variable====*/
FILE  * p1,*p2;
long ancindex0; //the number coordinate of haplotype
int  *H,mmm,i,ix,i1,i2,*nfunc, ndim;
	 // K[index] is the number of haplotype with index
double  aa,**IP ,*likeli, likeli0,x0,*para,bx;//**IP0;	  
int tou0,ianc;
//====================================================        
RX=RY=RZ=1;
    MU=29;
    read_pre();//read the value of m,m1,A0, maxA
    H=ivector(0,M);
	K=ivector(0,A0-1);
    Fret=dvector(0,M*maxA*maxA-1);
	Fre=dvector(0,M*maxA-1);
	HH=ivector(0,A0-1);
	read_hap();
	ttran=dvector(0,MU*N*M*maxA*maxA);
    transition();

likeli=dvector(1,MP);
IP=matrix(1,MP,1,NP);
//IP0=matrix(1,MP,1,NP);
para=dvector(1,NP);
nfunc=ivector(0,0);
ndim=NP;
x0=0;ancindex0=0;likeli0=1000000.0;

 //p1=fopen("e:\\ldmapping\\initial2.txt","r");
   //       if(p1==NULL){
     //    	printf("can't open the file initial2.txt");
       //    exit(1);}

           for(i=1;i<=NP;i++)
		   {//fscanf(p1,"%lf",&para[i]);
			   para[i]=0.1;
		   }
		   //fclose(p1);

		  for(i1=1;i1<=MP;i1++)
			{
            	for(i2=1;i2<=NP;i2++)
				{IP[i1][i2]=para[i2];
				}	             
   			}
  mmm=0;
 for(ianc=0;ianc<sampleD;ianc++)
	   
	   {ancindex=HH[ianc]; 
         mmm++;
		 printf("ancestral haplotype=%d\n",mmm);
  
  
	   
		    for(i=1;i<=NP;i++)
		    {
			  if(IP[i+1][i]<=0.5)IP[i+1][i]=IP[i+1][i]+0.4;
			  else IP[i+1][i]=IP[i+1][i]-0.4;
		     }
	  
	    
	    for(i1=1;i1<=MP;i1++)
		{        
		  likeli[i1]=likelihood(IP[i1]);
	
		 }
		  amoeba(IP,likeli,ndim,ftol,likelihood,nfunc);
	     
		  aa=likelihood(IP[1]);
		  if(likeli0>aa)
		  {
			  likeli0=aa;
		      for(i=1;i<=NP;i++)
			  {para[i]=IP[1][i];}
		      ancindex0=ancindex;
		  }
	   }
p2=fopen("result.out","w"); 
printf(" estimated parameter are\n");
fprintf(p2," estimated parameter are\n");
tou0=(int)(para[3]*N);
bx=para[4]*m1[M-1]*100000+Dist[0];
printf(" location=%4.3lf\n Disease mutation age=%d \n p=%lf\n",  bx,tou0 ,para[1]/4);
fprintf(p2," location=%4.3lf, \n Disease mutation age=%d \n p=%lf\n",  bx,tou0 ,para[1]/4);

Arrayindex(ancindex0,H);
printf(" ancestor haplotype=");
fprintf(p2," ancestor haplotype=");

for(i=1;i<=M;i++)
{printf("%d,",H[i-1]+1);
 fprintf(p2,"%d,",H[i-1]+1);
}
printf("\n"); 
 ancindex=ancindex0;
fclose(p2);

p1=fopen("location.txt","w");
 likeli0=1000000.0;
 fprintf(p1,"location (kb)    log(likelihood)\n");
for(ix=1;ix<1000;ix++)
{para[4]=ix*1.0/1000.0;
     aa=likelihood(para);
    bx=para[4]*m1[M-1]*100000+Dist[0];
	fprintf(p1,"%lf    %lf\n",bx,-aa);
	if(aa<likeli0) 
	{likeli0=aa;x0=para[4];}
}
fclose(p1);

/*printf("estimated parameter are\n");
tou0=(int)(para[3]*N);
bx=x0*m1[M-1]*100000+Dist[0];

printf("x=%4.3lf,tou=%d, mu=%lf, p=%lf\n",  bx,tou0,para[2]/100,para[1]);
Arrayindex(ancindex0,H);
printf("ancestor haplotype=");
for(i=1;i<=M;i++)printf("%d,",H[i-1]);
*/


free_ivector(m,0,M-1);
free_dvector(m1,0,M-1);
free_ivector(K,0,A0-1);
free_ivector(H,0,M);
free_dvector(Fret,0,M*maxA*maxA-1);
free_dvector(Fre,0,M*maxA-1);
free_dvector(para,1,NP);   
free_ivector(HH,0,A0);
free_ivector(nfunc,0,0);
free_dvector(ttran,0,MU*N*M*maxA*maxA);
free_matrix(IP,1,MP,1,NP);

}


//=====================================
//a subroutine that read (length) number of characters
//===============================
 void pass_char(FILE *p, int length)
 {
	 char ch;
	 int i;
	 for(i=1;i<=length;i++)
	 {
		 ch=getc(p);
	 }
 }

//=====================================
//a subroutine that read (length) number of characters
//===============================
 void pass_line(FILE *p, int noline)
 {
	 char ch;
	 int n;
	 n=0;
	 for(;;)
	 {
		 ch=getc(p);
		 if(ch==10)n++;
		 if(n>=noline) return;
         if(ch==EOF) 
		 {
			 printf("reach unexpected end of file\n");
			 return;
		 }
	 }
 }


/*==============================================
subfunction of transit from array index to number index
of haplotype 
=================================================*/
		
long INdex(int *H)
 //int *H;
{ long index, scale; int i;
 index=H[0]; scale=1;
  for(i=1;i<M;i++)
  {scale=scale*m[i-1];
    index=index+scale*H[i];
  }
return index;
}

/*====================================
function of transiting the number index to arrayindex*/

void Arrayindex(long index, int *H)
//long index;int * H; 
{long scale; int i;
	scale=A0/m[M-1];
 for(i=0; i<M; i++)
 {H[M-i-1]=index/scale;
 index=index-H[M-i-1]*scale;
 if(i<M-1) scale=scale/m[M-i-2];
 }
}
		
/*===============================================*/
		
double likelihood(double para[])
//long ancindex; int *K; double x; double p; double mu; int tou;
{
 int *H1,imu;
 int *Hanc,tou,index1;
 double mu,mu0,mu1,mu2;
 double *mm; 
 long index; int i,j,k,i0;
 double Pr,Pr1,a,b,c,d,a0,c0;
 double x,pp;
//========================================
 pp=para[1]/4;
  mu=para[2]/100.0;
  if(mu<0.0001)imu=(int)(100000*mu);
  else if(mu<0.001) imu=9+(int)(10000*mu);
  else imu=18+(int)(1000*mu);
 tou=(int)(para[3]*N);
 x=para[4]*m1[M-1];
 H1=(int *)(malloc)(M*sizeof(int));
 Hanc=(int *)(malloc)(M*sizeof(int));
 mm=(double*)(malloc)((M+3)*sizeof(double));
 
Arrayindex(ancindex, Hanc); 
i0=-1;
for(i=0;i<M;i++)
{if(x>m1[i]) i0++;
else break;
}


Pr=0;
for (index1=0;index1<sampleD;index1++)
{ 
   index=HH[index1];
     Arrayindex(index,H1);
     Pr1=0;
     
	 if(i0==-1)
	 {    mm[0]=x;
	      mm[M+1]=100.0;
		 for(i=1;i<=M;i++) mm[i]=m1[i-1];
		 for(i=0;i<=M;i++)
		 {mu0=1;
              if(i>=1)
              {for(j=0; j<i;j++) mu0=mu0*ttran[imu+tou*MU+N*MU*j+ N*MU*M*H1[j]+N*MU*M*maxA*Hanc[j]];
			  }		
		      
		  a=1;b=1;
			  /*if(i==M-1) a=Fre[M-1+M*H1[M-1]];
			  else if(i<M-1)
			  {
				  for(k=i;k<M-1;k++) a=a*Fret[k+H1[k+1]*(M-1)+H1[k]*(M-1)*maxA];
			  
			  for(k=i+1;k<M;k++) b=b*Fre[k+M*H1[k]];
			  } */

  
             if(i<M)
			 {for(k=i;k<M;k++) a=a*Fre[k+M*H1[k]];}
              if(b==0)a0=0;
			  else a0=a/b;
			  Pr1=Pr1+exp(-tou*fabs(x-mm[i]))*(1-exp(-tou*fabs(mm[i+1]-mm[i])))*mu0*a0;
			//*Pnull(i,M-1) ;/* Pnull(i,M-1)=1 for i>M-1*/	  
			 
         }
	 }
	 else if(i0==(M-1))
	 {mm[0]=-100;
	  mm[M+1]=x;
	  for(i=1;i<=M;i++) mm[i]=m1[i-1];	  
       for(i=1;i<=M+1;i++)
	   {mu0=1;
	   if(i<M+1)
	   {for(j=i;j<M+1;j++) mu0=mu0*ttran[imu+tou*MU+N*MU*(j-1)+N*MU*H1[j-1]*M+N*MU*Hanc[j-1]*M*maxA];}
	   a=1;b=1;
	   /*if(i==2) a=Fre[M*H1[0]];

			  else if(i>2)
			  {
				  for(k=0;k<i-2;k++) a=a*Fret[k+H1[k+1]*(M-1)+H1[k]*(M-1)*maxA];
			  for(k=0;k<i-3;k++) b=b*Fre[k+M*H1[k]];
			  } 
               */
 
              if(i>1)
			  {for(k=0;k<=(i-2);k++) a=a*Fre[k+M*H1[k]];}
	          if(b==0)a0=0;
			  else a0=a/b;
			  Pr1=Pr1+exp(-tou*fabs(x-mm[i]))*(1-exp(-tou*fabs(mm[i]-mm[i-1])))
		   *mu0*a0;//*Pnull(0,i-2);/* Pnull(0,i-2)=1 for i-2<0*/
	   }
	 }
	 else
	 {mm[0]=-100.0;
	  mm[M+2]=100.0;
	  mm[i0+2]=x;
	  for(i=0;i<=i0;i++) mm[i+1]=m1[i];
	  for(j=i0+1;j<M;j++) mm[j+2]=m1[j];
	  for(i=1;i<=i0+2;i++)
	  {mu1=1;
		  if(i<i0+2)
		  {for(k=i;k<i0+2;k++) mu1=mu1*ttran[imu+tou*MU+N*MU*(k-1)+N*MU*H1[k-1]*M+N*MU*Hanc[k-1]*M*maxA];
		  }
		for(j=i0+2;j<=M+1;j++)
	  {mu2=1;
	   if(j>i0+2)
	   {for(k=i0+3;k<=j;k++)mu2=mu2*ttran[imu+MU*tou+N*MU*(k-2)+N*MU*H1[k-2]*M+N*MU*Hanc[k-2]*M*maxA];
	   }
		  a=1;b=1;c=1;d=1;
/*              if(i==2) a=Fre[M*H1[0]];
			  else if(i>2)
			  {
				  for(k=0;k<i-2;k++) a=a*Fret[k+H1[k+1]*(M-1)+H1[k]*(M-1)*maxA];
		
			  for(k=0;k<i-3;k++) b=b*Fre[k+M*H1[k]];
			  }
			  if(j==M) c=Fre[M-1+M*H[M-1]];
			  else if(j<M)
			  {
				  for(k=j-1;k<M-1;k++) c=c*Fret[k+H1[k+1]*(M-1)+H1[k]*M*maxA];
			  
			  for(k=j;k<M;k++) d=d*Fre[k+M*H1[k]];
			  } */


		  if(i>1)
		  {for(k=0;k<i-1;k++)a=a*Fre[k+M*H1[k]];}
		  if(j<M+1)
		  {for(k=j-1;k<M;k++)c=c*Fre[k+M*H1[k]];}
		  if(b==0)a0=0;
		  else a0=a/b;
		  if(d==0)c0=0;
		  else c0=c/d;
		  Pr1=Pr1+exp(-tou*fabs(mm[j]-mm[i]))*(1-exp(-tou*fabs(mm[i]-mm[i-1])))
			  *(1-exp(-tou*fabs(mm[j+1]-mm[j])))
		   *mu1*mu2*a0*c0;//*Pnull(0,i-2)*Pnull(j-1,M-1);/* Pnull(0,i-2)=1 for i-2<0*/
		}
		  
		}
	  }
	  a=1;b=1;
	 /* for(i=0;i<M-1;i++)
	  {a=a*Fret[i+(M-1)*H1[i+1]+(M-1)*H1[i]*maxA];
	  }
	  for(i=1;i<M;i++)
	  {b=b*Fre[i+M*H1[i]];
	  }*/
	  for(i=0;i<M;i++)a=a*Fre[i+M*H1[i]];
	  if(b==0)a0=0;
	  else a0=a/b;
      
	  Pr1=Pr1*(1-pp)+pp*a0;//*Pnull(0,M-1);
	  Pr=Pr+K[index]*log(Pr1+0.00000000001);
	  
	 }
      

Pr=-Pr;

free(H1);free(mm);free(Hanc);
return Pr;
}
/*=====================================================*/

		  /*==============================================*/
/*function to generate the uniformly distributed sample on (0,1) 

long RX=1,RY=1,RZ=1;
double rand1()
{    double t;
     int t1;
     RX=(171*RX)%30269;
     RY=(172*RY)%30309;
     RZ=(170*RZ)%30323;
     t=(double)(RX/30269.0+RY/30309.0+RZ/30323.0);
     t1=(int)(t);
     return(t-t1);
}*/
//===================================================

  double **matrix(int nrl, int nrh, int ncl, int nch)
/* int nrl,nrh,ncl,nch;*/

{
        int i;
        double **m;

        m=(double **) malloc((unsigned) (nrh-nrl+1)*sizeof(double*));
        if (!m) nrerror("allocation failure 1 in matrix()");
        m -= nrl;

        for(i=nrl;i<=nrh;i++) {
                m[i]=(double *) malloc((unsigned) (nch-ncl+1)*sizeof(double));
                if (!m[i]) nrerror("allocation failure 2 in matrix()");
                m[i] -= ncl;
        }
        return m;
}
//===================================================
 int **imatrix(int nrl, int nrh, int ncl, int nch)
/* int nrl,nrh,ncl,nch;*/

{
        int i;
        int **m;

        m=(int **) malloc((unsigned) (nrh-nrl+1)*sizeof(int*));
        if (!m) nrerror("allocation failure 1 in imatrix()");
        m -= nrl;

        for(i=nrl;i<=nrh;i++) {
                m[i]=(int *) malloc((unsigned) (nch-ncl+1)*sizeof(int));
                if (!m[i]) nrerror("allocation failure 2 in matrix()");
                m[i] -= ncl;
        }
        return m;
}


//=================================================
void free_imatrix(int **m,int nrl, int nrh, int ncl, int nch)

{
        int i;

        for(i=nrh;i>=nrl;i--) free((char*) (m[i]+ncl));
        free((char*) (m+nrl));
}
//===================================================

void free_matrix(double **m,int nrl, int nrh, int ncl, int nch)
/* double **m;
int nrl,nrh,ncl,nch;*/
{
        int i;

        for(i=nrh;i>=nrl;i--) free((char*) (m[i]+ncl));
        free((char*) (m+nrl));
}

//=================================================

void nrerror(char error_text[])
// char error_text[];
{
        void exit(int);

        fprintf(stderr,"Numerical Recipes run-time error...\n");
        fprintf(stderr,"%s\n",error_text);
        fprintf(stderr,"...now exiting to system...\n");
        exit(1);
}
//======================================================
double *dvector(int n1,long n2)
{double *v;
v=(double*)malloc((size_t)((n2-n1+1)*sizeof(double)));
if(!v) nrerror("allocation failure in dvector()");
return v-n1;
}
//==================================================
int * ivector(int n1,int n2)
{int *v;
v=(int*)malloc((size_t)((n2-n1+1)*sizeof(int)));
if(!v) nrerror("allocation failure in dvector()");
return v-n1;
}
//=================================================
void free_dvector(double *v, int n1,int n2)
{free((char*)(v+n1));
}

void free_ivector(int *v, int n1,int n2)
{free((char*)( v+n1));
}

//=====generate the transition matrix of mutation=========
void transition()
{int i,j,k,t,imu,l;
 double *tran,*tran1,*tran2,mu,a1;

tran=dvector(0,M*maxA*maxA);
tran1=dvector(0,maxA*maxA);
tran2=dvector(0,maxA*maxA);

 for(imu=0;imu<MU;imu++)
 {if(imu<10) mu=imu*0.00001;
   else if(imu<19) mu=(imu-9)*0.0001;
	   else mu=(imu-18)*0.001;
  for(k=0;k<M;k++)
   
  {
	if(m[k]>2)
	{
	for(i=0;i<m[k];i++)
	{
		for(j=0;j<m[k];j++)
		{
			if(i==0)
			{if(j==0)tran[k+M*j+M*maxA*i]=ttran[imu+MU*N*k+MU*N*M*j+MU*N*M*maxA*i]=1-mu;
             else if(j==1)tran[k+M*j+M*maxA*i]=ttran[imu+MU*N*k+MU*N*M*j+MU*N*M*maxA*i]=mu;
             else tran[k+M*j+M*maxA*i]=ttran[imu+MU*N*k+MU*N*M*j+MU*N*M*maxA*i]=0;
			}
             else if(i==(m[k]-1))
			 {
				 if(j==(m[k]-1))tran[k+M*j+M*maxA*i]=ttran[imu+MU*N*k+MU*N*M*j+MU*N*M*maxA*i]=1-mu;
                  else if(j==(m[k]-2))tran[k+M*j+M*maxA*i]=ttran[imu+MU*N*k+MU*N*M*j+MU*N*M*maxA*i]=mu;
                  else tran[k+M*j+M*maxA*i]=ttran[imu+MU*N*k+MU*N*M*j+MU*N*M*maxA*i]=0;
			 }
              else
			  {
				  if(j==i)tran[k+M*j+M*maxA*i]=ttran[imu+MU*N*k+MU*N*M*j+MU*N*M*maxA*i]=1-2*mu;
                  else if(abs(i-j)==1)tran[k+M*j+M*maxA*i]=ttran[imu+MU*N*k+MU*N*M*j+MU*N*M*maxA*i]=mu;
                  else tran[k+M*j+M*maxA*i]=ttran[imu+MU*N*k+MU*N*M*j+MU*N*M*maxA*i]=0;
			  }
		}
	}
  
     
     	  for(i=0;i<m[k];i++)
		  {
		     for(j=0;j<m[k];j++)
			 {tran1[j+maxA*i]=tran[k+M*j+M*maxA*i];
			 }
		  }
	  for(t=1;t<N;t++)
	  {
	    for(i=0;i<m[k];i++)
		{
	      for(j=0;j<m[k];j++)
		  {a1=0;
			  for(l=0;l<m[k];l++)
			  {a1=a1+tran[k+M*l+M*maxA*i]*tran1[j+maxA*l];
			  }
			  tran2[j+maxA*i]=a1;
		  }
		}
		for(i=0;i<m[k];i++)
		{
	      for(j=0;j<m[k];j++)
		  {tran1[j+maxA*i]=tran2[j+maxA*i];
           ttran[imu+MU*t+MU*N*k+MU*N*M*j+MU*N*M*maxA*i]=tran1[j+maxA*i];
		  }
		}
        

	  }
  }

 if(m[k]==2)
  { 
	  for(t=0;t<N;t++)
	  {

	       for(i=0;i<m[k];i++)
		   {for(j=0;j<m[k];j++)
		   {
		   if(i==j)ttran[imu+MU*t+MU*N*k+MU*N*M*j+MU*N*M*maxA*i]=1;
		   else ttran[imu+MU*t+MU*N*k+MU*N*M*j+MU*N*M*maxA*i]=0;
		   }
		   }
	  }
  }
  
}
 }
free_dvector(tran,0,M*maxA*maxA);
free_dvector(tran1,0,maxA*maxA);
free_dvector(tran2,0,maxA*maxA);
}
//=============end of transition matrix===================
 
//========reading premary data===========
void read_pre()
{   FILE * p;
	int i;
     p=fopen("parameters.txt","r");
     pass_line(p,1);
	 fscanf(p,"%s",filename);
	 pass_line(p,2);
	 fscanf(p,"%d",&N);
	 pass_line(p,2);
	 fscanf(p,"%d",&M);
	 Dist=dvector(0,M-1);
	 m=ivector(0,M-1);
	 m1=dvector(0,M-1);
	 //printf("M=%d\n",M);
	 //getch();
     pass_line(p,2);
	 for(i=1;i<=M;i=i++)
	 {fscanf(p,"%d",&m[i-1]);
	  //printf("m[%d]=%d\n",i-1,m[i-1]);
	  //getch();
	 }
	 pass_line(p,2);
	 for(i=0;i<M;i++)
	 {
		 fscanf(p,"%lf",&Dist[i]);
		// printf("m1[%d]=%f\n",i,m1[i]);
	  //getch();
	 }
	 pass_line(p,2);
	 fscanf(p,"%d",&Dhap);
	 //printf("Dhap=%d\n",Dhap);
     pass_line(p,2);
	 fscanf(p,"%d",&indiallele);
	 //printf("indiallele=%d\n",indiallele);
	 pass_line(p,2);
	 fscanf(p,"%d",&Nhap);
	 //printf("Nhap=%d\n",Nhap);
     //getch();
	 fclose(p);
    
	 for(i=0;i<M;i++)
	 {m1[i]=(Dist[i]-Dist[0])/100000;
	 }
	
	
	A0=1;maxA=0;
	for(i=0;i<M;i++)
	{A0=A0*m[i];
	if(maxA<m[i]) maxA=m[i];
	}
}
//===========reading haplotype data==========
 
   void read_hap()
   {
	   FILE * p1;
        int *H,**HHH, jj,i,j,k,a,accountd;
	   long index;
	 

	   H=ivector(0,M);
	   HHH=imatrix(0,M,0,Dhap);
	   for(index=0; index<A0;index++)K[index]=0;
	
     	sampleD=0;
	    if((p1=fopen(filename,"r"))==NULL)
		{printf("can't open the file filename\n");
		 exit(0);
		}
	   pass_line(p1,1);
		for(j=1;j<=Dhap;j++)
		{
		    for(i=0;i<=M;i++)
			{
			fscanf(p1,"%d",&H[i]);
			H[i]=H[i]-1;
			}   
			index=INdex(H);
		    K[index]=H[M]+1;
            HH[sampleD]=index;
			sampleD++;
				
           
		}
    	pass_line(p1,2);

	//=caculate the haplotype(two marker) and allele frequency in Normal===
       if(indiallele==0)
	   {
		accountd=0;
	    //p1=fopen("e:\\ldmapping\\haplotyped.txt","r");
    	for(j=0;j<Nhap;j++) 
		{
		   for(i=0;i<=M;i++)
		   {   
		 	fscanf(p1,"%d",&H[i]);H[i]=H[i]-1;
			HHH[i][j]=H[i];
		   }
			accountd+=H[M]+1;   
		}
	     fclose(p1);

          for(k=0;k<M-1;k++)
		  {
			  for(i=0;i<m[k];i++)
			  {
				  for(j=0;j<m[k+1];j++)
  
				  {
					  a=0;
                      //p1=fopen("e:\\ldmapping\\haplotyped.txt","r");
	                  for(jj=0;jj<Nhap;jj++)
					  {
		                   
                       if((HHH[k][jj]==i)&&(HHH[k+1][jj]==j)) a=a+H[M]+1;
		               //ch=getc(p1);
					  }
	                 
                       Fret[k+j*(M-1)+i*(M-1)*maxA]=a*1.0/accountd;
  
				  }
			  }
		  }
  




                for(k=0;k<M;k++)
				{
	               for(i=0;i<m[k];i++)
	                  {
					   a=0;
					   
	                    for(jj=0;jj<Nhap;jj++)
						 {
	
		                       
                              if(HHH[k][jj]==i) a=a+HHH[M][jj]+1;				
						}
	                       
    	                 Fre[k+M*i]=a*1.0/accountd;
				   }	
				}
	   }
     
	   //=======read allele frequency 
	   else
	   {
	    //p1=fopen("e:\\ldmapping\\example\\allelefreq.txt","r");
		for(k=0;k<M;k++)
		{
			for(i=0;i<m[k];i++)
			{
				fscanf(p1,"%lf", &Fre[k+i*M]);
			}
		}
	   }  
		fclose(p1);

       for(k=0;k<M-1;k++)
		{
			for(i=0;i<m[k];i++)
			{
				for(j=0;j<m[k+1];j++)
				{
					Fret[k+(M-1)*j+(M-1)*maxA*i]=Fre[k+M*i]*Fre[k+M*j];
				}
			}
		}

               free_ivector(H,0,M);
			   free_imatrix(HHH,0,M,0,Dhap);
   }
   //======================
 //calculate correlation under conditional coalecent model
 //N0 is  disease population size at present time
 //N1 is  disease population size at ancestral time
 //T is the time from present to ancestral
 //sample is the disease haplotype we used in analysis
double correlation(int N0, int N1, int T, int sample)
{
  double *Ht,T1,b1,b2,sum,sum1, r,r0,aa;	  
  int i,i1;//N0,N1,T,i,i1;
/*
N0=100000;
N1=100;
T=100;
*/
r=log(N0*1.0/N1)/T;

/*N0=2000;
N1=1950;
T=2000;
r=log(N0*1.0/N1)/1000;
*/
r0=r*N0; 
T1=log(2*r0+1)/r0*N0;

Ht=dvector(0,sample);
b1=(exp(r0*(T-2)/N0)-1)/r0;
b2=(exp(r0*(T)/N0)-1)/r0;
sum1=0;
    for(i1=0;i1<1000;i1++)
	{
		printf("i=%d\n",i1);
      for(;;)
	  {
    	sum=0;
	    for(i=0;i<sample-1;i++)
		{
		sum+=-2*log(1-rand1())/((sample-i)*(sample-i-1));
		Ht[i]=(log(r0*sum+1)/r0);
		}
    	if((sum<=b2)&&(sum>=b1))break;
	  }
    
      sum=0;
      for(i=0;i<sample-1;i++)
	  {
		 sum+=(T*1.0/N0-Ht[i])/(T*1.0/N0+Ht[i])/(sample-i)/(sample-i+1);
	  }
	 sum1+=sum;
	}
   aa=sum1*2/1000;
free_dvector(Ht,0,sample);
   return sqrt(1+(sample-1)*aa);
}
//===============
//==============================================
//function to generate the uniformly distributed sample on (0,1) 
//long RX=1,RY=1,RZ=1;
 
 double rand1()
{  //extern RX,RY,RZ; 
	
	 double t;
     int t1;
     RX=(171*RX)%30269;
     RY=(172*RY)%30309;
     RZ=(170*RZ)%30323;
     t=(double)(RX/30269.0+RY/30309.0+RZ/30323.0);
     t1=(int)(t);
     return(t-t1);
}
