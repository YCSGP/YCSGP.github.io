Variable Importance-Weighted Random Forests

This is an R package for variable importance-weighted Random Forests. We modified the original R randomForest package to enable a weighted random feature sampling in Random Forests.

To install the package, type
"install.packages("viRandomForests_1.0.tar.gz")"
in R.

Instructions for functions included in this package can be found in "viRandomForests-manual.pdf".