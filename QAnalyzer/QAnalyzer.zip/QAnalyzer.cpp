

/* This is QAnalyzer 1.0a. This program is writted by Zhong Guan 
based QAmerge 1.0e which was written by Jinming Li. 
In addition to dealing with data set having two channels (dyes) as in 
QAmerge, this program can merge data sets with three (3) or more channels.
Furthermore, the options for normalization--normalization to Median 
and normalization using Lowess Fitted Curves. This Lowess fit 
normalization may count the Dye effects. The user also have option 
to use ANOVA procedure to analyze the gene expresion microarray data.  
More features are coming....
*/

/////////////////////////////////////////////////////////////////////////////////////////
// When WebVersion=0, this program needs manual input of the parameters                //
//      WebVersion=1, this program reads a Tab delimited Text file for parameter input //
/////////////////////////////////////////////////////////////////////////////////////////
#include <conio.h>
#include <stdio.h> 
#include <math.h>   
#include <stdlib.h>
#include <string.h>

#define IA 16807                                 
#define IM 2147483647                            
#define AM (1.0/IM)                              
#define IQ 127773                                
#define IR 2836                                  
#define NTAB 32                                  
#define NDIV (1+(IM-1)/NTAB)                     
#define EPS 1.2e-7                               
#define RNMX (1.0-EPS)                           
#define MAXIT 1000 // 100 won't work for function batacf
#define FPMIN 1.0e-30

long RX=1,RY=1,RZ=1;      
int fcompare (const void * a, const void * b)
{
	if(*(double*)a - *(double*)b>0) return 1;
	else if(*(double*)a - *(double*)b<0) return -1;
	else return 0;
}

void main()
{
	void squeeze(char s[],char c[]), ErrorMessage(char error_text[]);
	double  **dmatrix(int,int,int,int), *dvector(int,int);
	double ***darray(int,int,int,int,int,int);
	void free_darray(double ***,int,int,int,int,int,int);
	char **cmatrix(int,int,int,int), *cvector(int, int);
	void free_cmatrix(char **,int,int,int,int),free_dmatrix(double **,int,int,int,int);
	char ***carray(int,int,int,int,int,int);
	void free_carray(char ***,int,int,int,int,int,int);
	int *ivector(int, int), **imatrix(int,int,int,int);
	void free_ivector(int *, int,int),free_imatrix(int **,int,int,int,int), free_cvector(char *, int, int);
	//void clowess(double *, double *, int , double , int , double , double *, double *, double *);
	void free_dvector(double *, int, int), lowess_normalization(double **, int, int, double, int, double);//, double, int , int);
	double rMean(double *,  int), rMedian(double *,int),fmax2(double,double);
	double std(double *, int);
	void quicksort(double *,int), rPsort(double *,int,int);
	//void lowess(double *,double *,int ,double ,int ,double ,double *,double *,double *);
	int skipLine(FILE *fp, int num),imax2(int,int),imin2(int,int);
	char  chr,temp[50],sYesNo[3], string[50], DataFile[50], LowessFit[3],string1[3];
	int ArrayRows, ArrayColumns, Rows, Columns, ArraySpots, SpotNumber, intmp,l, i,j,k,g,re, cn, rn;
	double doubletmp, ***ChIntensity, ***ChBackground, ***Ratio, ***RepeatRatio, ***MeanRatio, **Filter;
	double f,pct; int nsteps;
	char **GeneName, **FileName, **MergeFile, **ch, ***chnl, ***dye, ***img;
	double **Mean, **Median, **Total, *factor, ***MeanLogIntensity;
	char  ANOVA[3], *UserID,tempID[30], *CaseStr[5]={"Case1","Case2","Case3","Case4","Case5"},*bch, *bb,b[100]; 
	int **Fout, **Gout, **Fnu, **Gnu, **Length, *intemp, *ord;
	double **x,**y,**z,**xx,**lxx, **OverallMean, **LogMean,  **OverallMedian, **Stdev, **LogStdev;
	FILE *fpin[100], *fpout1, *fpout2, *parameter;
	int ArrayNumber, GeneNumber, ChannelNumber, RN, Version;
	/////////////////////////////////////////////
	int WebVersion=0;// WebVersion=1: Used on Web
	/////////////////////////////////////////////
	int st,t, t1, r, r1,  YesNo, nor,**LT, NoDM=1, *ControlChannel, **Case, ci;//ra[10],
	double betai(double, double, double), *Tstat, **Pvalue;//,  **Chnl_lowess;
	void ANOVA4Microarray(int, double ***,int , char **, int , int, int , int **, int*, int**, char *,char [], FILE *);
	void iorder(int *, int , int *);
//	char ChString[5]={"ch1 Intensity","ch2 Intensity","ch3 Intensity","ch4 Intensity","ch5 Intensity"};

	printf("  -----------------------------------------------------------------------\n");
	printf("  -----------------------------------------------------------------------\n");
	printf("        ***      *                                                       \n");
	printf("       *   *    * *                                                      \n");
	printf("      **   **  *   *  *   *    *    *   *   *  *****  ****  ****         \n");
	printf("      **   ** **   ** **  *   * *   *    * *      *   *     *   *        \n");
	printf("       * * *  ******* * * *  *   *  *     *      *    ****  *  *         \n");
	printf("        ***   **   ** *  **  *****  *     *     *     *     * *          \n");
	printf("           *  **   ** *   *  *   *  ****  *    *****  ****  *   *        \n");
	printf("  ------------------------------------------------------------------------");
	printf("\n            Thank you for using QAnalyzer 1.0b.               \n");
	printf("  ------------------------------------------------------------------------");
	printf("\n  This program is designed to perform statistical analysis for \n");
	printf("\n  QuantArray output data sets, and to merge several data sets. \n");
	printf("  ------------------------------------------------------------------------");
	if(WebVersion==0)
	{
		printf("\n\nInput the number of arrays:  ");
	
		scanf("%s",string);
		ArrayNumber = atoi(string);
	
		while (ArrayNumber <= 0) 
		{
		    printf("\n\n\aInvalid Input! You are expected to enter a positive integer!\n\n");
	       printf("Input the number of arrays again:  ");
		    scanf("%s",string);
		    ArrayNumber = atoi(string);
		}    
    	
		printf("\nInput the number of replicated spots in each array:  ");
		scanf("%s",string); 
		r = atoi(string);
	    while (r <= 0) 
		{
		    printf("\n\aInvalid Input! You are expected to enter a positive integer!\n\n");
	       printf("Input the number of replicated spots in each array again:  ");
		    scanf("%s",string);
		    r = atoi(string);
		}  
	
		printf("\n\nHow many channels you have in each array? \n\nPlease enter the NUMBER of CHANNELS:  "); 
		scanf("%s", string);
		ChannelNumber=atoi(string);
		printf("\n\n");

		while (ChannelNumber <= 1 || ChannelNumber >5) 
		{
		    printf("\n\n\aInvalid Input! \n\n");
		    printf("\n\nYou are expected to enter an integer greater than 1 and less than 6!\n\n");
	        printf("Input the number of channels again:  ");
		    scanf("%s",string);
		    ChannelNumber = atoi(string);
		} 
//		RN=(int)(ChannelNumber*(ChannelNumber-1))/2;
		RN=ChannelNumber-1;
//		for(i=1;i<=RN;i++) ra[i]=1;

		FileName=cmatrix(1,ArrayNumber,0,50);
		printf("\nInput the file names of the QuantArray data to be Analyzed");
		printf("\n        (no space allowed in a filename):  \n\n");
		printf("\n");
	
		for (k=1;k<=ArrayNumber;k++)
		{   
			intmp=0;
			while (intmp==0)
			{		
				printf("\n Array %d:  ", k);
				scanf("%s", FileName[k]);
				intmp=1;
				if ((fpin[k] = fopen(FileName[k],"r")) == NULL)
				{
					printf("\aCannot open  file: <%s>.\n Please enter the file name again.\n", FileName[k]);
					intmp=0;			
				}
				else fclose(fpin[k]);
				if (k>1)
				{
					for(j=1;j<=k-1;j++)
					{
						if(strcmp(FileName[k],FileName[j])==0 )
						{
							printf("\a<%s> has been used by Array %d.\n Please enter the file name again.\n", FileName[k], j);
							intmp=0;
						}
					} 
				}			
			}
		}
	
		printf("\n\nThe data sets you want to analyze are\n");
	
		for(k=1; k<=ArrayNumber;k++) printf("  Array %d:\t %s\n", k, FileName[k]);
		printf("\n\n");
	}
	else    //  For Web Version
	{
		if ((parameter = fopen("QParameterInput.txt","r")) == NULL)
		{ 
			printf("Cannot open the data file:<ParameterInput.txt>.\a \n");
			printf("Press any key to exit the program.\n");
			getch();
			exit(1); 
		}
		fscanf(parameter, "%s", temp);	
		fscanf(parameter,"%s",string);
		ArrayNumber = atoi(string);   // Number of Arrays
    	fscanf(parameter, "%s", temp);	
		fscanf(parameter,"%s",string);
	    r = atoi(string);             // Number of Replicated Spots
		fscanf(parameter, "%s", temp);	
		fscanf(parameter,"%s",string);
		ChannelNumber=atoi(string);   //Number of Channels
		RN=ChannelNumber-1;	
		FileName=cmatrix(1,ArrayNumber,0,50);
		fscanf(parameter, "%s", temp);
		for (k=1;k<=ArrayNumber;k++)
		{   
			intmp=0;
			while (intmp==0)
			{		
				fscanf(parameter,"%s", temp);
	//			printf("temp2=%s\n",temp);
				strcpy(FileName[k],temp);                      // Input File Names
	//			printf("\nFileName[%d]=%s\n",k,FileName[k]);
	//			getch();
		
				intmp=1;
				if ((fpin[k] = fopen(FileName[k],"r")) == NULL)
				{
					printf("\aCannot open  file: <%s>.\n Please enter the file name again.\n", FileName[k]);
					intmp=0;			
				}
				else fclose(fpin[k]);
				if (k>1)
				{
					for(j=1;j<=k-1;j++)
					{
						if(strcmp(FileName[k],FileName[j])==0 )
						{
							printf("\a<%s> has been used by Array %d.\n Please enter the file name again.\n", FileName[k], j);
							intmp=0;
						}
					} 
				}			
			}
		}
	}

	for(k=1;k<=ArrayNumber;k++)
	{
		if ((fpin[k] = fopen(FileName[k],"r")) == NULL)
		{ 
			printf("\aCannot open the array data file: <%s>!\n", FileName[k]);
			printf("Press any key to exit the program.\n");
			getch();
			exit(1); 
		}
	
		fscanf(fpin[k], "%s", temp);
		if (strcmp(temp, "User")) 
		{
			printf("\n\a %s is not a valid ASCII format QA output file!\n	Check the User's Manual to see how to convert it a Unicode QA output file\n to an ASCII format file.\n", FileName[k]);
			printf("\n");
			printf("Press any key to exit the program.\n");
			getch();
			exit(0);
		}
	}
	skipLine(fpin[1], 6);
	fscanf(fpin[1], "%s", temp);
	fscanf(fpin[1], "%d", &Version);
	printf("Version = %d\n", Version);

	skipLine(fpin[1], 4);
	
	fscanf(fpin[1], "%s", temp);
	fscanf(fpin[1], "%s", temp);
	fscanf(fpin[1], "%d", &ArrayRows);
	printf("ArrayRows = %d\n", ArrayRows);
 
	fscanf(fpin[1], "%s", temp);
	fscanf(fpin[1], "%s", temp);
	fscanf(fpin[1], "%d", &ArrayColumns);
	printf("ArrayColumns = %d\n", ArrayColumns);

	fscanf(fpin[1], "%s", temp);
	fscanf(fpin[1], "%d", &Rows);
	printf("Rows = %d\n", Rows);

	fscanf(fpin[1], "%s", temp);
	fscanf(fpin[1], "%d", &Columns);
	printf("Columns = %d\n", Columns);

	skipLine(fpin[1], 7);

	fscanf(fpin[1], "%s", temp);
	fscanf(fpin[1], "%s", temp);
	fscanf(fpin[1], "%s", temp);
	fscanf(fpin[1], "%d", &ArraySpots);
	printf("ArraySpots = %d\n", ArraySpots);

	fscanf(fpin[1], "%s", temp);
	fscanf(fpin[1], "%s", temp);
	fscanf(fpin[1], "%d", &SpotNumber);
	printf("SpotNumber = %d\n", SpotNumber);

	printf("\n");
	
//	skipLine(fpin[1], 8);

/*	printf("Are all the data sets have the same experimental design? (Y/N)\n\nPlease answer Y--Yes or N-No.\n");
	scanf("%s", sYesNo);
	while (strcmp(sYesNo,"y") && strcmp(sYesNo,"n") ) 
	{
		printf("\n\n\aInvalid Input! You are expected to enter Y (Yes) or N (No)!\n\n");
	    printf("Please  answer Y--Yes or N--No. ");
	    scanf("%s", sYesNo);
	}  
	printf("\n");

	if(strcmp(sYesNo,"n"))
	{	YesNo=1;
		printf("Since the experimental designs of all the data sets are the same,\n");
		printf("the following information is listed only for the first data set.\n\n\n");
	}
	else */
	YesNo=0;

	ch=cmatrix(1,4*ChannelNumber,0,100);
	chnl=carray(1, ArrayNumber,1,ChannelNumber,0,10);
	dye=carray(1, ArrayNumber,1,ChannelNumber,0,10);
	img=carray(1, ArrayNumber,1,ChannelNumber,0,100);
	ControlChannel=ivector(1,ArrayNumber);
	Case=imatrix(1,ArrayNumber,1,ChannelNumber-1);
	for(k=1;k<=(YesNo==1)+(YesNo==0)*ArrayNumber;k++)
	{
		skipLine(fpin[k], (k>1)*27);
		fscanf(fpin[k], "%s", string);
L14:	while(strcmp(string,"Begin"))
		{
			skipLine(fpin[k], 1);
			fscanf(fpin[k], "%s", string);
		}
		fscanf(fpin[k], "%s", string);
		if(strcmp(string,"Image")) 
		{
			goto L14;
		}
		
		skipLine(fpin[k], 2);
		printf("  Data Set %d:\t %s\n", k, FileName[k]);
		printf("Channel (Fluor.)\tImage Files:\n");
		ci=0;
		for(cn=1;cn<=ChannelNumber;cn++)
		{
			
			for(j=1;j<=3;j++)
			{
				memset(ch[(cn-1)*4+j], 0, 100);
				chr=getc(fpin[k]);
				ch[(cn-1)*4+j][0]=chr;
				st=0;
				while (chr !='\t')
				{   
					chr=getc(fpin[k]);
					//st+=1;
					if(chr!='\t'){st+=1; ch[(cn-1)*4+j][st]=chr;}
				}
//				printf("what=%s\n", ch[(cn-1)*4+j]);
			}
			for(j=1;j<=6;j++)
			{
				chr=getc(fpin[k]);
				st=0;
				while (chr !='\t')
				{   
					chr=getc(fpin[k]);
					//st+=1;
//					if(chr!='\t'){st+=1; ch[(cn-1)*4+j][st]=chr;}
				}
			}
			memset(ch[(cn-1)*4+4], 0, 100);
			chr=getc(fpin[k]);
			ch[(cn-1)*4+4][0]=chr;
			st=0;
			while (chr !='\n' && chr != '\t')
			{   
				chr=getc(fpin[k]);
				//st+=1;
				if(chr!='\n'){st+=1; ch[(cn-1)*4+4][st]=chr;}
			}
//			printf("Status=%s\n", ch[(cn-1)*4+4]);
			//memset(bch,0,100);
			bch = strrev(ch[(cn-1)*4+2]);
//			printf("bch=%s\n",bch);
			t1=0; 
	
			memset(b,0,100);

			while (bch[t1] !='\\') 
			{
			    b[t1] = bch[t1];
				t1+=1;
			}
			
/*			fscanf(fpin[k], "%s", chnl[k][cn]);
			printf("String1=%s\n", chnl[k][cn]);
			getch();
			fscanf(fpin[k], "%s", img[k][cn]);
			printf("String2=%s\n", img[k][cn]);
			getch();
			fscanf(fpin[k], "%s", dye[k][cn]);
			printf("String3=%s\n", dye[k][cn]);
			getch();
			fscanf(fpin[k], "%s", string);
			printf("String4=%s\n", string);
			getch();
			t1=1;  
			while(strstr(string, "Control")==NULL && strstr(string, "Case")==NULL )
			{
				fscanf(fpin[k], "%s", string);
				printf("String %d=%s\n", 4+t1,string);
				t1++;
				getch();
			}  */
			strcpy(string,ch[(cn-1)*4+4]);
			if(strstr(string, "Control")!=NULL) ControlChannel[k]=cn;
			else if (strstr(string, "Case")!=NULL)
			{
				for(i=1;i<ChannelNumber;i++)
				{
					if(_stricmp(string, CaseStr[i-1])==0 ) Case[k][i]=cn;
//					printf("string=%s\n", string);
//					printf("CaseStr[%d]=%s\n", i,CaseStr[i-1]);
				}
			}
			else 
			{
				Case[k][++ci]=cn;
//				printf("string=%s\n", string);
//				printf("Case[%d][%d]=%d\n", k,ci,Case[k][ci]);			
			}

			bb= strrev(b);
			strcpy(chnl[k][cn],ch[(cn-1)*4+1]);
			strcpy(dye[k][cn],ch[(cn-1)*4+3]);
			strcpy(img[k][cn],bb);
//			printf("%2.3s(%2.3s)\t%s\n", ch[(cn-1)*4+1],ch[(cn-1)*4+3],bb);
//			printf("%2.3s(%2.3s)\t%s\n", chnl[k][cn],dye[k][cn],img[k][cn]);
//			getch();
//			skipLine(fpin[k], 1);
		}
		printf("ControlChannel[%d]=%d\n", k,ControlChannel[k]);
		for(i=1;i<ChannelNumber;i++) printf("Case[%d][%d]=%d\n", k,i,Case[k][i]);
//		getch();
		printf("\n\n");
	}
	free_cmatrix(ch, 1, 4*ChannelNumber,0,100);

/////////////////////////////////////
//////////////////////////////////////
	LT=imatrix(0,ArrayNumber-1,0,ChannelNumber-1);
	for(k=1;k<=(YesNo==1)+(YesNo==0)*ArrayNumber;k++)
	{
		for(cn=1;cn<=ChannelNumber;cn++)
		{
			t1=0;
			while(dye[k][cn][t1]!='\0')
			{
				t1+=1;
			}
			NoDM*=(t1>1);
		}
	}
//	printf("NoDM=%d\n",NoDM);
//	getch();
	if(NoDM==0)
	{
		printf("I cannot detect your experiment design.\n");
L10://	if(YesNo==0) printf("Please tell me your experiment designs for the %d arrays:\n\n",ArrayNumber);
	//	else 
	//		printf("Please tell me the common experiment design for all the %d arrays:\n\n",ArrayNumber);

		if(WebVersion==1) {fscanf(parameter, "%s", temp);    
		      		printf("tempDye=%s\n",temp);
		}
		for(k=1;k<=(YesNo==1)+(YesNo==0)*ArrayNumber;k++)
			for(cn=1;cn<=ChannelNumber;cn++)
			{
				if((strcmp(dye[k][cn],"       ")==1)==0)
				{
					if(WebVersion==0)
					{
						printf("The Dyes (Fluorophor) used for\n\n");
						printf("Please type in the symbol such as Cy3 and Cy5.\n\n");
						printf("Please use the same symbols in all the data sets.\n\n");
						printf("      Array %d, Channel %d is \n",k,cn);
						scanf("%s", dye[k][cn]);
					}
					else  {fscanf(parameter,"%s", dye[k][cn]);
										printf("Dye[%d][%d]=%s\t",k,cn,dye[k][cn]);
								getch();
					}
				}
			}
		if(WebVersion==0)  //////////////////////////
		{
			printf("\n");
			if(YesNo==0) printf("Your dye assignments for the %d arrays are:\n\n",ArrayNumber);
			else printf("The same dye assignment for the  %d arrays is:\n\n",ArrayNumber);
			printf("Dyes (Fluorophors) used \n");
			for(cn=1;cn<=ChannelNumber;cn++) printf("\t  Channel %d",cn);
			printf("\n");
			for(k=1;k<=(YesNo==1)+(YesNo==0)*ArrayNumber;k++)
			{
				printf("Array %d",k);
				for(cn=1;cn<=ChannelNumber;cn++)
				{
					printf("  \t%s    ",dye[k][cn]);
				}
				printf("\n");
			}
			printf("\nAre you sure this is the correct design matrix? (Y---Yes or N---No)   ");
			scanf("%s",sYesNo);
			while (strcmp(sYesNo,"y") && strcmp(sYesNo,"n") ) 
			{
				printf("\n\n\aInvalid Input! You are expected to enter Y (Yes) or N (No)!\n\n");
			    printf("Please answer Y--Yes or N--No. ");
				scanf("%s", sYesNo);
			}
			if(strcmp(sYesNo,"y") && strcmp(sYesNo,"Y")) 
			{
				YesNo=0;
				goto L10;
			}
		}
		else strcpy(sYesNo,"y");
		NoDM=1;
	}
	else
	{
		if(WebVersion==1) skipLine(parameter,ArrayNumber+1);
	}
	YesNo=1;
	for(cn=1;cn<=ChannelNumber;cn++)
	{	
		for(k=2;k<=ArrayNumber;k++)
		{
			YesNo*=(_stricmp(dye[k][cn],dye[1][cn])==0);
		}
	}
//	printf("YesNo=%d\n",YesNo);
//	getch();

	for(cn=1;cn<=ChannelNumber;cn++)
	{	
		LT[0][cn-1]=cn;
//		printf("LT[0][%d]=%d\t",cn-1,LT[0][cn-1]);
		for(k=2;k<=ArrayNumber;k++)
		{
			if(YesNo==1) LT[k-1][cn-1]=cn;
			else
			{
				LT[k-1][cn-1]=0;
				for(j=1;j<=ChannelNumber;j++)
				{
					LT[k-1][cn-1]+=j*(_stricmp(dye[k][cn],dye[1][j])==0);
				  // Use "_stricmp" rather than "strcmp" to ignore case different
				}
				if(LT[k-1][cn-1]==0)
				{
					printf("The Dyes (Fluorophors) used for all the %d arrays must the same.\n",ArrayNumber);
					ErrorMessage("Use the same symbol for the same dye");
				}
			}
//			printf("LT[%d][%d]=%d\t",k-1,cn-1,LT[k-1][cn-1]);
		}
//		printf("\n");
	}
	
////////////////////////////////////
////////////////////////////////////		
	printf("\n\nYou have %d channels in each array.", ChannelNumber);
/*	for(i=1;i<=ChannelNumber-1;i++)
		for(j=i+1;j<=ChannelNumber;j++)
		{
			r1=(int) (j-i+(i-1)*(2*ChannelNumber-i)/2);
			printf("You want to consider \n\t\t1-----ch%d/ch%d    or    2-----ch%d/ch%d?\n Please enter 1 or 2 to make your choice:", j,i,i,j);
			scanf("%s", &temp);
			ra[r1]=atoi(temp);
			printf("\n\n");
			while ( (ra[r1] != 1) && (ra[r1] !=2)) 
			{
				printf("\aInvalid Input! You are expected to enter 1 or 2.\n Please enter your choice again:  ");
				scanf("%s",&temp);
				ra[r1]=atoi(temp);
				printf("\n\n");
			}
		}  */

	ChIntensity = darray( 1, ArrayNumber,1,ChannelNumber,1,SpotNumber);
	ChBackground = darray( 1, ArrayNumber,1,ChannelNumber,1,SpotNumber);
	GeneName = cmatrix(1,SpotNumber,0,500);
	Filter = dmatrix(1,ArrayNumber, 1, SpotNumber);

	GeneNumber = (int) (SpotNumber / r);
	printf("The Total Number of Gene is %d.\n", GeneNumber);
	for(k=1;k<=ArrayNumber;k++)
	{
		fscanf(fpin[k], "%s", string);
L13:	while(strcmp(string,"Begin"))
		{
			skipLine(fpin[k], 1);
			fscanf(fpin[k], "%s", string);
		}
		fscanf(fpin[k], "%s", string);
		if(strcmp(string,"Measurements")) 
		{
			goto L13;
		}
		
	//	skipLine(fpin[k], 4+(k>1)*(YesNo==1)*(29+ChannelNumber));
		skipLine(fpin[k], 2);
		fscanf(fpin[k], "%d", &intmp);

		skipLine(fpin[k], SpotNumber+1);
		fscanf(fpin[k], "%s", string);
L15:	while(strcmp(string,"Begin"))
		{
			skipLine(fpin[k], 1);
			fscanf(fpin[k], "%s", string);
		}
		fscanf(fpin[k], "%s", string);
		if(strcmp(string,"Data")) 
		{
			goto L15;
		}
		
	//	skipLine(fpin[k], 4+(k>1)*(YesNo==1)*(29+ChannelNumber));
		skipLine(fpin[k], 2);
		for(j=1;j<=SpotNumber;j++)          // begin the read of data 
		{
			for(i=1;i<=5;i++)
			{
				fscanf(fpin[k], "%d", &intmp);
				//printf("%d\n",intmp);
				//getch();
			}
			chr=getc(fpin[k]);
			memset(GeneName[j], 0, 500);
			chr=getc(fpin[k]);
			GeneName[j][0]=chr;
			st=0;
			while (chr !='\t')
			{
				chr=getc(fpin[k]);
				if(chr!='\t')
				{
					st+=1;
					GeneName[j][st]=chr;
				}
			}
//			if(j>=3258 && j<=3262)
//			{
//			printf(" GeneName[%d]=%s\n", j,GeneName[j]);
//			getch();
//			}
			for(cn=1;cn<=ChannelNumber;cn++)
			{
				fscanf(fpin[k],"%lf", &doubletmp);
//				if(j>=2122)printf(" X Location[%d]=%f\n", j,doubletmp);
				fscanf(fpin[k],"%lf", &doubletmp);
//				if(j>=2122)printf(" Y Location[%d]=%f\n", j,doubletmp);
				fscanf(fpin[k],"%lf",&ChIntensity[k][cn][j]);
				fscanf(fpin[k],"%lf",&ChBackground[k][cn][j]);
//				if(j>=3258 && j<=3262)
//				{
//				printf("Ch%dIntensity = %lf\n", cn, ChIntensity[k][cn][j]);
//				printf("Ch%dBackground = %lf\n", cn, ChBackground[k][cn][j]);
//				getch();
//				}
				ChIntensity[k][cn][j]-=ChBackground[k][cn][j];
				if(Version==3)
				{
					for(l=1;l<=8;l++) fscanf(fpin[k],"%lf", &doubletmp);
				}
				
//				printf("Ch%dIntensityBsr = %lf\n", cn, ChIntensity[k][cn][j]);
//				
			}

			fscanf(fpin[k],"%lf", &doubletmp);
			fscanf(fpin[k],"%lf", &doubletmp);
			fscanf(fpin[k],"%lf", &Filter[k][j]);
		}
		fclose(fpin[k]);
	}                                        //End the Data Input
	if(WebVersion==0)
	{
		printf("\nWhich kind of Simple Normalization you want to use?\n1 --- Normalization to Mean\n2 --- Normalzation to Median\n\nPlease enter 1 or 2 to make your choice:  "); 
		scanf("%s", &temp);
		nor=atoi(temp);
		printf("\n");
		while ( (nor != 1) && (nor !=2)) 
		{
			printf("\n\aInvalid Input! You are expected to enter 1 or 2.\nPlease enter your choice again:  ");
			scanf("%s",&temp);
			nor=atoi(temp);
			printf("\n");
		}
		if(nor==1)
			printf("You have chosen Normalization to mean. ");
		else printf("You have chosen Normalization to median. ");
		printf("\n\n");
	}
	else 
	{
		UserID=cvector(0,60);
		fscanf(parameter, "%s", temp);
		fscanf(parameter, "%s", tempID);  // User ID
		strcpy(UserID,tempID);
//		printf("UserID=%s\n",tempID);
//		getch();
		fscanf(parameter, "%s", temp);
	//	printf("\nWhich kind of Simple Normalization you want to use?\n1 --- Normalization to Mean\n2 --- Normalzation to Median\n\nPlease enter 1 or 2 to make your choice:  "); 
		fscanf(parameter, "%s", &temp);
		nor=atoi(temp);
	}
	free_darray(ChBackground, 1, ArrayNumber,1,ChannelNumber,1,SpotNumber);
	
    //Simple Normarlization Begins.
	// ----Normalization to Mean or to Median
	Mean = dmatrix(1,ArrayNumber,1,ChannelNumber); 
	Total = dmatrix(1,ArrayNumber,1,ChannelNumber);
	Median = dmatrix(1,ArrayNumber,1,ChannelNumber);
	factor = dvector(1,ArrayNumber); 
	ord = ivector(0,ChannelNumber-1);
	for(cn=1;cn<=ChannelNumber;cn++)
		for(k=1;k<=ArrayNumber;k++)
		{
			if(nor==1)
			{
				Mean[k][cn] = 0.0; Total[k][cn]=0.0;	
				for(j=1;j<=SpotNumber;j++)
				{
					if (ChIntensity[k][cn][j] >=0 ) 
					{
						Total[k][cn]+=1;
						Mean[k][cn] += ChIntensity[k][cn][j];
					}			
				}
				Mean[k][cn]/=Total[k][cn];
			}
			else
			{
				Median[k][cn]=rMedian(ChIntensity[k][cn],SpotNumber);
//				printf("Median[%d][%d]=%f\n",k,cn,Median[k][cn]);
//				getch();
			}
		}

	if(WebVersion==0)
	{
	for (k=1;k<=ArrayNumber;k++)
	{   
		printf("Data Set %d:\n", k);
		printf("Channel:");
		for(cn=1;cn<=ChannelNumber;cn++)
		{
			printf("\t channel %d",cn);
		}
		printf("\n");
		if(nor==1)
		{
			printf("   Mean:");
			for(cn=1;cn<=ChannelNumber;cn++)
				printf("\t %lf", Mean[k][cn]);
		}
		else
		{
			printf("   Median:");
			for(cn=1;cn<=ChannelNumber;cn++)
				printf("\t %lf", Median[k][cn]);
		}
		printf("\n\n");
	}
	}


   
	   //Simple Normalization
	for(k=1;k<=ArrayNumber;k++)
	{
		for(cn=1;cn<=ChannelNumber;cn++)
		{
			for(j=1;j<=SpotNumber;j++)
			{
				ChIntensity[k][cn][j]/= ((nor==1)*Mean[k][cn]+(nor==2)*Median[k][cn]);
			}

		}
	} //End of the Simple Normalization
	printf("\n\n************************************************************************\n");
	printf("In order to adjust the Dye effect,\n");
	printf("you may want to use the nonlinear normalization\n");
	printf("---Lowess Fit Method---to normalize your ratios.\n\n");
	printf("References for Lowess Normalization:\n\n");
	printf("Yang, Y. H. et al., Normalization for cDNA Microarray Data\n");
	printf("                   SPIE BiOS 2001, San Jose, California, January 2001. ;\n");
	printf("Dudoit, S. et al., Statistical Methods for Identifying Differentially \n");
	printf("                   Expressed Genes in Replicated cDNA Microarray Experiments;\n");
	printf("                   Technical Report #578, Aug. 2000, Dept. of Statistics,\n");
	printf("                   UC Berkeley\n");
	printf("Tseng, G. C. et al., Issues in cDNA Microarray Analysis: Quality Filtering, \n");
	printf("                     Channel Normalization, Models of Variation and Assessment \n");
	printf("                     of Gene Effects. Neucleic Acids Research, 2001, Vol.29, \n");
	printf("                     No 12, 2549-1557. \n\n");
	printf("\n************************************************************************\n\n");

	//printf("Do you want to use Lowess Fit to normalize your data?\n");
	//printf("Y----YES  or N----NO? Please choose Y or N.\n");
	//scanf("%s", LowessFit);
	strcpy(LowessFit,"y");
	//printf("%s",LowessFit);
	while (strcmp(LowessFit,"y") && strcmp(LowessFit,"n") ) 
	{
		printf("\n\n\aInvalid Input! You are expected to enter Y (Yes) or N (No)!\n\n");
	    printf("Please  answer Y--Yes or N--No. ");
	    scanf("%s", LowessFit);
	}  

	printf("\n");
	if(strcmp(LowessFit,"n"))  // IF LowessFit!="n"
	{
//////////////////////////////////////////
//////////////////////////////////////////



		f=2.0/3.0; nsteps=3; pct=0.01;
	//	printf("The Default values of Parameters for Lowess Fit are:\n\n");
	//	printf("        f=2.0/3.0=0.6666..., iter=3, delta=pct*range(x), where pct=0.01.\n\n");
	//	printf("Do you want to change these default values?\n");
	//	printf("Please Answer Y---Yes or N---No.\n");
		//scanf("%s",string);
		strcpy(string,"n");
		while (strcmp(string,"y") && strcmp(string,"n") ) 
		{
			printf("\n\n\aInvalid Input! You are expected to enter Y (Yes) or N (No)!\n\n");
		    printf("Please answer Y--Yes or N--No. ");
		    scanf("%s", string);
		}  
		if(strcmp(string, "n"))
		{
L5:			printf("Please Enter Your Parameter values:\n");
			printf("f=\n");
			scanf("%s",string1);
			f=atof(string1);
			printf("iter=\n");
			scanf("%s",string1);
			nsteps=atoi(string1);
			printf("pct=\n");
			scanf("%s", string1);
			pct=atof(string1);
			printf("Your values for Parameters of Lowess Fit are:\n\n");
			printf("f=%f, iter=%d, delta=%f*range(x).\n", f, nsteps, pct);
			scanf("Are these values correct? Y--Yes or N--No?%s\n\n", string1);
			while (strcmp(string1,"y") && strcmp(string1,"n") ) 
			{
				printf("\n\n\aInvalid Input! You are expected to enter Y (Yes) or N (No)!\n\n");
			    printf("Please answer Y--Yes or N--No. ");
			    scanf("%s", string1);
			}  
			
			if(strcmp(string1, "y"))
				goto L5;
		}
		printf("\n\nLowess Fit Normalization is Running.\n");
		printf("\nPlease wait."); 
		//Lowess Fit Normalization  begins
		z=dmatrix(1,ChannelNumber,1,SpotNumber);
		for(k=1;k<=ArrayNumber;k++)    
		{
			iorder(LT[k-1], ChannelNumber, ord);
			for(cn=1;cn<=ChannelNumber;cn++)				
				for(j=1;j<=SpotNumber;j++)
				{
					z[cn][j]=ChIntensity[k][ord[cn-1]][j];
				}
			lowess_normalization(z,SpotNumber,ChannelNumber, f, nsteps, pct);//,0.02,1000,1000);
			for(cn=1;cn<=ChannelNumber;cn++)
				for(j=1;j<=SpotNumber;j++)
				{
					ChIntensity[k][ord[cn-1]][j]=z[cn][j];
				}
		}
		//	printf("lowess normalization finished.\n\n");
		free_dmatrix(z,1,ChannelNumber,1,SpotNumber);

	}
	

       //End of Lowess Fit Normalization


	//M = dmatrix( 1, RN*ArrayNumber,1,SpotNumber);
	//A =	dmatrix( 1, ArrayNumber,1,SpotNumber);
	Ratio = darray(1, ArrayNumber,1, RN, 1,SpotNumber); 
	

	for(k=1;k<=ArrayNumber;k++)    //Calculating Ratios, M and A
	{
		for(g=1;g<=SpotNumber;g++)
		{
/*			A[k][g] = 1;
			for(cn=1;cn<=ChannelNumber;cn++)
			{
				if(ChIntensity[k][cn][g]>0)
					A[k][g]*=ChIntensity[k][cn][g];
			}
			A[k][g]=log(A[k][g])/ChannelNumber;
*/			
//			for(i=1;i<=ChannelNumber-1;i++)
//				for(j=i+1;j<=ChannelNumber;j++)
			for(r1=1;r1<=RN;r1++)
				{
			//		r1=(int) (j-i+(i-1)*(2*ChannelNumber-i)/2);
					if((ChIntensity[k][ControlChannel[k]][g] <=0) || (ChIntensity[k][Case[k][r1]][g]<=0) ) 
					{
						Ratio[k][r1][g] = 0;
						//M[k][r1][g] = 0;
					}
					else 
					{
						Ratio[k][r1][g] = ChIntensity[k][Case[k][r1]][g] / ChIntensity[k][ControlChannel[k]][g];
			//			Ratio[k][r1][g] = ChIntensity[k][j][g] / ChIntensity[k][i][g];
						//M[k][r1][g] = log(Ratio[k][r1][g]);
			//			if (ra[r1]==2)Ratio[k][r1][g] =  1/Ratio[k][r1][g];
					}
				}
		}

	}       //End of Calculation of Ratios, M and A



	RepeatRatio = darray(1,GeneNumber,1,RN, 1, r*ArrayNumber);
	MeanLogIntensity = darray( 1, ArrayNumber,1,ChannelNumber,1,GeneNumber);
	for(g=1;g<=GeneNumber;g++)   // 
		for(k=1; k<=ArrayNumber;k++)
		{
			for(cn=1;cn<=ChannelNumber; cn++)
			{
				MeanLogIntensity[k][cn][g]=1.0; t=0;
				for(re=1;re<=r;re++)
				{
					if(cn<ChannelNumber) 
					{
						if(ChIntensity[k][Case[k][cn]][r*(g-1)+re]>0.0)
						{
							MeanLogIntensity[k][cn][g]*=ChIntensity[k][Case[k][cn]][r*(g-1)+re]; 
							t+=1;
						}
					}
					else
					{
						if(ChIntensity[k][ControlChannel[k]][r*(g-1)+re]>0.0)
						{
							MeanLogIntensity[k][cn][g]*=ChIntensity[k][ControlChannel[k]][r*(g-1)+re]; 
							t+=1;
						}
					}

				}
				if(t>0)
					MeanLogIntensity[k][cn][g]=log(MeanLogIntensity[k][cn][g])/t;
				else
					MeanLogIntensity[k][cn][g]=0.0;
			}
			for(re=1;re<=r;re++) 
			{
				for(r1=1;r1<=RN;r1++)
					RepeatRatio[g][r1][r*(k-1)+re]=Ratio[k][r1][r*(g-1)+re];
			}
		}
	if(WebVersion==0)
	{
		printf("\n\nType in the file name you want save your normalized data:\n\n");
L0:		scanf("%s", DataFile);
		//getch();
		printf("\n\n");
		if ((fpout2= fopen(DataFile, "r")) != NULL)
		{ 
			printf("\aFile <%s> exists! Do you want to overwrite the file: %s?\n",DataFile,DataFile);
			printf("Y----YES  or N----NO? Please choose Y or N.\n");
			scanf("%s", string);
			if(strcmp(string,"y")) 
			{
				printf("Type in another file name you want save your normalized data:\n");
				goto L0;
			}
		}	

L1:		if ((fpout2= fopen(DataFile, "w")) == NULL)
		{
			printf("\aCannot write to the data file <%s>.\n",DataFile);
			printf("Close the Excel or other application which opens this file.\n");
			printf("Then press any key to continue.\n");
			getch();
			goto L1;
			//exit(1);
		}
		printf("\n\n");
	}
	else 
	{
		strcpy(DataFile,"NormalizedData.txt");
		strcpy(UserID,tempID);
		strcat(UserID,DataFile);
		strcpy(DataFile,UserID);
		fpout2= fopen(DataFile, "w");
	}
	fprintf(fpout2, "\nNormalized Data Files:\t\t\t");
	for(k=1;k<=ArrayNumber;k++)
	{
		fprintf(fpout2, " %s\t", FileName[k]);
	}
				
	fprintf(fpout2,"\n");

	fprintf(fpout2, "Normalization Information:\n");
	if(nor==1)
	{
		fprintf(fpout2, "Method: Normalization to Mean \n\n");
		fprintf(fpout2, "Mean Intensities(Backgound Subtracted): \n\n");
	}
	else
	{
		fprintf(fpout2, "Method: Normalization to Median \n\n");
		fprintf(fpout2, "Median Intensities(Backgound Subtracted): \n\n");
	}

	//fprintf(fpout2, " \t ");
	for(i=1;i<=ChannelNumber;i++)
		fprintf(fpout2, " \t Channel %d ",i);

	fprintf(fpout2,"\n");
	for(k=1;k<=ArrayNumber;k++)
	{
		fprintf(fpout2, " %s\t", FileName[k]);
		if(nor==1)
		{
			for(cn=1;cn<=ChannelNumber;cn++)
				fprintf(fpout2, " %lf\t", Mean[k][cn]);
			fprintf(fpout2,"\n\n");
		}
		else
		{
			for(cn=1;cn<=ChannelNumber;cn++)
				fprintf(fpout2, " %lf\t", Median[k][cn]);
			fprintf(fpout2,"\n\n");
		}
	}
	if(strcmp(LowessFit,"n"))
	{
		fprintf(fpout2, "Lowess Fit Normalization Was Used After the Above Normalization.\n\n");
	}
	fprintf(fpout2,"\n");
	////////////////////////////
	/////////////////////////////
		fprintf(fpout2,"Dyes (Fluorophors) Used the for the %d Arrays are\n",ArrayNumber);
		for(cn=1;cn<=ChannelNumber;cn++) fprintf(fpout2,"\tChannel %d",cn);
		fprintf(fpout2,"\n");
		for(k=1;k<=(YesNo==1)+(YesNo==0)*ArrayNumber;k++)
		{
			if(YesNo==0) fprintf(fpout2,"Array %d",k);
			else fprintf(fpout2,"Arrays %d - %d",1,ArrayNumber);
			for(cn=1;cn<=ChannelNumber;cn++)
			{
				fprintf(fpout2,"\t%s",dye[k][cn]);
			}
			fprintf(fpout2,"\n");
		}		

		////////////////////////////
		//////////////////////////////
	fprintf(fpout2, "Begin data\n");
	fprintf(fpout2, "\t\t");
	for(k=1;k<=ArrayNumber;k++)
	{
		fprintf(fpout2, "%s", FileName[k]);
		for(i=1;i<=ChannelNumber+RN;i++)
			fprintf(fpout2, "\t");
	}
	fprintf(fpout2,"\n");
									
	fprintf(fpout2, "Number\t Gene Name\t");
	for(k=1;k<=ArrayNumber;k++)
	{
		for(cn=1;cn<=ChannelNumber;cn++)
			fprintf(fpout2, "Ch.%d Intensity \t",cn);
/*		for(i=1;i<=ChannelNumber-1;i++)
			for(j=i+1;j<=ChannelNumber;j++)
			{
				r1=(int)(j-i+(i-1)*(2*ChannelNumber-i)/2);
				fprintf(fpout2, "Ch%d/Ch%d Ratio\t",j*(ra[r1]==1)+i*(ra[r1]==2),i*(ra[r1]==1)+j*(ra[r1]==2));
			}*/
		for(i=1;i<=RN;i++)
		{
			fprintf(fpout2, "Case%d(Ch%d)/Control(Ch%d) Ratio\t",i,Case[k][i],ControlChannel[k]);
		}

	}


	fprintf(fpout2, "\n");
					
	for(g=1;g<=SpotNumber;g++)
	{
		fprintf(fpout2, "%d\t", g);
//		fprintf(fpout2,"%s\t", GeneName[g]);
//		printf("GeneName[%d]%s\n",g, GeneName[g]);
		t1=0;
		while((GeneName[g][t1]!='\0')&&(GeneName[g][t1]!='\t'))
		{
			//if(GeneName[g][t1]=='\t') t1+=1;
			t1+=1;
		}
		if(t1>0) fprintf(fpout2,"%s\t", GeneName[g]);
		else fprintf(fpout2,"%s", GeneName[g]);
//		if(j>=3258 && j<=3262)
//		{printf("Gene Name=%s\n", GeneName[g]); getch();}
		for(k=1;k<=ArrayNumber;k++) 
		{
			for(cn=1;cn<=ChannelNumber;cn++)
				fprintf(fpout2, "%lf\t ",ChIntensity[k][cn][g]);
/*			for(i=1;i<=ChannelNumber-1;i++)
				for(j=i+1;j<=ChannelNumber;j++)
				{
					r1=(int)(j-i+(i-1)*(2*ChannelNumber-i)/2);
					if(fabs(Ratio[k][r1][g])>1e05)
					fprintf(fpout2, "%.2e\t",Ratio[k][r1][g]);
					else fprintf(fpout2, "%lf\t",Ratio[k][r1][g]);
				//	fprintf(fpout2, "%lf\t", Ratio[k][r1][g]);
				}*/
			for(i=1;i<=RN;i++)
			{
				if(fabs(Ratio[k][i][g])>1e05)
				fprintf(fpout2, "%.2e\t",Ratio[k][i][g]);
				else fprintf(fpout2, "%lf\t",Ratio[k][i][g]);
			//	fprintf(fpout2, "%lf\t", Ratio[k][i][g]);
			}

		}					
		fprintf(fpout2,"\n");
	}
	fclose(fpout2);
		
//////////////////////////////
//      ANOVA Begins        //
//////////////////////////////
	if(ArrayNumber>=2)
	{
		if(NoDM==1)
		{
			if(ChannelNumber==ArrayNumber)
			{
				intemp=ivector(1,ChannelNumber);
				for(cn=1;cn<=ChannelNumber;cn++)
				{
					intemp[cn]=0;
					for(k=1;k<=ArrayNumber;k++)
					{
						intemp[cn]+=LT[k-1][cn-1];
					}
				}
				intmp=1;
				for(cn=1;cn<=ChannelNumber;cn++)
				{
					intmp*=(intemp[cn]==ChannelNumber*(ChannelNumber+1)/2.0);
				}
//				printf("intmp=%d\n",intmp);
//				printf("ArrayNumber=%d\tChannelNumber=%d\n",ArrayNumber, ChannelNumber);
//				getch();
				free_ivector(intemp,1,ChannelNumber);
//				intmp=(ArrayNumber==ChannelNumber)*intmp;
				if(intmp==1)
				{	
 		            printf("It seems that you have a %d x %d Latin square experiment.\n", ArrayNumber, ChannelNumber);
					printf("The Latin Experimental Design Matrix is \n\n");
					for(cn=1;cn<=ChannelNumber;cn++)
						printf("\t        Ch.%d:", cn);
					printf("\n\n");
					for(k=1;k<=ArrayNumber;k++)
					{
						printf("Array %d:\t",k);
						for(cn=1;cn<=ChannelNumber;cn++)
						{
							printf("%d (%s)      \t",LT[k-1][cn-1],dye[k][cn]);
						}
						printf("\n");
					}
				}
				printf("\n");
				printf("You have the option to perform the Analysis of Variance for your Gene\n");
			}
			else
			{
				printf("The Experimental Design Matrix is \n\n");
				for(cn=1;cn<=ChannelNumber;cn++)
					printf("\t        Ch.%d:", cn);
				printf("\n\n");
				for(k=1;k<=ArrayNumber;k++)
				{
					printf("Array %d:\t",k);
					for(cn=1;cn<=ChannelNumber;cn++)
					{
						printf("%d (%s)\t",LT[k-1][cn-1],dye[k][cn]);
					}
					printf("\n");
				}
				printf("\n");

				printf("You have the option to perform the Analysis of Variance for your Gene\n");
			}
			printf("expression microarrays.\n");
			if(WebVersion==0)
			{
				printf("\n\n************************************************************************\n");
				printf("You have option to use ANOVA method to analyze your microarray data.\n");
				printf("Reference for Lowess Normalization:\n\n");
				printf("Kerr, M. K. et al., Analysis of Variance for Gene Expression Microarray Data,\n");
				printf("                    J. Comput. Biol., 7, 819-837.\n");
				printf("\n************************************************************************\n\n");

			}
		}
		if(WebVersion==0)
		{
			printf("\n\n");
			printf("Do you want to Perform ANOVA to analyze your data?\n\n");
			printf("Y----YES  or N----NO? Please choose Y or N.\n");
			scanf("%s", ANOVA);
			//printf("%s", ANOVA);
			while (strcmp(ANOVA,"y") && strcmp(ANOVA,"n") ) 
			{
				printf("\n\n\aInvalid Input! You are expected to enter Y (Yes) or N (No)!\n\n");
			    printf("Please  answer Y--Yes or N--No. ");
			    scanf("%s", ANOVA);
			}  
			printf("\n\n");
		}
		else 
		{
			fscanf(parameter, "%s", temp);
			fscanf(parameter,"%s", ANOVA);
		}

		if(strcmp(ANOVA,"n"))  // IF ANOVA!="n"
		{
			
/*			if(NoDM==0)
			{
				printf("I cannot detect your experiment design matrix.\n");
				printf("Because the experimental esigns are different,\n");
				printf("I need the experiment design matrix to perform ANOVA.\n\n");
				printf("Please tell me your experiment design matrix:\n\n");
				for(k=1;k<=ArrayNumber;k++)
					for(cn=1;cn<=ChannelNumber;cn++)
					{
						printf("DM[%d][%d]=\t",k,cn);
						scanf("%s",string);
						LT[k-1][cn-1]=atoi(string);
					}
					printf("\n");			
			}*/
			ANOVA4Microarray(WebVersion,MeanLogIntensity,r, GeneName, 
				GeneNumber, ArrayNumber, ChannelNumber, LT, ControlChannel, Case, UserID, tempID, parameter);
		}
	}

	free_darray(ChIntensity, 1, ArrayNumber,1,ChannelNumber,1,SpotNumber);	
	free_dmatrix(Mean,1,ArrayNumber,1,ChannelNumber);
	free_dmatrix(Total,1,ArrayNumber,1,ChannelNumber);
	free_dmatrix(Median,1,ArrayNumber,1,ChannelNumber);
	free_dvector(factor,1,ArrayNumber);
	free_darray(Ratio,1,ArrayNumber,1, RN,1,SpotNumber);

	MeanRatio= darray(1,ArrayNumber,1, RN, 1,GeneNumber); // Mean of non-zero ratios of repeated Genes
	for(rn=1;rn<=RN;rn++)	
		for(k=1;k<=ArrayNumber;k++)
			for(g=1;g<=GeneNumber;g++)
			{
				MeanRatio[k][rn][g]=0.0;
				t=0;
				for(re=1;re<=r;re++)
				{
					if(RepeatRatio[g][rn][r*(k-1)+re] > 0 )
					{
						t+=1;
						MeanRatio[k][rn][g] += RepeatRatio[g][rn][r*(k-1)+re];
					}
				}
				if(t !=0 ) 
				{
					MeanRatio[k][rn][g] /=t;
				}
			} // data specified mean

		
	Stdev=dmatrix(1,RN,1,GeneNumber);  //Stdev of Ratios
	LogStdev=dmatrix(1,RN,1,GeneNumber);  //Stdev of log2 Ratios

	Fout = imatrix(1, RN,1,ArrayNumber);
	Fnu =  imatrix(1, RN,1,ArrayNumber);
	Gout = imatrix(1, RN,1,GeneNumber);
	Gnu = imatrix(1,RN,1,GeneNumber);
	Length = imatrix(1,RN,1,GeneNumber);

	OverallMean = dmatrix(1,RN,1,GeneNumber); //Mean of non-zero ratios
	LogMean = dmatrix(1,RN,1,GeneNumber);    //Mean of log2 (non-zeero) Ratios
	OverallMedian =dmatrix(1,RN,1,GeneNumber); //Median of non-zero ratios
    Pvalue =dmatrix(1,RN,1,GeneNumber);
	Tstat=dvector(1,GeneNumber);

	for(rn=1;rn<=RN;rn++)
	{
		for(g=1;g<=GeneNumber;g++)
		{
			OverallMean[rn][g]=0; LogMean[rn][g]=-10000; 
			OverallMedian[rn][g]=0; Pvalue[rn][g]=-1;
			Gout[rn][g]=0; Gnu[rn][g]=0; 
			Stdev[rn][g]=0; LogStdev[rn][g]=0;
		}	
		for (k=1;k<=ArrayNumber;k++)
		{
			Fout[rn][k]=0; Fnu[rn][k]=0;
		}

	}
	x = dmatrix(1,RN,1, r*ArrayNumber);
	xx = dmatrix(1,RN,1, r*ArrayNumber);
	y = dmatrix(1,RN,1, r*ArrayNumber);
	lxx = dmatrix(1,RN,1, r*ArrayNumber);
		
	for (g=1;g<=GeneNumber;g++)
	{ 
		for(rn=1;rn<=RN;rn++)
		{
			for(j=1;j<=r*ArrayNumber;j++)
			{
				x[rn][j] = RepeatRatio[g][rn][j];
				y[rn][j] = RepeatRatio[g][rn][j];
			}
			qsort(y[rn]+1,r*ArrayNumber,sizeof(double),fcompare);
			//quicksort(y[rn]+1,r*ArrayNumber);  //Sort  y in ascending order			
			for(j=1;j<=r*ArrayNumber;j++)
			{
				if(x[rn][j]==0)
				{   
					intmp=(int) ((j-1)/r);
					Fnu[rn][intmp+1]+=1;
					Gnu[rn][g]+=1;           // Number of zero values in x
				}
			}			
			Length[rn][g] = r*ArrayNumber - Gnu[rn][g];  // Number of non-zero values in x

			if (Length[rn][g] != 0 ) 
			{
			    for (j=1;j<=Length[rn][g];j++)
				{
					k=j+Gnu[rn][g];
					xx[rn][j]=y[rn][k];  // Assign non-zero values to xx	
				}
				if (Length[rn][g]==1) 
				{
					OverallMean[rn][g]=xx[rn][1];
					LogMean[rn][g]=log(xx[rn][1])/log(2.0);
					OverallMedian[rn][g]=xx[rn][1];
					Stdev[rn][g]=0;
					LogStdev[rn][g]=0;
					Pvalue[rn][g]=-1;
				}
				else if (Length[rn][g] == 2)
				{
					if ( (xx[rn][2] / xx[rn][1] > 8) || (xx[rn][2] / xx[rn][1] < 0.125) )
					{
						OverallMean[rn][g]=0;
						LogMean[rn][g]=-10000;
						OverallMedian[rn][g]=0;
						Stdev[rn][g]=0;
						LogStdev[rn][g]=0;
						Length[rn][g]=0;
						Pvalue[rn][g]=-1;
	
						for (j=1;j<=r*ArrayNumber;j++) 
						{
							if(x[rn][j]==xx[rn][1]) 
								Fout[rn][(int) ((j-1)/r) + 1] +=1;
							if (x[rn][j] == xx[rn][2]) 
								Fout[rn][(int)((j-1) /r) + 1] +=1;
						}
						Gout[rn][g]+=2;
					}
					else 
					{
						OverallMean[rn][g] = rMean(xx[rn],2);
						
						OverallMedian[rn][g] = rMedian(xx[rn],2);
						for(j=1;j<=2;j++)
							lxx[rn][j]=log(xx[rn][j])/log(2.0);
						LogMean[rn][g] = rMean(lxx[rn],2);
						Stdev[rn][g] = std(xx[rn],2);
						LogStdev[rn][g]=std(lxx[rn],2);
						
						t=2;
						Tstat[rn] = sqrt(2.0)*LogMean[rn][g]/LogStdev[rn][g];
						Pvalue[rn][g] = betai(0.5*(double)(t-1),0.5, (double)(t-1)/((double)(t-1)+Tstat[rn]*Tstat[rn]));
					}
				}
				else 
				{
					while (((rMean(xx[rn],Length[rn][g]) / rMedian(xx[rn],Length[rn][g]) > 2)||(rMean(xx[rn],Length[rn][g]) / rMedian(xx[rn],Length[rn][g]) < 0.5))&& (Length[rn][g]>2) )
					{
						if (rMean(xx[rn],Length[rn][g]) / rMedian(xx[rn],Length[rn][g]) > 2)
						{
							for(j=1;j<=r*ArrayNumber;j++)
							{
								if(x[rn][j]==xx[rn][Length[rn][g]]) 
									Fout[rn][(int) ((j-1)/r)+1]+=1;             
							}
							Gout[rn][g] +=1;
							Length[rn][g] -= 1;
						}
						else
						{
							for(j=1;j<=r*ArrayNumber;j++)
							{
								if(x[rn][j]==xx[rn][1]) 
									Fout[rn][(int) ((j-1)/r)+1]+=1;             
							}
							Gout[rn][g] +=1;
							Length[rn][g] -= 1;
							xx[rn]=xx[rn]+1;
						}
					}
					
		
					if (Length[rn][g] > 2) 
					{
						t=Length[rn][g];
						OverallMean[rn][g] = rMean(xx[rn],t);
						OverallMedian[rn][g] = rMedian(xx[rn],t);
						Stdev[rn][g] = std(xx[rn], t);

						for(j=1;j<=t;j++)
							lxx[rn][j]=log(xx[rn][j])/log(2.0);
						LogMean[rn][g] = rMean(lxx[rn],t);
						LogStdev[rn][g] = std(lxx[rn],t);
					    Tstat[rn] = LogMean[rn][g]*sqrt((double)(t))/LogStdev[rn][g];
						Pvalue[rn][g] = betai(0.5*(double)(t-1),0.5, (double)(t-1)/((double)(t-1)+Tstat[rn]*Tstat[rn]));
					}
					else if((xx[rn][2] /xx[rn][1] > 8)|| (xx[rn][2] /xx[rn][1] <0.125))
					{
						OverallMean[rn][g]=0;
						LogMean[rn][g]=-10000;
						OverallMedian[rn][g]=0;
						Length[rn][g]=0;
						Stdev[rn][g]=0;
						LogStdev[rn][g]=0;
						Pvalue[rn][g]=-1;
						for (j=1;j<=r*ArrayNumber;j++) 
						{
							if (x[rn][j] == xx[rn][1]) 
								Fout[rn][(int) ((j-1)/r) + 1] +=1;
							if (x[rn][j] == xx[rn][2]) 
								Fout[rn][(int) ((j-1)/r) + 1] +=1;
						}
						Gout[rn][g]+=2;
					}
					else 
					{
		                t=Length[rn][g];
						OverallMean[rn][g] = rMean(xx[rn],t);
						OverallMedian[rn][g] = rMedian(xx[rn],t);
						Stdev[rn][g] = std(xx[rn], t);
		
						for(i=1;i<=t;i++)
							lxx[rn][i]=log(xx[rn][i])/log(2.0);
						LogMean[rn][g] = rMean(lxx[rn],t);
						LogStdev[rn][g] = std(lxx[rn],t);
						Tstat[rn] = LogMean[rn][g]*sqrt((double)(t))/LogStdev[rn][g];
						Pvalue[rn][g] = betai(0.5*(double)(t-1),0.5, (double)(t-1)/((double)(t-1)+Tstat[rn]*Tstat[rn]));
		
					}
				}
			} 
		}
	}

	
	//for(g=1;g<=GeneNumber;g++) {printf("OverallMean[%d] = %lf\n",g,OverallMean[g]);getch();}
	MergeFile=cmatrix(1,RN,0,50);
//	for(i=1;i<=(ChannelNumber-1);i++)
//		for(j=(i+1);j<=ChannelNumber;j++)
//		{
//			r1=(int)(j-i+(i-1)*(2*ChannelNumber-i)/2);
//L2:			printf("Type in the file names you want save your merge results for ratio Ch%d/Ch%d.\n",(ra[r1]==1)*j+(ra[r1]==2)*i,(ra[r1]==2)*j+(ra[r1]==1)*i);
	for(r1=1;r1<=RN;r1++)
		{
			if(WebVersion==0)
			{
L2:				printf("Type in the file names you want save your merge results for ratio Case%d(Ch%d)/Control(Ch%d).\n",r1,Case[1][r1], ControlChannel[1]);
				scanf("%s", MergeFile[r1]);
				if ((fpout1= fopen(MergeFile[r1], "r")) != NULL)
				{ 
					printf("\aFile %s exists! Do you want to overwrite the file: <%s>?\n",MergeFile[r1],MergeFile[r1]);
					printf("Y----YES  or N----NO? Please choose Y or N.\n");
					scanf("%s", string);
					if(strcmp(string,"y")) goto L2;
				}
L3:				if ((fpout1= fopen(MergeFile[r1], "w")) == NULL)
				{ 
					printf("\aCannot write to the data file: <%s>.\n",MergeFile[r1]);
					printf("Close the Excel or other application which opens this file.\n");
				    printf("Then press any key to continue.\n");
					getch();
					goto L3;
					//exit(1);
				}
			}
			else 
			{
				strcpy(MergeFile[r1],"MergeFile");
				_itoa(r1,temp,10);
				strcat(MergeFile[r1],temp);
				strcat(MergeFile[r1],".txt");
				strcpy(UserID,tempID);
				strcat(UserID,MergeFile[r1]);
				strcpy(MergeFile[r1],UserID);
				fpout1= fopen(MergeFile[r1], "w");
			}


			fprintf(fpout1, "\n");
			fprintf(fpout1, "\n");
			fprintf(fpout1, "\t\t\t\tResults for Ratio: Case%d(Ch%d)/Control(Ch%d).\n\n",r1,Case[1][r1], ControlChannel[1]);
			fprintf(fpout1, "The number of data sets merged:\t\t\t\t\t %d\n", ArrayNumber);
			fprintf(fpout1,"The number of genes in each file:\t\t\t\t\t %d\n", GeneNumber);
			fprintf(fpout1,"The nummber of replicated spots in each file:\t\t\t\t\t %d\n\n", r);
	
			fprintf(fpout1, "Image Information:\n");
			if(YesNo==1)
			{
				fprintf(fpout1,"Since the experimental designs of all the data sets are the same,\n");
				fprintf(fpout1,"the following information is listed only for the first data set.\n\n\n");
			}
			for(k=1;k<=(YesNo==1)+(YesNo==0)*ArrayNumber;k++)
			{
				fprintf(fpout1,"  Data Set %d:\t\t %s\n", k, FileName[k]);
				fprintf(fpout1,"Channel (Fluor.)\t\tImage Files:\n");
				for(cn=1;cn<=ChannelNumber;cn++)
				{
					fprintf(fpout1,"%2.3s(%2.3s)\t%s\n", chnl[k][cn],dye[k][cn],img[k][cn]);
				}
				fprintf(fpout1, "\n");
			}
			fprintf(fpout1, "\n");

			fprintf(fpout1,"The number of spots not used in ratio calculation in each data set:\n");
		
		    for(k=1;k<=ArrayNumber;k++) fprintf(fpout1, "%s\t", FileName[k]);
			fprintf(fpout1, "\n");
			for(k=1;k<=ArrayNumber;k++) fprintf(fpout1,"%d\t", Fnu[r1][k]+Fout[r1][k]);

			fprintf(fpout1, "\n");
			fprintf(fpout1, "\n");

		    fprintf(fpout1,"The number of outliers found in each data set:\n");
			for(k=1;k<=ArrayNumber;k++)fprintf(fpout1,"%s\t", FileName[k]);
			fprintf(fpout1,"\n");

			for(k=1;k<=ArrayNumber;k++) fprintf(fpout1,"%d\t", Fout[r1][k]);

			fprintf(fpout1,"\n");
			fprintf(fpout1,"\n");


			fprintf(fpout1, "Number\t Name\t");
		
			for (k=1;k<=ArrayNumber;k++)fprintf(fpout1, "%s-Ratio\t", FileName[k]);
		    fprintf(fpout1, "Mean of Ratio\t");
			fprintf(fpout1, "StDev of Ratio\t");
			fprintf(fpout1, "Median of Ratio\t");
			fprintf(fpout1, "Mean of Log2-Ratio\t");
			fprintf(fpout1, "StDev of Log2-Ratio\t");
		    fprintf(fpout1, "P-Value(T-Test)\t");

		    fprintf(fpout1, "Spots used\t");
			fprintf(fpout1, "Outliers Found\n");
		
			for(g=1;g<=GeneNumber;g++)
			{
				if(r>1) fprintf(fpout1, "%3d-%3d\t", r*(g-1)+1, r*g);
				else fprintf(fpout1, "%3d\t", g);
				t1=0;
				while((GeneName[r*g][t1]!='\0')&&(GeneName[r*g][t1]!='\t'))
				{
					t1+=1;
				}
				if(t1>0) fprintf(fpout1,"%s\t", GeneName[r*g]);
				else fprintf(fpout1,"%s", GeneName[r*g]);

//				fprintf(fpout1, "%s\t", GeneName[r*g]);
            
				for(k=1;k<=ArrayNumber;k++) 
				{
					if(fabs(MeanRatio[k][r1][g])>1e05)
						fprintf(fpout1, "%.2e\t",MeanRatio[k][r1][g]);
					else fprintf(fpout1, "%lf\t",MeanRatio[k][r1][g]);
//					fprintf(fpout1, "%lf\t", MeanRatio[k][r1][g]);
				}
			
			
				if (Length[r1][g]!=0)
				{
					if(fabs(OverallMean[r1][g])>1e05)
						fprintf(fpout1, "%.2e\t",OverallMean[r1][g]);
					else fprintf(fpout1, "%lf\t",OverallMean[r1][g]);					
//					fprintf(fpout1, "%4.3lf\t",OverallMean[r1][g]);
					if(fabs(Stdev[r1][g])>1e05)
						fprintf(fpout1, "%.2e\t",Stdev[r1][g]);
					else fprintf(fpout1, "%lf\t",Stdev[r1][g]);					
//					fprintf(fpout1, "%4.3lf\t", Stdev[r1][g]);
					if(fabs(OverallMedian[r1][g])>1e05)
						fprintf(fpout1, "%.2e\t",OverallMedian[r1][g]);
					else fprintf(fpout1, "%lf\t",OverallMedian[r1][g]);					
//					fprintf(fpout1, "%4.3lf\t",OverallMedian[r1][g]);
					if(fabs(LogMean[r1][g])>1e05)
						fprintf(fpout1, "%.2e\t",LogMean[r1][g]);
					else fprintf(fpout1, "%lf\t",LogMean[r1][g]);					
//				    fprintf(fpout1, "%4.3lf\t",LogMean[r1][g]);
					if(fabs(LogStdev[r1][g])>1e05)
						fprintf(fpout1, "%.2e\t",LogStdev[r1][g]);
					else fprintf(fpout1, "%lf\t",LogStdev[r1][g]);					
//				    fprintf(fpout1, "%4.3lf\t", LogStdev[r1][g]);
				}
			   	else 
				{
					fprintf(fpout1, "-\t");
					fprintf(fpout1, "-\t");
				    fprintf(fpout1, "-\t");
		            fprintf(fpout1, "-\t");
		            fprintf(fpout1, "-\t");
				}
				if (Pvalue[r1][g]<0) fprintf(fpout1, "-\t");
				else fprintf(fpout1, "%lf\t", Pvalue[r1][g]);
	            fprintf(fpout1, "%d\t",Length[r1][g]);
	            fprintf(fpout1, "%d\n",Gout[r1][g]);
			}
			fclose(fpout1);
		}


	if(ChannelNumber==2)
		printf("\n\n\nOK!\n Check output files <%s> and <%s> for results.\n\n",MergeFile[1],DataFile);
	else 
	{
		printf("\n\n\n\t\t\tOK!\n\n\n Check output files ");
		printf(" %s, ", DataFile);
		for(i=1;i<=RN-1;i++)
		{
			printf("%s",MergeFile[i]);
			if(i<RN-1) printf(", ");
		}
		printf("  and %s  for results.\n\n",MergeFile[RN]);
	}
	printf("Please send bug reports to zhong.guan@yale.edu.\n\n");
	if(WebVersion==0)
	{
		printf("\n\nPress Any Key to Exit.\n");
		getch();
	}
	free_dmatrix(Filter,1,ArrayNumber,1,SpotNumber);
	free_darray(MeanRatio, 1, ArrayNumber,1, RN, 1, GeneNumber);
	free_imatrix(Fout,1,RN,1,ArrayNumber);
	free_imatrix(Gout,1,RN,1,GeneNumber);
	free_imatrix(Length,1,RN,1,GeneNumber);
	free_imatrix(Fnu,1,RN,1,ArrayNumber);
	free_imatrix(Gnu,1,RN,1,GeneNumber);
	free_darray(RepeatRatio, 1,GeneNumber,1,RN,1,r*ArrayNumber);
	free_darray(MeanLogIntensity,1,ArrayNumber,1, ChannelNumber, 1, GeneNumber);
	free_dmatrix(lxx,1,RN,1,r*ArrayNumber);
	free_dmatrix(xx,1,RN,1,r*ArrayNumber);
	free_dmatrix(x,1,RN,1,r*ArrayNumber);
	free_dmatrix(y,1,RN,1,r*ArrayNumber);
	free_ivector(ControlChannel,1,ArrayNumber);
	free_imatrix(Case,1,ArrayNumber,1,ChannelNumber-1);
	free_cmatrix(GeneName,1,SpotNumber,0,500);
	free_cmatrix(FileName,1,ArrayNumber,0,50);
	free_cmatrix(MergeFile,1,RN,0,50);
	free_carray(chnl,1,ArrayNumber,1, ChannelNumber,0,10);
	free_carray(dye,1,ArrayNumber,1, ChannelNumber,0,10);
	free_carray(img,1,ArrayNumber,1, ChannelNumber,0,100);
	free_imatrix(LT,0,ArrayNumber-1,0,ChannelNumber-1);
	free_ivector(ord, 0,ChannelNumber-1);
	free_dmatrix(OverallMean,1,RN,1,GeneNumber);
	free_dmatrix(LogMean,1,RN,1,GeneNumber);
	free_dmatrix(Stdev,1,RN,1,GeneNumber);
	free_dmatrix(LogStdev,1,RN,1,GeneNumber);
	free_dmatrix(OverallMedian,1,RN,1,GeneNumber);
	free_dmatrix(Pvalue,1,RN,1,GeneNumber);
	free_dvector(Tstat,1,GeneNumber);
//	free_dmatrix(M, 1, RN*ArrayNumber,1,SpotNumber);
//	free_dmatrix(A, 1, ArrayNumber,1,SpotNumber);
}


void ErrorMessage(char error_text[])
{
        void exit(int);

        fprintf(stderr,"Run-time error...\n");
        fprintf(stderr,"%s\n",error_text);
        fprintf(stderr,"...now exiting to system...\n");
        exit(1);
}
                 

double **dmatrix(int nrl,int nrh,int ncl,int nch)
{
        int i;
        double **m;

        m=(double **) malloc((unsigned) (nrh-nrl+1)*sizeof(double*));
        if (!m) ErrorMessage("allocation failure 1 in dmatrix()");
        m -= nrl;

        for(i=nrl;i<=nrh;i++) {
                m[i]=(double *) malloc((unsigned) (nch-ncl+1)*sizeof(double));
                if (!m[i]) ErrorMessage("allocation failure 2 in dmatrix()");
                m[i] -= ncl;
        }
        return m;
}


void free_dmatrix(double **m, int nrl, int nrh, int ncl, int nch)
{
        int i;

        for(i=nrh;i>=nrl;i--) free((char*) (m[i]+ncl));
        free((char*) (m+nrl));
}

//  Function of ***darray(int ml, int mh, int nl, int nh, int pl, int ph)

double ***darray(int ml, int mh, int nl, int nh, int pl, int ph)
{
	int i;
	double ***a;

        a=(double ***) malloc((unsigned) (mh-ml+1)*sizeof(double**));
        if (!a) ErrorMessage("allocation failure in darray()");
        a -= ml;

        for(i=ml;i<=mh;i++) 
		{
			a[i]=dmatrix(nl, nh, pl, ph);
        }
        return a;
}


void free_darray(double ***a, int ml, int mh, int nl, int nh, int pl, int ph)
{
    int i;

    for(i=mh;i>=ml;i--) free_dmatrix(a[i], nl, nh, pl, ph);
}

int **imatrix(int nrl,int nrh,int ncl,int nch)
{
        int i, **m;

        m=(int **) malloc((unsigned) (nrh-nrl+1)*sizeof(int*));
        if (!m) ErrorMessage("allocation failure 1 in imatrix()");
        m -= nrl;

        for(i=nrl;i<=nrh;i++) {
                m[i]=(int *) malloc((unsigned) (nch-ncl+1)*sizeof(int));
                if (!m[i]) ErrorMessage("allocation failure 2 in imatrix()");
                m[i] -= ncl;
        }
        return m;
}


void free_imatrix(int **m, int nrl, int nrh, int ncl, int nch)
{
        int i;

        for(i=nrh;i>=nrl;i--) free((char*) (m[i]+ncl));
        free((char*) (m+nrl));
}


int ***iarray(int ml, int mh, int nl, int nh, int pl, int ph)
{
	int i, ***a;

        a=(int ***) malloc((unsigned) (mh-ml+1)*sizeof(int **));
        if (!a) ErrorMessage("allocation failure in iarray()");
        a -= ml;

        for(i=ml;i<=mh;i++) 
		{
			a[i]=imatrix(nl, nh, pl, ph);
        }
        return a;
}


void free_iarray(int ***a, int ml, int mh, int nl, int nh, int pl, int ph)
{
    int i;

    for(i=mh;i>=ml;i--) free_imatrix(a[i], nl, nh, pl, ph);
}


char **cmatrix(int nrl,int nrh,int ncl,int nch)
{
        int i;
        char **m;

        m=(char **) malloc((unsigned) (nrh-nrl+1)*sizeof(char *));
        if (!m) ErrorMessage("allocation failure 1 in cmatrix()");
        m -= nrl;

        for(i=nrl;i<=nrh;i++) {
                m[i]=(char *) malloc((unsigned) (nch-ncl+1)*sizeof(char));
                if (!m[i]) ErrorMessage("allocation failure 2 in cmatrix()");
                m[i] -= ncl;
        }
        return m;
}


void free_cmatrix(char **m, int nrl, int nrh, int ncl, int nch)
{
        int i;

        for(i=nrh;i>=nrl;i--) free((char*) (m[i]+ncl));
        free((char*) (m+nrl));
}


char ***carray(int ml, int mh, int nl, int nh, int pl, int ph)
{
	int i;
	char ***a;

        a=(char ***) malloc((unsigned) (mh-ml+1)*sizeof(char **));
        if (!a) ErrorMessage("allocation failure in carray()");
        a -= ml;

        for(i=ml;i<=mh;i++) 
		{
			a[i]=cmatrix(nl, nh, pl, ph);
        }
        return a;
}


void free_carray(char ***a, int ml, int mh, int nl, int nh, int pl, int ph)
{
    int i;

    for(i=mh;i>=ml;i--) free_cmatrix(a[i], nl, nh, pl, ph);
}

double *dvector(int nl,int nh)                                       
{                                                                    
        double *v;                                                   
                                                                     
        v=(double *)malloc((unsigned) (nh-nl+1)*sizeof(double));     
        if (!v) ErrorMessage("allocation failure in dvector()");          
        return v-nl;                                                 
}                                                                    

void free_dvector(double *v, int nl, int nh)
{
        free((char*) (v+nl));
}

int *ivector(int nl,int nh)
{
        int *v;

        v=(int *)malloc((unsigned) (nh-nl+1)*sizeof(int));
        if (!v) ErrorMessage("allocation failure in ivector()");
        return v-nl;
}

void free_ivector(int *v, int nl, int nh)
{
        free((char*) (v+nl));
}
          
char *cvector(int nl,int nh)
{
        char *v;

        v=(char *)malloc((unsigned) (nh-nl+1)*sizeof(char));
        if (!v) ErrorMessage("allocation failure in cvector()");
        return v-nl;
}

void free_cvector(char *v, int nl, int nh)
{
        free((char*) (v+nl));
}


double rMean(double *x, int s)
{
	int i;
	double sum;
	sum = 0.0;
	for (i=1;i<=s;i++) sum += x[i];
    sum = sum / s; 
    return sum;
}

double rMedian(double *x, int s)
{
	int i;
	double *vec;
    double mdn;
	void quicksort(double *, int);
    vec = dvector(0,s);
	
    for(i=0; i<=s-1; i++) *(vec + i) = x[i+1];
    quicksort(vec, s); 
	if ( s % 2 == 0) mdn = 0.5*(vec[ (int) (s/2) -1] + vec[(int) (s/2)]);
	else mdn = vec[(int) ((s-1)/2)];	

    free_dvector(vec, 0,s);
	return mdn;
     
}

double std(double *x, int s)
{
	if(s<=1) ErrorMessage("Sample size must be greater that 1 when calculating Stdev!");
	int i;
	double mean,sum;
	mean = 0;
	sum=0;
	for(i=1;i<=s;i++) mean+=x[i];
	mean = mean / (double) s;
	for(i=1;i<=s;i++) sum += (x[i]-mean)*(x[i]-mean);
	sum = sqrt(sum / (double) (s-1));
	return sum;
}
     
double rand1()                                             
{    double t;                                             
     int t1;                                               
     RX=(171*RX)%30269;                                    
     RY=(172*RY)%30309;                                    
     RZ=(170*RZ)%30323;                                    
     t=(double)(RX/30269.0+RY/30309.0+RZ/30323.0);         
     t1=(int)(t);                                          
     return(t-t1);                                         
}                                                          
                                                           
//subroutine to sort a vector;                             
void quicksort(double *vec, int leng)                      
{                                                          
        double a, *b;                                      
        int i, k, begin, end;                              
        b=dvector(0,leng);                                 
        if(leng<=1)return;                                 
        if(leng==2)                                        
        {                                                  
                if(vec[0]>vec[1])                          
                {                                          
                        a=vec[0];                          
                        vec[0]=vec[1];                     
                        vec[1]=a;                          
                }                                          
                return;                                    
        }                                                  
        k=(int)(rand1()*leng);                             
        for(i=0;i<leng;i++) b[i]=vec[i];                   
        begin=0;end=0;                                     
    for(i=0;i<leng;i++)                                    
        {                                                  
                if((i!=k)&&(b[i]>=b[k]))                   
                {                                          
                        vec[leng-1-end]=b[i];              
                        end++;                             
                }                                          
                if((i!=k)&&(b[i]<b[k]))                    
                {                                          
                        vec[begin]=b[i];                   
                        begin++;                           
                }                                          
        }                                                  
        vec[begin]=b[k];                                   
        if(begin==0)                                       
                quicksort(vec+1,leng-1);                   
        else if(end==0)                                    
                quicksort(vec,leng-1);                     
        else                                               
        {                                                  
                quicksort(vec,begin);                      
                quicksort(vec+begin+1,end);                
        }                                                  
        free_dvector(b,0,leng);                            
}                                                          

int factorial(int n)
{
	int mul,i;
	for(i=1;i<=n;i++)
	{
		mul*=i;
	}
	return mul;
}



int skipLine(FILE *fp, int num)
{
	int k=0;
	char ch;
	while(k<num)
	{
		for(;;)
		{
			ch=getc(fp);
//			if(ch==EOF&&k<num)
//				return(-k);
			if(ch=='\n')
			{
				k++;
				break;
			}
		}
	}
	return(num);
//  Skip the lines of a text file when read from or write to file.
//  Input
//		fp: the file pointer that can be read;
//		num: the number of lines that be skipped.
//	Return:
//		The function will return a negative integer that represents the total number
//		of this file when it is less than the number of lines that be skipped, otherwise
//		it will return the number of lines that be skipped.
}

// The following function calculates the incomplete beta function
double betai(double a, double b, double x)
{
	double betacf(double a, double b, double x);
	double gammln(double xx);
	void ErrorMessage(char error_text[]);
	double bt;
	if (x < 0.0 || x > 1.0) ErrorMessage("Bad x in routine betai");
	if (x == 0.0 || x == 1.0) bt=0.0;
	else bt=exp(gammln(a+b)-gammln(a)-gammln(b)+a*log(x)+b*log(1.0-x));
	if (x < (a+1.0)/(a+b+2.0)) 
		return bt*betacf(a,b,x)/a;
	else 
		return 1.0-bt*betacf(b,a,1.0-x)/b;
}


double betacf(double a, double b, double x)
{
	void ErrorMessage(char error_text[]);
	int m,m2;
	double aa,c,d,del,h,qab,qam,qap;
	qab=a+b; 
	qap=a+1.0;
	qam=a-1.0;
	c=1.0; 
	d=1.0-qab*x/qap;
	if (fabs(d) < FPMIN) d=FPMIN;
	d=1.0/d;
	h=d;
	for (m=1;m<=MAXIT;m++) 
	{
		m2=2*m;
		aa=m*(b-m)*x/((qam+m2)*(a+m2));
		d=1.0+aa*d; 
		if (fabs(d) < FPMIN) d=FPMIN;
		c=1.0+aa/c;
		if (fabs(c) < FPMIN) c=FPMIN;
		d=1.0/d;
		h *= d*c;
		aa = -(a+m)*(qab+m)*x/((a+m2)*(qap+m2));
		d=1.0+aa*d; 
		if (fabs(d) < FPMIN) d=FPMIN;
		c=1.0+aa/c;
		if (fabs(c) < FPMIN) c=FPMIN;
		d=1.0/d;
		del=d*c;
		h *= del;
		if (fabs(del-1.0) < EPS) break; 
	}

	if (m > MAXIT) ErrorMessage("a or b too big, or MAXIT too small in betacf");
	return h;
}

double gammln(double xx)
{
        double x,tmp,ser;
        static double cof[6]={76.18009173,-86.50532033,24.01409822,
                -1.231739516,0.120858003e-2,-0.536382e-5};
        int j;

        x=xx-1.0;
        tmp=x+5.5;
        tmp -= (x+0.5)*log(tmp);
        ser=1.0;
        for (j=0;j<=5;j++) 
		{
            x += 1.0;
            ser += cof[j]/x;
        }
        return -tmp+log(2.50662827465*ser);
}


double Rank(double y, double *x, int leng)
{
	int i,k;
	double rnk=0.0,*z;
	z=dvector(0,leng);
	for(i=0;i<leng;i++)
		z[i]=x[i];
	quicksort(z,leng);
	k=0;
	for(i=0;i<leng;i++)
	{
		if(z[i]==y)
		{
			k+=1;
			rnk=i;
		}
	}
	free_dvector(z,0,leng);
	rnk=rnk-(double)((k-3.0)/2.0);
	return(rnk);

}





// Begin Rank Invariant Set Selection
void RankInvarSet(double **data, int leng, int cn, int d, int l,int *RnkInvSet, int t)
{
	// Returns Rank Invariant Set defined by Tseng et al. (Nucleic Acids Research, 2001, Vo. 29, 
    // No. 12,  2549-2557;)
    // d and l are the threshold values; 

	double *MeanByGene, temp1, temp2;
	int i, j, k;//, leng;
	//leng = Length(x[1]);
	//RnkInvSet = ivector(1,leng);
	MeanByGene=dvector(1,leng);
	for(k=1; k<=leng; k++)
	{
		MeanByGene[k]=0.0;
		for(i=1;i<=cn;i++)
			MeanByGene[k]+=data[i][k];
		MeanByGene[k]/=cn;
	}
	for(k=1; k<=leng; k++)
		for(i=1;i<=cn-1; i++)
			for(j=i+1;j<=cn;j++)
			{
				temp1=fabs(Rank(data[i][k],data[i],leng)-Rank(data[j][k],data[j],leng));
				temp2=Rank(MeanByGene[k],MeanByGene,leng);
				if((temp1<d)&&(temp2<leng-l)&&(temp2>l))
				{
					t+=1;
					RnkInvSet[t]=k;
				}
			}
	//RnkInvSet=ivector(1,t);
	//for(k=1;k<=t;k++) RnkInvSet[k]=ind[k];
	//free_ivector(RnkInvSet,1,leng);
	//free_ivector(ind,1,leng);
	//free_dvector(MeanByGene,1,leng);
	//return(RIS);
}

void IterRankInvarSet(double **data, int leng, int cn, double p, int l, int *RnkInvSet, int t)
{
	// Returns Rank Invariant Set defined by Tseng et al. (Nucleic Acids Research, 2001, Vo. 29, 
    // No. 12,  2549-2557;)
    // d and l are the threshold values; p=percentage

	double **temp;
	int *ind, *ind1, i, k, s=leng, d;
	d=(int) (p*leng);
	ind = ivector(1,leng);

	RankInvarSet(data, leng, cn, d, l, ind, s);
	ind1 = ivector(1,s);
	for(k=1;k<=s;s++) ind1[k]=ind[k];
	
	while(s!=leng)
	{
		leng=s; 
			
		temp=dmatrix(1,cn,1,leng);

		for(k=1; k<=leng; k++)
		{
			for(i=1;i<=cn;i++)
			{
				temp[i][k]=data[i][ind[k]];
			}
		}
				
		RankInvarSet(temp, leng, cn, d, l, ind, s);
		d=(int) (p*s);
		for(k=1;k<=s;s++) ind1[k]=ind1[ind[k]];
	}
	//RIS=ivector(1,s); 
	for(k=1;k<=s;s++) RnkInvSet[k]=ind1[k];
	t=s;
	free_ivector(ind1,1,leng);
	free_ivector(ind,1,leng);
}


void lowess_normalization(double **data, int leng, int cn, double f, int nsteps, double pct)//, double p, int d, int l)
{
	int   i, j, k,   *ord, *ord1;//, *RIS, temp;
	double  /*f=2.0/3.0, */ delta=0.05, *M,  *A,  *ys, *ys1, *rw, *res, *M1;//, *A1,max, min;
	void lowess(double *, double *, int * , double *, int *, double *, double *, double *, double *);
	void forder(double *, int, int *),iorder(int *, int, int *);
/*	RIS=ivector(1,leng);
	if(leng>1000)
	{
		IterRankInvarSet(x, leng, cn, p, l, RIS, t);
	}
	else
	{
		RankInvarSet(x, leng, cn, d, l, RIS, t);
	}*/
	//RN=(int)(cn*(cn-1)/2);
   	M = dvector( 0, leng-1);
   	M1 = dvector( 0, leng-1);

    A =	dvector( 0, leng-1);
	//A1 =	dvector( 0, leng-1);
	ord= ivector( 0, leng-1);
	ord1= ivector( 0, leng-1);
	ys = dvector( 0, leng-1);
	ys1 = dvector( 0, leng-1);
	rw =dvector(0, leng-1);
	res= dvector( 0, leng-1);
	//indc=dvector( 1, leng);

                    //Calculating M and A
	for(k=0;k<leng;k++)
	{
		A[k] = 1;
		for(j=1;j<=cn;j++)
		{
			if(data[j][k+1]>0)
				A[k]*=data[j][k+1];
		}
		A[k]=log(A[k])/cn;
		if(k%1000==0) printf(".");
		if(k>=100000 && k%100000==0) printf("\n");
	}

	i=1;
	for(j=i+1;j<=cn;j++)
	{
		for(k=0;k<leng;k++)
		{
			M[k] =log((data[j][k+1]*(data[j][k+1]>0)+(data[j][k+1]<=0))
				/(data[i][k+1]*(data[i][k+1]>0)+(data[i][k+1]<=0)));
			//printf("M[%d]=%f\t A[%d]=%f\n",k,M[k], k, A[k]);
			if(k%1000==0) printf(".");
		}
		//getch();
		forder(A,leng,ord);
		qsort(A, leng, sizeof(double), fcompare);
		delta=pct*(A[leng-1]-A[0]);
		for(k=0;k<leng;k++)
		{
			M1[k]=M[ord[k]-1];
			//printf("M[%d]=%f\t A[%d]=%f\n",k,M1[k], k, A[k]);
			if(k%1000==0) printf(".");
		}

		lowess(A, M1, &leng, &f, &nsteps, &delta, ys, rw, res);
		iorder(ord,leng,ord1);
		for(k=0;k<leng;k++)
		{
			ys1[k]=ys[ord1[k]-1];
			//printf("ys[%d]=%f\n", k, ys[k]);
			data[j][k+1]=data[j][k+1]/exp(ys1[k]);
			if(k%1000==0) printf(".");
		}
		//printf("j=%d\n",j);
		//getch();
	}  
/*	max=Max(A); min=Min(A);
	temp=0;
	for(k=1;k<=leng;k++)
	{
		if((A[k]<=max) && (A[k]>=min))
		{
			temp+=1; 
			ind[temp]=k;
		}
	}*/
	  //delta should be taken to be around 0.01*range(A)
	//n=&leng;  
	//f=&f0;//
	//f=2.0/3.0; 
	//nsteps=&steps; 
	//delta=&delta0;//2/100;
	/*i=1;
	for(j=i+1;j<=cn;j++)
	{
		r=(int) (j-i+(i-1)*(2*cn-i)/2);
		clowess(A, M[r], leng, f, nsteps, delta, ys, rw, res);
		for(k=1;k<=leng;k++)
		{
			printf("ys[%d]=%f\n",k,ys[k]);
			x[j][k]=x[j][k]/exp(ys[k]);
		}
	}*/
	//printf("In lowess nomalization \n");
	//free_ivector(RIS,1,leng);
	free_dvector(A,0,leng-1);
	//free_dvector(A1,0,leng-1);

	free_dvector(M, 0, leng-1);
	free_dvector(M1, 0, leng-1);
	free_dvector(ys1,0,leng-1);
	free_dvector(ys,0,leng-1);
	free_dvector(rw,0,leng-1);
	free_dvector(res,0,leng-1);
	free_ivector(ord, 0,leng-1);
	free_ivector(ord1, 0,leng-1);

/*	M1 = dmatrix( 1, RN,1,t);
	A1 = dvector( 1, t);

	for(k=1;k<=t;k++)
	{
		A1[k]=A[RIS[k]];
		for(r=1;r<=RN;r++)
			M1[r][k]=M[r][RIS[k]];
	}

	delta=0.2;  //delta should be taken to around 0.01*range(A)
	i=1;
	for(j=i+1;j<=cn;j++)
	{
		r=(int) (j-i+(i-1)*(2*cn-i)/2);
		lowess(A1, M1[r], temp, 2/3, 3, delta, ys, rw, res);
		for(k=1;k<=temp;k++)			
			x[j][ind[k]]=x[j][ind[k]]/exp(ys[ind[k]]);
	}
	if(temp!=leng)
	{
		temp1=0;
		for(k=1;k<=leng;k++)
		{
			for(i=1;i<=temp;i++)
			{
				if(k!=ind[i])
				{
					temp1+=1;
					indc[temp1]=k;
				}
			}
		}
		*/

}       


/*
 *  R : A Computer Language for Statistical Data Analysis
 *  Copyright (C) 1996  Robert Gentleman and Ross Ihaka
 *  Copyright (C) 1999-2001   Robert Gentleman, Ross Ihaka and the
 *                            R Development Core Team
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */


static double fsquare(double x)
{
    return x * x;
}

static double fcube(double x)
{
    return x * x * x;
}

static void lowest(double *x, double *y, int n, double *xs, double *ys,
	int nleft, int nright, double *w, bool userw, double *rw, bool *ok)
{
    int nrt, j;
    double a, b, c, h, h1, h9, r, range, fmax2(double,double);

    x--;
    y--;
    w--;
    rw--;

    range = x[n]-x[1];
    h = fmax2(*xs-x[nleft], x[nright]-*xs);
    h9 = 0.999*h;
    h1 = 0.001*h;

    /* sum of weights */

    a = 0.0;
    j = nleft;
    while (j <= n) 
	{

		/* compute weights */
		/* (pick up all ties on right) */

		w[j] = 0.0;
		r = fabs(x[j] - *xs);//Absolute value
		if (r <= h9) 
		{
		    if (r <= h1)
				w[j] = 1.0;
		    else
				w[j] = fcube(1.0-fcube(r/h));
		    if (userw)
				w[j] *= rw[j];
		    a += w[j];
		}
		else if (x[j] > *xs)
		    break;
		j = j+1;
    }

    /* rightmost pt (may be greater */
    /* than nright because of ties) */

    nrt = j-1;
    if (a <= 0.0)
		*ok = false;
    else 
	{
		*ok = true;

		/* weighted least squares */
		/* make sum of w[j] == 1 */

		for(j=nleft ; j<=nrt ; j++)
		    w[j] /= a;
		if (h > 0.0) 
		{
		    a = 0.0;

		    /*  use linear fit */
		    /* weighted center of x values */

		    for(j=nleft ; j<=nrt ; j++)
				a += w[j] * x[j];
		    b = *xs - a;
		    c = 0.0;
		    for(j=nleft ; j<=nrt ; j++)
				c += w[j]*fsquare(x[j]-a);
		    if (sqrt(c) > 0.001*range) 
			{
				b /= c;

				/* points are spread out */
				/* enough to compute slope */

				for(j=nleft; j <= nrt; j++)
				    w[j] *= (b*(x[j]-a) + 1.0);
			}
		}
		*ys = 0.0;
		for(j=nleft; j <= nrt; j++)
			*ys += w[j] * y[j];
    }
}

static
void clowess(double *x, double *y, int n,
	     double f, int nsteps, double delta,
	     double *ys, double *rw, double *res)
{
    int i, iter, j, last, m1, m2, nleft, nright, ns;
    bool ok;
	int imax2(int, int), imin2(int,int);
    double alpha, c1, c9, cmad, cut, d1, d2, denom, r;

    if (n < 2) 
	{
		ys[0] = y[0]; 
		return;
    }

    /* nleft, nright, last, etc. must all be shifted to get rid of these: */
    x--;
    y--;
    ys--;


    /* at least two, at most n points */
    ns = imax2(2, imin2(n, (int)(f*n + 1e-7)));

    /* robustness iterations */

    iter = 1;
    while (iter <= nsteps+1) 
	{
		nleft = 1;
		nright = ns;
		last = 0;	/* index of prev estimated point */
		i = 1;		/* index of current point */

		for(;;) 
		{
		    if (nright < n) 
			{
	
				/* move nleft,  nright to right */
				/* if radius decreases */

				d1 = x[i] - x[nleft];
				d2 = x[nright+1] - x[i];

				/* if d1 <= d2 with */
				/* x[nright+1] == x[nright], */
				/* lowest fixes */

				if (d1 > d2) 
				{
				    /* radius will not */
				    /* decrease by */
				    /* move right */

				    nleft++;
				    nright++;
				    continue;
				}
		    }

		    /* fitted value at x[i] */
		    lowest(&x[1], &y[1], n, &x[i], &ys[i],
			   nleft, nright, res, iter>1, rw, &ok);
		    if (!ok) ys[i] = y[i];

		    /* all weights zero */
		    /* copy over value (all rw==0) */

		    if (last < i-1) 
			{
				denom = x[i]-x[last];

				/* skipped points -- interpolate */
				/* non-zero - proof? */

				for(j = last+1; j < i; j++) 
				{
				    alpha = (x[j]-x[last])/denom;
				    ys[j] = alpha*ys[i] + (1.0-alpha)*ys[last];
				}
		    }

		    /* last point actually estimated */
		    last = i;

		    /* x coord of close points */
		    cut = x[last]+delta;
		    for (i = last+1; i <= n; i++) 
			{
				if (x[i] > cut)
				    break;
				if (x[i] == x[last]) 
				{
				    ys[i] = ys[last];
				    last = i;
				}
		    }
		    i = imax2(last+1, i-1);
		    if (last >= n)
				break;
		}
		/* residuals */
		for(i=0; i < n; i++)
		    res[i] = y[i+1] - ys[i+1];

		/* compute robustness weights */
		/* except last time */

		if (iter > nsteps)
		    break;
		/* Note: The following code, biweight_{6 MAD|Ri|} 
		   is also used in stl(), loess and several other places.
		   --> should provide API here (MM) */
		for(i=0 ; i<n ; i++)
		    rw[i] = fabs(res[i]);

		/* Compute   cmad := 6 * median(rw[], n)  ---- */
		/* FIXME: We need C API in R for Median ! */
		m1 = n/2;
		/* partial sort, for m1 & m2 */
		//rPsort(rw, n, m1);
		
		qsort(rw,n,sizeof(double),fcompare);
		if(n % 2 == 0)  // if n is an even number
		{
		    m2 = n-m1-1;
		    //rPsort(rw, n, m2);
			//quicksort(rw,n);
		    cmad = 3.0*(rw[m1]+rw[m2]);
		} 
		else 
		{ /* n odd */
		    cmad = 6.0*rw[m1];
		}
		c9 = 0.999*cmad;
		c1 = 0.001*cmad;
		for(i=0 ; i<n ; i++) 
		{
		    r = fabs(res[i]);
		    if (r <= c1)
				rw[i] = 1.0;
		    else if (r <= c9)
				rw[i] = fsquare(1.0-fsquare(r/cmad));
		    else
				rw[i] = 0.0;
		}
		iter++;

    }
}

void lowess(double *x, double *y, int *n,
	    double *f, int *nsteps, double *delta,
	    double *ys, double *rw, double *res)
{
    clowess(x, y, *n, *f, *nsteps, *delta, ys, rw, res);
}


double fmax2(double x, double y)
{
	return (x < y) ? y : x;
}


int imin2(int x, int y)
{
    return (x < y) ? x : y;
}


int imax2(int x, int y)
{
    return (x < y) ? y : x;
}

        



// Functio order Returns an integer vector containing 
//the permutation that will sort the input into ascending order. 

void forder(double *vec, int leng, int *ord)
{
	int i, j;
	double *temp,*z;
	z=dvector(0,leng-1);
	temp=dvector(0,leng-1);
	for(i=0;i<leng;i++)
	{
		z[i]=vec[i];
		temp[i]=z[i];
	}
	//quicksort(z,leng);
	qsort(z, leng, sizeof(double), fcompare);
	for(i=0;i<leng;i++)
	{
		for(j=leng-1;j>=0;j--)
		{
			if(z[i]==temp[j])
			{
				ord[i]=j+1;
			}
		}
		temp[ord[i]-1]=z[0]-1000.0;
	}
	free_dvector(z,0,leng-1);
	free_dvector(temp,0,leng-1);
	
}


int compare (const void * a, const void * b)
{
	return ( *(int*)a - *(int*)b );
}


void iorder(int *vec, int leng, int *ord)
{
	int i, j,*temp,*z;
		z=ivector(0,leng-1);
		temp=ivector(0,leng-1);
	for(i=0;i<leng;i++)
	{
		z[i]=vec[i];
		temp[i]=z[i];
	}
	qsort(z, leng, sizeof(int), compare);
	for(i=0;i<leng;i++)
	{
		for(j=leng-1;j>=0;j--)
		{
			if(z[i]==temp[j])
			{
				ord[i]=j+1;
			}
		}
		temp[ord[i]-1]=z[0]-100;
	}
	free_ivector(z,0,leng-1);
	free_ivector(temp,0,leng-1);
	
}



/////////////////////////////////////////////////////
//    ANOVA Procedure for Microarray Data Analysis //
/////////////////////////////////////////////////////
/* data= input, LOGARITHMS of original or normalized data values
   leng= input, the TOTAL NUMBER OF SPOTS
     cn= input, the NUMBER OF CHANNELS
	 fn= input, the NUMBER OF FILES (ARRAYS), 
					for Latin Square Experimental Design, fn=cn
	 LT= input, cn by cn Latin Square Matrix, 
					entry is j=LT[i][k]: in i-th array, k-th channel, j-th dye is used
  model= input, model number:
     ra= input, determines the ratios to be considered

  Output results are the ewstimated fold changes and the corresponding 
  P-values based on T tests and are written in an output file 
  with default file name <AnovaTable.txt>.
	 
	    model 1: log(y)=mu+Ai+Dj+Vk+Gg+(AG)ig+(DG)jg+(VG)kg+Eijkg 
              2: log(y)=mu+Ai+Dj+Vk+Gg+(AG)ig+(VG)kg+Eijkg
              3: log(y)=mu+Ai+Vk+Gg+(AG)ig+(VG)kg+Eijkg
              4: log(y)=mu+Ai+Vk+Gg+(VG)kg+Eijkg

  where mu is the overall average signal, Ai represents the effect 
  of the i-th array, Dj represents the effect of the j-th dye, Vk represents
  the effect of the k-th variaty, Gg represents the effect of the g-th gene, (AG)ig
  represents a combination of array i and gene g (i.e., a particular spot on a particular array),
  and (VG)kg represents the interaction between the k-th variety and the g-th gene, 
  finally, (DG)jg represents the interaction between the j-th dye and g-th gene.


  References: 1. Kerr, M.K., Matin, M. and Churchill, G.A.(2000) Analysis of vaiance 
			 for gene expression microarray. J. Comput. Biol., 7, 819-837.
			  2. Kerr, M.K. and Churchill, G.A.(2001) Experimental design  
			 for gene expression microarray. Biostatistics, 2:183-201. 

  */
void ANOVA4Microarray(int Version, double ***data,int rep, char **GeneName, 
					  int leng, int an, int cn, int **LT, int *Control, int **Case, char *UserID, 
					  char tempID[], FILE *parameter)
{

	int t1,itemp2=0, i, j, model, g, acn=an*cn,cnleng=cn*leng, **ind, r1, TryAgain=0, nModel=0;//itemp1, model,
	int DF[7]={an-1,cn-1,leng-1,(cn-1)*(leng-1),(an-1)*(leng-1),(cn-1)*(an-1)*leng, an*cnleng-1};
	double  SS[7]={0.0,0.0,0.0,0.0,0.0,0.0,0.0}, MS[7], F[7], Pval[7];
	double mu, *Ti, *Tk, *Tg, **Tig, **Tkg;//, **Tjg, *Tj;
	double dtemp0=0.0, dtemp1=0.0, dtemp2=0.0, ***Res, ***zhat, *A, *V, *G, **AG, **VG;//, **DG, *D;
	char  string[10], **AnovaTabl, temp[50];//AnovaTbl[50]="AnovaTable.txt";
	void iorder(int *, int, int*);
	FILE *fpout1;
	
	static char *Source[]=
	{
		"          Array",
//		"            Dye",
		"        Variety",
		"           Gene",
//		"     Dye x Gene",
		" Variety x Gene",
		"   Array x Gene",
		"       Residual",
		"Corrected Total"
	};
	
	AnovaTabl=cmatrix(0,1,0,50);
	strcpy(AnovaTabl[0],"AnovaTable1.txt");
	strcpy(AnovaTabl[1],"AnovaTable2.txt");

L8:	if(TryAgain==0) 
	{
		printf("You can choose a model from the following:\n\n");
	//	printf("Model 1:     log(y)=mu+Ai+Dj+Vk+Gg+(AG)ig+(DG)jg+(VG)kg+Eijkg\n\n");
	//	printf("Model 2:     log(y)=mu+Ai+Dj+Vk+Gg+(AG)ig+(VG)kg+Eijkg\n\n");
		printf("Model 1:     log(y)=mu+Ai+Vk+Gg+(AG)ig+(VG)kg+Eikg\n\n");
		printf("Model 2:     log(y)=mu+Ai+Vk+Gg+(VG)kg+Eikg\n");
		printf("\n\n");
	//	printf("If you have chosen Lowess Fit Normalization, I suggest you use model 3 or 4.\n\n");
	//	printf("Please make your choice by entering 1, 2, 3, or 4.\n");
		if(Version==0)
		{	
L6:			printf("Model--->  ");
			scanf("%s",string);
			model=atoi(string);
			printf("\n\n");
			while( (model-1)*(model-2)!=0)
			{
				printf("\aError: model must be 1 or 2!\n");
				printf("Please make your choice again.\n\n");
				goto L6;		
			}
		}
		else
		{
			fscanf(parameter, "%s", temp);
			fscanf(parameter,"%s",string);
			model=atoi(string);
		}

	}
	else 
	{
		for(i=0;i<=6;i++) SS[i]=0.0;
		int DF[7]={an-1,cn-1,leng-1,(cn-1)*(leng-1),(an-1)*(leng-1),(cn-1)*(an-1)*leng, an*cnleng-1};
		model=(model==1)? 2:1;
		if(model==1) printf("Model 1:     log(y)=mu+Ai+Vk+Gg+(AG)ig+(VG)kg+Eikg\n\n");
		else printf("Model 2:     log(y)=mu+Ai+Vk+Gg+(VG)kg+Eikg\n");
	}

//	model=model+2;
	//Initialzation
	ind=imatrix(0,an-1,0,cn-1);
	Ti=dvector(1,an);
//	Tj=dvector(1,cn);
	Tk=dvector(1,cn);
	Tg=dvector(1,leng);
	Tig=dmatrix(1,an,1, leng);
//	Tjg=dmatrix(1,cn,1, leng);
	Tkg=dmatrix(1,cn,1, leng);
	A=dvector(1,an);
//	D=dvector(1,cn);
	V=dvector(1,cn);
	G=dvector(1,leng);
	AG=dmatrix(1,an,1, leng);
//	DG=dmatrix(1,cn,1, leng);
	VG=dmatrix(1,cn,1, leng);
	Res=darray(1,an, 1, cn,1,leng);
	zhat=darray(1,an, 1, cn,1,leng);
	
	for(i=0; i<an;i++)
	{
		iorder(LT[i],cn, ind[i]);
	}
	mu=0.0; 
	for(i=1;i<=an;i++)
	{
		Ti[i]=0.0; 
		for(g=1;g<=leng;g++)
		{
			Tig[i][g]=0.0; 
			for(j=1;j<=cn;j++)
			{
				Tig[i][g]+=data[i][j][g];
				SS[6]+=data[i][j][g]*data[i][j][g];
			}
			Tig[i][g]/=cn;
			Ti[i]+=Tig[i][g];
		}
		Ti[i]/=leng;
		mu+=Ti[i];
	}
	mu/=an;
	SS[6]-=an*cnleng*mu*mu;
	for(i=1;i<=cn;i++)
	{
//		Tj[i]=0.0; 
		Tk[i]=0.0;
		for(g=1;g<=leng;g++)
		{
//			Tjg[i][g]=0.0; 
			Tkg[i][g]=0.0; 
			for(j=1;j<=an;j++)
			{
				Tkg[i][g]+=data[j][i][g];
//				Tjg[i][g]+=data[j][ind[j-1][i-1]][g];
			}
//			Tjg[i][g]/=an;
			Tkg[i][g]/=an;
//			Tj[i]+=Tjg[i][g];
			Tk[i]+=Tkg[i][g];
		}
//		Tj[i]/=leng;
//		D[i]=Tj[i]-mu;
		Tk[i]/=leng;
		V[i]=Tk[i]-mu;
//		SS[1]+=D[i]*D[i];
		SS[1]+=V[i]*V[i];
	}
	SS[1]*=an*leng;
//	SS[2]*=cnleng;
	
	for(g=1;g<=leng;g++)
	{
		Tg[g]=0.0;
		for(j=1;j<=an;j++)
		{
			Tg[g]+=Tig[j][g];
		}
		Tg[g]/=an;
		G[g]=Tg[g]-mu;
		SS[2]+=G[g]*G[g];
	}
	SS[2]*=(an*cn);
	for(i=1;i<=an;i++)
	{
		A[i]=Ti[i]-mu;
		SS[0]+=A[i]*A[i];
		for(g=1;g<=leng;g++)
		{		
			AG[i][g]=Tig[i][g]-Ti[i]-G[g];
			SS[4]+=AG[i][g]*AG[i][g];
		}
	}
	SS[0]*=cnleng;
	SS[4]*=cn;
	for(i=1;i<=cn;i++)
	{
		for(g=1;g<=leng;g++)
		{		
//			DG[i][g]=Tjg[i][g]-Tj[i]-G[g];
			VG[i][g]=Tkg[i][g]-Tk[i]-G[g];
//			SS[5]+=DG[i][g]*DG[i][g];
			SS[3]+=VG[i][g]*VG[i][g];
		}
	}
	SS[3]*=an;
//	SS[6]*=an;
	for(i=1;i<=an;i++)
		for(j=1;j<=cn;j++)
			for(g=1;g<=leng;g++)
			{
				zhat[i][j][g]=mu+A[i]+V[j]+G[g]+AG[i][g]+VG[j][g];
				if(model==2)
				{
					zhat[i][j][g]=zhat[i][j][g]-AG[i][g];
				}
/*				else if(model==3)
				{
					zhat[i][j][g]=zhat[i][j][g]-DG[LT[i-1][j-1]][g]-D[LT[i-1][j-1]];
				}
				else if(model==4)
				{
					zhat[i][j][g]=zhat[i][j][g]-DG[LT[i-1][j-1]][g]-D[LT[i-1][j-1]]-AG[i][g];
				} */
				
				Res[i][j][g]=data[i][j][g]-zhat[i][j][g];
				SS[5]+=Res[i][j][g]*Res[i][j][g];
			}
	if(model==1)
	{
		for(i=0;i<=6;i++)
		{
			MS[i]=SS[i]/DF[i];
			F[i]=MS[i]*DF[5]/SS[5];
			// Using formular F(x;m,n)=I_a(n/2,m/2), with a=xm/(n+mx)
			// where F(x;m,n) is the distribution function of F-Distribution with DF=(m,n)
			// I_a(i,j) is the incomplete beta function
//			printf("F=%f, DF[i]=%d, DF[5]=%d\n",F[i], DF[i], DF[5]);
			Pval[i]=1-betai(DF[i]/2.0,DF[5]/2.0, F[i]*DF[i]/(DF[5]+DF[i]*F[i]));
		}
	}
	else
	{
		SS[4]+=SS[5]; DF[4]+=DF[5];
		SS[5] =SS[6]; DF[5] =DF[6];
		for(i=0;i<=5;i++)
		{
			MS[i]=SS[i]/DF[i];
			F[i]=MS[i]*DF[4]/SS[4];
			// Using formular F(x;m,n)=I_a(n/2,m/2), with a=xm/(n+mx)
			// where F(x;m,n) is the distribution function of F-Distribution with DF=(m,n)
			// I_a(i,j) is the incomplete beta function
			Pval[i]=1-betai(DF[i]/2.0,DF[4]/2.0, F[i]*DF[i]/(DF[4]+DF[i]*F[i]));
			
		}


/*		itemp1=0; itemp2=DF[7];
		for(i=2;i<=model;i++)
		{
			j=5*(i==2)+(i==3)+4*(i==4);
			itemp1+=DF[j];
		}
		
		for(i=1;i<=9-model;i++) 
		{
			j=i+(model>1)*(i>6-model)+(model>2)*(i>0)+(model>3)*(i>2);
			SS[i]=SS[j];
			if(i!=8-model) 
			{
				DF[i]=DF[j];
			}
		}
		DF[8-model]=itemp2+itemp1;

		for(i=0;i<=9-model;i++) 
		{
			MS[i]=SS[i]/DF[i];
			F[i]=MS[i]*DF[8-model]/SS[8-model];

			Pval[i]=1-betai(DF[i]/2.0, DF[8-model]/2.0, F[i]*DF[i]/(DF[8-model]+DF[i]*F[i]));
		}*/

	}
	if(Version==0)
	{
		printf("ANOVA Table for Model %d:\n\n",model);
		if(model==1)printf("         log(y)=mu+Ai+Vk+Gg+(AG)ig+(VG)kg+Eikg\n");
		else printf("         log(y)=mu+Ai+Vk+Gg+(VG)kg+Eikg\n");
//		else if(model==3)printf("         log(y)=mu+Ai+Vk+Gg+(AG)ig+(VG)kg+Eijkg\n");
//		else printf("         log(y)=mu+Ai+Vk+Gg+(VG)kg+Eijkg\n");
		printf("\n\n");
		printf("Source     \tDF      \tSS      \tMS       \tF-value       \tP-value\n");
		for(i=0;i<=7-model;i++)
		{
			j=i+(model>1)*(i>5-model);//+(model>2)*(i>0)+(model>3)*(i>2);
			if(i<=5-model)
				printf("%s\t%d\t%f\t%f\t%f\t%f\n", Source[j],DF[i],SS[i],MS[i],F[i],Pval[i]);
			else if (i<=6-model)
				printf("%s\t%d\t%f\t%f\t\t\n", Source[j],DF[i],SS[i],MS[i]);
			else printf("%s\t%d\t%f\t\t\t\n", Source[j],DF[i],SS[i]);
		}
		printf("\n\n");
		printf("R-square=\t%f\n", 1-SS[6-model]/SS[7-model]);
/*
		printf("\n\n\n Do you want to try another model?\n\n");
		printf("Please answer Y or N:");
L7:		scanf("%s",string);

		while( strcmp(string,"y") && strcmp(string, "n"))
		{
			printf("\aPlease press Y for Yes or N for No.\n");
			printf("Please make your choice again.\n\n");
			goto L7;		
		}

		if (strcmp(string, "n")) { TryAgain+=1;goto L8;}
*/
		printf("\n\n Do you want save the current ANOVA results\n");
		printf("\nPlease answer Y or N:");
L11:	scanf("%s",string);

		while( strcmp(string,"y") && strcmp(string, "n"))
		{
			printf("\n\n\aPlease press Y for Yes or N for No.\n");
			printf("Please make your choice again.\n\n");
			goto L11;		
		}
	}
	else 
	{
		strcpy(string, "y");
		strcpy(UserID,tempID);
		strcat(UserID,AnovaTabl[TryAgain]);
		strcpy(AnovaTabl[TryAgain],UserID);
	}

	if (strcmp(string, "y")) goto L12;
	else 
	{
		nModel+=1;
		if(Version==0)
		{
			printf("\n\n Do you want save the current ANOVA results\n");
			printf("in file <%s>\n",AnovaTabl[nModel-1]);
			printf("\nPlease answer Y or N:");
L9:			scanf("%s",string);

			while( strcmp(string,"y") && strcmp(string, "n"))
			{
				printf("\n\n\aPlease press Y for Yes or N for No.\n");
				printf("Please make your choice again.\n\n");
				goto L9;		
			}

			if (strcmp(string, "y"))
			{
				printf("\n\nPlease type in the file name you want to save the ANOVA table \n");
				printf("and the results of estimated fold changes:\n");
				scanf("%s", AnovaTabl[nModel-1]);
			}
		}
L4:		if ((fpout1= fopen(AnovaTabl[nModel-1], "w")) == NULL)
		{ 
			printf("\n\n\aCannot write to the file: <%s> .\n",AnovaTabl[nModel-1]);
			printf("Close the Excel or other application which opens this file.\n");
		    printf("Press any key to continue.\n");
			getch();
			goto L4;
		}
		fprintf(fpout1,"\n\n");
		fprintf(fpout1,"       ANOVA Table for Model:\n\n");
		if(model==1)fprintf(fpout1,"         log(y)=mu+Ai+Vk+Gg+(AG)ig+(VG)kg+Eikg\n\n");
		else fprintf(fpout1,"         log(y)=mu+Ai+Vk+Gg+(VG)kg+Eikg\n\n");
//		else if(model==3)fprintf(fpout1,"         log(y)=mu+Ai+Vk+Gg+(AG)ig+(VG)kg+Eijkg\n\n");
//		else fprintf(fpout1,"         log(y)=mu+Ai+Vk+Gg+(VG)kg+Eijkg\n\n");

		fprintf(fpout1,"Source\tDF\tSS\tMS\tF-value\tP-value\n");
		for(i=0;i<=7-model;i++)
		{
			j=i+(model>1)*(i>5-model);//+(model>2)*(i>0)+(model>3)*(i>2);
			if(i<=5-model)
				fprintf(fpout1,"%s\t%d\t%f\t%f\t%f\t%f\n", Source[j],DF[i],SS[i],MS[i],F[i],Pval[i]);
			else if (i<=6-model)
				fprintf(fpout1,"%s\t%d\t%f\t%f\t\t\n", Source[j],DF[i],SS[i],MS[i]);
			else fprintf(fpout1,"%s\t%d\t%f\t\t\t\n", Source[j],DF[i],SS[i]);
		}

		fprintf(fpout1,"\n\n");
		fprintf(fpout1,"R-square=\t%f\n", 1-SS[6-model]/SS[7-model]);
	
		fprintf(fpout1,"\n\n     The Estimated Fold Changes and P-values\n\n");

		fprintf(fpout1, "Number\t Gene Name\t");

/*		for(i=1;i<=cn-1;i++)
			for(j=i+1;j<=cn;j++)
			{
				r1=(int)(j-i+(i-1)*(2*cn-i)/2);
				fprintf(fpout1, "Ch%d/Ch%d Ratio\tP-value\t",j*(ra[r1]==1)+i*(ra[r1]==2),i*(ra[r1]==1)+j*(ra[r1]==2));
			}*/
		for(i=1;i<=cn-1;i++)
			{
				r1=i;
				fprintf(fpout1, "Case%d(Ch%d)/Control(Ch%d) Ratio\tP-value\t",i,Case[1][i],Control[1]);
			}
		fprintf(fpout1, "\n");
		for(g=1;g<=leng;g++)
		{
			if(rep>1) fprintf(fpout1, "%3d-%3d\t", rep*(g-1)+1, rep*g);
			else fprintf(fpout1, "%3d\t", g);
			//fprintf(fpout1, "%s\t", GeneName[rep*g]);
				t1=0;
				while((GeneName[rep*g][t1]!='\0')&&(GeneName[rep*g][t1]!='\t'))
				{
					t1+=1;
				}
				if(t1>0) fprintf(fpout1,"%s\t", GeneName[rep*g]);
				else fprintf(fpout1,"%s", GeneName[rep*g]);

/*			for(i=1;i<=cn-1;i++)
				for(j=i+1;j<=cn;j++)
				{
					r1=(int)(j-i+(i-1)*(2*cn-i)/2);
					dtemp1=VG[j][g]*(ra[r1]==1)+VG[i][g]*(ra[r1]==2)-VG[i][g]*(ra[r1]==1)-VG[j][g]*(ra[r1]==2);
					dtemp0=0.5*cnleng*fabs(dtemp1)/((leng-1)*MS[8-model]);
					dtemp2=betai(DF[8-model]/2.0, 0.5,DF[8-model]/(DF[8-model]+dtemp0*dtemp0)); 
					fprintf(fpout1, "%f\t%f\t",exp(dtemp1), dtemp2);
				}*/
			for(i=1;i<=cn-1;i++)
				{
					r1=i;
					dtemp1=VG[r1][g]-VG[cn][g];
					dtemp0=sqrt(0.5*an*leng)*fabs(dtemp1)/sqrt((leng-1)*MS[6-model]);
					dtemp2=betai(DF[6-model]/2.0, 0.5,DF[6-model]/(DF[6-model]+dtemp0*dtemp0)); 
					fprintf(fpout1, "%f\t%f\t",exp(dtemp1), dtemp2);
				}
			fprintf(fpout1, "\n");
		}
		fclose(fpout1);
	}

L12:if(Version==0)
	{
		if(TryAgain<1)
		{
			printf("\n\n\n Do you want to try the other model?\n\n");
			printf("Please answer Y or N:");
L7:			scanf("%s",string);
			printf("\n\n");
			while( strcmp(string,"y") && strcmp(string, "n"))
			{
				printf("\aPlease press Y for Yes or N for No.\n");
				printf("Please make your choice again.\n\n");
				goto L7;		
			}

			if (strcmp(string, "n")) { TryAgain+=1;goto L8;}
		}
	}
		
	printf("\n\n Ok! Check out the ANONA results given in\n\n"); 
	for(i=0;i<=nModel-1;i++)
	{
		printf("<%s>",AnovaTabl[i]);
		if(i<TryAgain) printf(" and ");
		else printf(".");
	}
	printf("\n\n");
	// free the memory
	free_imatrix(ind,0,an-1,0,cn-1);
	free_dvector(Ti, 1,an);
//	free_dvector(Tj, 1,cn);
	free_dvector(Tk, 1,cn);
	free_dvector(Tg, 1,leng);
	free_dmatrix(Tig, 1,an,1, leng);
//	free_dmatrix(Tjg, 1,cn,1, leng);
	free_dmatrix(Tkg, 1,cn,1, leng);
	free_dvector(A, 1,an);
//	free_dvector(D, 1,cn);
	free_dvector(V, 1,cn);
	free_dvector(G, 1,leng);
	free_dmatrix(AG, 1,an,1, leng);
//	free_dmatrix(DG, 1,cn,1, leng);
	free_dmatrix(VG, 1,cn,1, leng);
	free_darray(Res, 1,an, 1,cn,1, leng);
	free_darray(zhat, 1,an, 1, cn,1, leng);
	free_cmatrix(AnovaTabl,0,1,0,50);
}


void squeeze(char s[],char c[])  //Squeeze all null
{
	int i,j;
	for(i=j=0;s[i]!='\0';++i)
	{
		if(s[j]!=c[i])
		{
			s[j++]=s[j];
		}
		else s[j]='\0';
	}
}