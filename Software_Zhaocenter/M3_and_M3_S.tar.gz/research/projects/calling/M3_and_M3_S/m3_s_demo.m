%% MMM Demo

%% Set directory 
global base
base = [pwd '/'];
addpath([base 'functions']);
addpath([base 'data']);

%% M3-S Method 

file1 = ['intensity_s'];
file2 = ['hap_s'];
file3 = ['hap_s_id'];

cutoff   = 0.85;               % cutoff of the posterior probability.
s_train = 94;                  % the size of reference SNPs.
simu = 500;                    % the simulated sample size of each cluster.    
hap_bei = 80;                  % the size of reference SNPs.
err   = 0.00001;
rr = 100000; 


[idx]= mmm_sample(file1, file2, file3, cutoff, s_train, simu, hap_bei, rr, err);


 

 