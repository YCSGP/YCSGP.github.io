function [cc, idxs] = mmm_step22(file, file1, idx, callrate, idxs, step, bei, cut, rq, err, calrat1, calrat2, mmaf, APR)

    cut=cut; step = step; rq=rq; bei = bei;
    calrat1 = calrat1; calrat2 = calrat2;
    tt = err; mmaf = mmaf; APR = APR;
    nname0 = [file,'.txt'];
    yy=textread(nname0);
    idx = idx;
    callrate = callrate;
    idxs = idxs;
    mmaf = mmaf; APR = APR;
    nname1 = [file1,'.txt'];
    fid=fopen(nname1);
    snp=textscan(fid,'%s');
    fclose(fid);
    
    if 3*step >= size(yy,2)/2 
        disp('Error Inf: the size of refence SNPs is too large!!!')
    end

    %% select testing SNPs
    %% calculate the MAF at the 1st step results
if 3*step < size(yy,2)/2  
       
    maf = zeros(size(idxs,2),1);
    for s = 1: size(idxs,2)
        maf(s,1)=sum(idxs(idxs(:,s)~=-9,s))/(size(idxs(idxs(:,s)~=-9,s),1)*2);
    end
    set1 = find(maf < mmaf);
    set2 = find(callrate < APR);
    freq = union(set1,set2);
    %freq = set1;
    freq = sort(freq);
    indd = (freq*2-1)';  
    kk=0; 
    idxx=zeros(size(yy,1)*2,size(indd,2));
    idxss=zeros(size(yy,1)*2,size(indd,2));
    sss=zeros(size(indd,2),1);
    numsnp = size(idx,2);
   
for jj = indd
    kk = kk+1
    ii = (jj+1)/2;
    if ii >= numsnp-step
    nn1 = find(callrate((ii-2*step):(ii-1),:) > calrat1);
    nn2 = find(callrate((ii-2*step):(ii-1),:) < calrat2);
    nnn = ii+intersect(nn1,nn2)-2*step-1;
    end
    if ii <= step
    nn1 = find(callrate((ii+1):(ii+2*step),:) > calrat1);
    nn2 = find(callrate((ii+1):(ii+2*step),:) < calrat2);
    nnn = ii+intersect(nn1,nn2);
    end
    if ii > step && ii < numsnp-step
       nn1 = find(callrate(ii-step:ii+step,:) > calrat1);
       nn2 = find(callrate(ii-step:ii+step,:) < calrat2);
       nnn = ii+intersect(nn1,nn2)-step-1;
    end
 
   gs = setdiff(nnn,freq);
   gs0 = sum(idx(:,gs)==1);
   gs1 = sum(idx(:,gs)==2);
   gs2 = sum(idx(:,gs)==3);
   gss0 = find(gs0 > bei);
   gss1 = find(gs1 > bei);
   gss2 = find(gs2 > bei);
   
   qc = 0;
   while isempty(intersect(intersect(gss0,gss1),gss2))
         gss0 = find(gs0 > bei-qc*100);
         gss1 = find(gs1 > bei-qc*100);
         gss2 = find(gs2 > bei-qc*100);
         qc = qc+1;
   end

   ss = 2*gs(intersect(intersect(gss0,gss1),gss2),:)-1; 
   ss = ss';
   d = zeros(size(ss,2),1);
   dd = zeros(size(ss,2),1);

  for i = 1:size(ss,2)
        X_ref = yy(:,ss(i):(ss(i)+1));
        X_log = yy(:,jj:(jj+1));
          
        % mahalanobis distance
        d(i) = sum(mahal(X_log,X_ref));
        
        %% calculate distance
        ind_zero11 = find(X_log(:,1) == 0);
        ind_zero22 = find(X_log(:,2) == 0);
        ind_zero1 = union(ind_zero11,ind_zero22);
        if size(ind_zero1,1) < size(ind_zero1,2)
            ind_zero1 = ind_zero1';
        end
        ind_nzero1 = setdiff(1:size(X_log,1),ind_zero1')';
        
        ind_zero33 = find(X_ref(:,1) == 0);  
        ind_zero44 = find(X_ref(:,2) == 0);  
        ind_zero2 = union(ind_zero33,ind_zero44);
        if size(ind_zero2,1) < size(ind_zero2,2)
            ind_zero2 = ind_zero2';
        end
        ind_nzero2 = setdiff(1:size(X_ref,1),ind_zero2')';
              
        X1 = X_log(ind_nzero1',:);
        X2 = X_ref(ind_nzero2',:);
        
        X = X2;
        % Initial values for log intensity
        contrast = (X(:,1)-X(:,2))./(X(:,1)+X(:,2));
        con1 = find(contrast < -rq) ;
        con2 = find(contrast < rq & contrast >= -rq) ;
        con3 = find(contrast >= rq) ;

        tot  = length(con1)+length(con2)+length(con3);
        p1 = length(con1)/tot;
        p2 = length(con2)/tot;
        p3 = length(con3)/tot;

    if p1 > 0 && p2 > 0 && p3 > 0
        ini.PComponents = [p1,p2,p3]; 
        ini.mu = zeros(3,2); ini.Sigma=zeros(2,2,3);
        ini.mu(1,:) = [mean(X(con1,1)),mean(X(con1,2))];
        ini.mu(2,:) = [mean(X(con2,1)),mean(X(con2,2))];
        ini.mu(3,:) = [mean(X(con3,1)),mean(X(con3,2))];
        if length(con1) > 1 
           ini.Sigma(:,:,1) = cov(X(con1,1),X(con1,2));
        else ini.Sigma(:,:,1) = eye(2,2);
        end;    
    
        if length(con2) > 1
           ini.Sigma(:,:,2) = cov(X(con2,1),X(con2,2));
        else ini.Sigma(:,:,2) = eye(2,2);
        end;    
    
        if length(con3) > 1 
           ini.Sigma(:,:,3) = cov(X(con3,1),X(con3,2));
        else ini.Sigma(:,:,3) = eye(2,2);
        end;
        k=3;
        e1=eig(ini.Sigma(:,:,1)); 
        e2=eig(ini.Sigma(:,:,2));
        e3=eig(ini.Sigma(:,:,3));
        if e1(1,:) < tt || e1(2,:) < tt 
           [U,S] = eig(ini.Sigma(:,:,1));
           ini.Sigma(:,:,1)= U'*(abs(S)+eye(2)*0.001)*U;
        end
        if e2(1,:) < tt || e2(2,:) < tt
           [U,S] = eig(ini.Sigma(:,:,2));
           ini.Sigma(:,:,2)= U'*(abs(S)+eye(2)*0.001)*U;
        end
        if e3(1,:) < tt || e3(2,:) < tt
           [U,S] = eig(ini.Sigma(:,:,3));
           ini.Sigma(:,:,3)= U'*(abs(S)+eye(2)*0.001)*U;
        end
    end
        SD = struct('PComponents',ini.PComponents,'mu',ini.mu,'Sigma',ini.Sigma);

        X = X1;
        % Initial values for log intensity
        contrast = (X(:,1)-X(:,2))./(X(:,1)+X(:,2));
        con1 = find(contrast < -rq) ;
        con2 = find(contrast < rq & contrast >= -rq) ;
        con3 = find(contrast >= rq) ;

        tot  = length(con1)+length(con2)+length(con3);
        p1 = length(con1)/tot;
        p2 = length(con2)/tot;
        p3 = length(con3)/tot;

    if p1 > 0 && p2 > 0 && p3 > 0
        ini.PComponents = [p1,p2,p3]; 
        ini.mu = zeros(3,2); ini.Sigma=zeros(2,2,3);
        ini.mu(1,:) = [mean(X(con1,1)),mean(X(con1,2))];
        ini.mu(2,:) = [mean(X(con2,1)),mean(X(con2,2))];
        ini.mu(3,:) = [mean(X(con3,1)),mean(X(con3,2))];
        if length(con1) > 1 
           ini.Sigma(:,:,1) = cov(X(con1,1),X(con1,2));
        else ini.Sigma(:,:,1) = eye(2,2);
        end;    
    
        if length(con2) > 1
           ini.Sigma(:,:,2) = cov(X(con2,1),X(con2,2));
        else ini.Sigma(:,:,2) = eye(2,2);
        end;    
    
        if length(con3) > 1 
           ini.Sigma(:,:,3) = cov(X(con3,1),X(con3,2));
        else ini.Sigma(:,:,3) = eye(2,2);
        end;
        k=3;
        e1=eig(ini.Sigma(:,:,1)); 
        e2=eig(ini.Sigma(:,:,2));
        e3=eig(ini.Sigma(:,:,3));
        if e1(1,:) < tt || e1(2,:) < tt 
           [U,S] = eig(ini.Sigma(:,:,1));
           ini.Sigma(:,:,1)= U'*(abs(S)+eye(2)*0.001)*U;
        end
        if e2(1,:) < tt || e2(2,:) < tt
           [U,S] = eig(ini.Sigma(:,:,2));
           ini.Sigma(:,:,2)= U'*(abs(S)+eye(2)*0.001)*U;
        end
        if e3(1,:) < tt || e3(2,:) < tt
           [U,S] = eig(ini.Sigma(:,:,3));
           ini.Sigma(:,:,3)= U'*(abs(S)+eye(2)*0.001)*U;
        end
    end

    if p1 == 0 && p2 > 0 && p3 > 0,
        ini.PComponents = [p2,p3];
        ini.mu = zeros(2,2); ini.Sigma=zeros(2,2,2);
        ini.mu(1,:) = [mean(X(con2,1)),mean(X(con2,2))];
        ini.mu(2,:) = [mean(X(con3,1)),mean(X(con3,2))];
        if length(con2) > 1
           ini.Sigma(:,:,1) = cov(X(con2,1),X(con2,2));
        else ini.Sigma(:,:,1) = eye(2,2);
        end    
        if length(con3) > 1 
           ini.Sigma(:,:,2) = cov(X(con3,1),X(con3,2));
        else ini.Sigma(:,:,2) = eye(2,2);
        end;
        k=2; 
        e1=eig(ini.Sigma(:,:,1)); 
        e2=eig(ini.Sigma(:,:,2));
        if e1(1,:) < tt || e1(2,:) < tt
           [U,S] = eig(ini.Sigma(:,:,1));
           ini.Sigma(:,:,1)= U'*(abs(S)+eye(2)*0.001)*U;
        end
        if e2(1,:) < tt || e2(2,:) < tt
           [U,S] = eig(ini.Sigma(:,:,2));
           ini.Sigma(:,:,2)= U'*(abs(S)+eye(2)*0.001)*U;
        end
    end;
    
    if p2 == 0 && p1 > 0 && p3 > 0, 
        ini.PComponents = [p1,p3];
        ini.mu = zeros(2,2); ini.Sigma=zeros(2,2,2);
        ini.mu(1,:) = [mean(X(con1,1)),mean(X(con1,2))];
        ini.mu(2,:) = [mean(X(con3,1)),mean(X(con3,2))];
        if length(con1) > 1
           ini.Sigma(:,:,1) = cov(X(con1,1),X(con1,2));
        else ini.Sigma(:,:,1) = eye(2,2);
        end    
        if length(con3) > 1 
           ini.Sigma(:,:,2) = cov(X(con3,1),X(con3,2));
        else ini.Sigma(:,:,2) = eye(2,2);
        end;
        k=2; 
        e1=eig(ini.Sigma(:,:,1)); 
        e2=eig(ini.Sigma(:,:,2));
        if e1(1,:) < tt || e1(2,:) < tt
           [U,S] = eig(ini.Sigma(:,:,1));
           ini.Sigma(:,:,1)= U'*(abs(S)+eye(2)*0.001)*U;
        end
        if e2(1,:) < tt || e2(2,:) < tt
           [U,S] = eig(ini.Sigma(:,:,2));
           ini.Sigma(:,:,2)= U'*(abs(S)+eye(2)*0.001)*U;
        end
    end;
    
    if p3 == 0 && p1 > 0 && p2 > 0,
        ini.PComponents = [p1,p2];
        ini.mu = zeros(2,2); ini.Sigma=zeros(2,2,2);
        ini.mu(1,:) = [mean(X(con1,1)),mean(X(con1,2))];
        ini.mu(2,:) = [mean(X(con2,1)),mean(X(con2,2))];
        if length(con1) > 1
           ini.Sigma(:,:,1) = cov(X(con1,1),X(con1,2));
        else ini.Sigma(:,:,1) = eye(2,2);
        end    
        if length(con2) > 1 
           ini.Sigma(:,:,2) = cov(X(con2,1),X(con2,2));
        else ini.Sigma(:,:,2) = eye(2,2);
        end;
        k=2; 
        e1=eig(ini.Sigma(:,:,1)); 
        e2=eig(ini.Sigma(:,:,2));
        if e1(1,:) < tt || e1(2,:) < tt
           [U,S] = eig(ini.Sigma(:,:,1));
           ini.Sigma(:,:,1)= U'*(abs(S)+eye(2)*0.001)*U;;
        end
        if e2(1,:) < tt || e2(2,:) < tt
           [U,S] = eig(ini.Sigma(:,:,2));
           ini.Sigma(:,:,2)= U'*(abs(S)+eye(2)*0.001)*U;
        end
    end;

    if p1 == 0 && p2 == 0 && p3 > 0,
        ini.PComponents = p3;
        ini.mu = zeros(1,2); ini.Sigma=zeros(2,2,1);
        ini.mu(1,:) = [mean(X(con3,1)),mean(X(con3,2))];
        if length(con3) > 1 
           ini.Sigma(:,:,1) = cov(X(con3,1),X(con3,2));
        else ini.Sigma(:,:,1) = eye(2,2);
        end    
        k=1; 
        e1=eig(ini.Sigma(:,:,1)); 
        if e1(1,:) < tt || e1(2,:) < tt
           [U,S] = eig(ini.Sigma(:,:,1));
           ini.Sigma(:,:,1)= U'*(abs(S)+eye(2)*0.001)*U;
        end
    end;

    if p1 == 0 && p3 == 0 && p2 > 0,
        ini.PComponents = p2;
        ini.mu = zeros(1,2); ini.Sigma=zeros(2,2,1);
        ini.mu(1,:) = [mean(X(con2,1)),mean(X(con2,2))];
        if length(con2) > 1 
           ini.Sigma(:,:,1) = cov(X(con2,1),X(con2,2));
        else ini.Sigma(:,:,1) = eye(2,2);
        end    
        k=1; 
        e1=eig(ini.Sigma(:,:,1)); 
        if e1(1,:) < tt || e1(2,:) < tt
           [U,S] = eig(ini.Sigma(:,:,1));
           ini.Sigma(:,:,1)= U'*(abs(S)+eye(2)*0.001)*U;
        end
    end;
    
    if p2 == 0 && p3 == 0 && p1 > 0,
        ini.PComponents = p1;
        ini.mu = zeros(1,2); ini.Sigma=zeros(2,2,1);
        ini.mu(1,:) = [mean(X(con1,1)),mean(X(con1,2))];
        if length(con1) > 1 
           ini.Sigma(:,:,1) = cov(X(con1,1),X(con1,2));
        else ini.Sigma(:,:,1) = eye(2,2);
        end    
        k=1; 
        e1=eig(ini.Sigma(:,:,1)); 
        if e1(1,:) < tt || e1(2,:) < tt
           [U,S] = eig(ini.Sigma(:,:,1));
           ini.Sigma(:,:,1)= U'*(abs(S)+eye(2)*0.001)*U;
        end
    end;

    SDD = struct('PComponents',ini.PComponents,'mu',ini.mu,'Sigma',ini.Sigma);
    
    if k == 3,
       if ~isempty(con1),
          dd1 = trace((X1(con1,:)-repmat(SD.mu(1,:),size(con1,1),1))/((SD.Sigma(:,:,1)+SDD.Sigma(:,:,1))/2)*(X1(con1,:)-repmat(SD.mu(1,:),size(con1,1),1))');
       end
       if ~isempty(con2),
           dd2 = trace((X1(con2,:)-repmat(SD.mu(2,:),size(con2,1),1))/((SD.Sigma(:,:,2)+SDD.Sigma(:,:,2))/2)*(X1(con2,:)-repmat(SD.mu(2,:),size(con2,1),1))');
       end
       if ~isempty(con3),
          dd3 = trace((X1(con3,:)-repmat(SD.mu(3,:),size(con3,1),1))/((SD.Sigma(:,:,3)+SDD.Sigma(:,:,3))/2)*(X1(con3,:)-repmat(SD.mu(3,:),size(con3,1),1))');
       end
       dd(i) = dd1+dd2+dd3;
    end
    
    if k == 2 && p1 == 0 && p2 > 0 && p3 > 0,
       if ~isempty(con2),
           dd2 = trace((X1(con2,:)-repmat(SD.mu(2,:),size(con2,1),1))/((SD.Sigma(:,:,2)+SDD.Sigma(:,:,1))/2)*(X1(con2,:)-repmat(SD.mu(2,:),size(con2,1),1))');
       end
       if ~isempty(con3),
          dd3 = trace((X1(con3,:)-repmat(SD.mu(3,:),size(con3,1),1))/((SD.Sigma(:,:,3)+SDD.Sigma(:,:,2))/2)*(X1(con3,:)-repmat(SD.mu(3,:),size(con3,1),1))');
       end
       dd(i) = dd2+dd3;
    end   

    if k == 2 && p1 > 0 && p2 == 0 && p3 > 0,
       if ~isempty(con1),
          dd1 = trace((X1(con1,:)-repmat(SD.mu(1,:),size(con1,1),1))/((SD.Sigma(:,:,1)+SDD.Sigma(:,:,1))/2)*(X1(con1,:)-repmat(SD.mu(1,:),size(con1,1),1))');
       end
       if ~isempty(con3),
          dd3 = trace((X1(con3,:)-repmat(SD.mu(3,:),size(con3,1),1))/((SD.Sigma(:,:,3)+SDD.Sigma(:,:,2))/2)*(X1(con3,:)-repmat(SD.mu(3,:),size(con3,1),1))');
       end
       dd(i) = dd1+dd3;
    end   
    
    if k == 2 && p1 > 0 && p2 > 0 && p3 == 0,
       if ~isempty(con1),
          dd1 = trace((X1(con1,:)-repmat(SD.mu(1,:),size(con1,1),1))/((SD.Sigma(:,:,1)+SDD.Sigma(:,:,1))/2)*(X1(con1,:)-repmat(SD.mu(1,:),size(con1,1),1))');
       end
       if ~isempty(con2),
           dd2 = trace((X1(con2,:)-repmat(SD.mu(2,:),size(con2,1),1))/((SD.Sigma(:,:,2)+SDD.Sigma(:,:,2))/2)*(X1(con2,:)-repmat(SD.mu(2,:),size(con2,1),1))');
       end
       dd(i) = dd1+dd2;
    end
    
    if k == 1 && p1 == 0 && p2 == 0 && p3 > 0,
       if ~isempty(con3),
          dd(i) = trace((X1(con3,:)-repmat(SD.mu(3,:),size(con3,1),1))/((SD.Sigma(:,:,3)+SDD.Sigma(:,:,1))/2)*(X1(con3,:)-repmat(SD.mu(3,:),size(con3,1),1))');
       end
    end
    if k == 1 && p1 == 0 && p2 > 0 && p3 == 0,
       if ~isempty(con2),
          dd(i) = trace((X1(con2,:)-repmat(SD.mu(2,:),size(con2,1),1))/((SD.Sigma(:,:,2)+SDD.Sigma(:,:,1))/2)*(X1(con2,:)-repmat(SD.mu(2,:),size(con2,1),1))');
       end
    end   
    if k == 1 && p1 > 0 && p2 == 0 && p3 == 0,
       if ~isempty(con1),
          dd(i) = trace((X1(con1,:)-repmat(SD.mu(1,:),size(con1,1),1))/((SD.Sigma(:,:,1)+SDD.Sigma(:,:,1))/2)*(X1(con1,:)-repmat(SD.mu(1,:),size(con1,1),1))');
       end
    end   
  end
         
    %%% final combine SNP
        X_ref = yy(:,ss(dd==min(dd)):(ss(dd==min(dd))+1));        
        X_log = yy(:,jj:(jj+1));
        ind_zero11 = find(X_log(:,1) == 0);
        ind_zero22 = find(X_log(:,2) == 0);
        ind_zero1 = union(ind_zero11,ind_zero22);
        if size(ind_zero1,1) < size(ind_zero1,2)
            ind_zero1 = ind_zero1';
        end
        ind_nzero1 = setdiff(1:size(X_log,1),ind_zero1')';
        
        ind_zero33 = find(X_ref(:,1) == 0);  
        ind_zero44 = find(X_ref(:,2) == 0);  
        ind_zero2 = union(ind_zero33,ind_zero44);
        if size(ind_zero2,1) < size(ind_zero2,2)
            ind_zero2 = ind_zero2';
        end
        ind_nzero2 = setdiff(1:size(X_ref,1),ind_zero2')';
         
        X1 = X_log(ind_nzero1,:);
        X2 = X_ref(ind_nzero2,:);
        X = [X1; X2];   
        XX =[X_log;X_ref];
        options = statset('Display','final','MaxIter',500);
       
        %figure(1);
        %plot(X_ref(:,1),X_ref(:,2),'ro');
        %hold on
        %plot(X_log(:,1),X_log(:,2),'g*');    
        %hold off
        %axis([0 15000 0 15000]);
        %legend('Ref-SNP','Testing-SNP','Location','NW')
       
        
        % Initial values for log intensity
        contrast = (X(:,1)-X(:,2))./(X(:,1)+X(:,2));
        con1 = find(contrast < -rq) ;
        con2 = find(contrast < rq & contrast >= -rq) ;
        con3 = find(contrast >= rq) ;
        mu1 = mean((X(con1,1)-X(con1,2))./(X(con1,1)+X(con1,2)));
        mu2 = mean((X(con2,1)-X(con2,2))./(X(con2,1)+X(con2,2)));
        mu3 = mean((X(con3,1)-X(con3,2))./(X(con3,1)+X(con3,2)));    
        ming = -rq; maxg = rq;
        if length(con1) > 3 && length(con2) > 3 && length(con3) > 3,
           maxg = mu2+(mu3-mu2)/2;
           ming = mu2-(mu2-mu1)/2;
        end
        if length(con1) > 3 && length(con2) > 3 && isempty(con3),
           maxg = mu1+(mu2-mu1)/2;
           ming = maxg;
        end
        if length(con1) > 3 && length(con3) > 3 && isempty(con2),
           maxg = mu1+(mu3-mu1)/2;
           ming = maxg;
        end
        if length(con2) > 3 && length(con3) > 3 && isempty(con1),
           maxg = mu2+(mu3-mu2)/2;
           ming = maxg;
        end
        if ~isempty(con1) && isempty(con2) && isempty(con3),
           maxg = rq;
           ming = -rq;
        end    
        if ~isempty(con2) && isempty(con1) && isempty(con3),
           maxg = rq;
           ming = -rq;
        end   
        if ~isempty(con3) && isempty(con1) && isempty(con2),
           maxg = rq;
           ming = -rq;
        end   
        con1 = find(contrast < ming) ;
        con2 = find(contrast < maxg & contrast >= ming) ;
        con3 = find(contrast >= maxg) ;
    
    tot  = length(con1)+length(con2)+length(con3);
    p1 = length(con1)/tot;
    p2 = length(con2)/tot;
    p3 = length(con3)/tot;
    
    if p1 > 0 && p2 > 0 && p3 > 0
        ini.PComponents = [p1,p2,p3]; 
        ini.mu = zeros(3,2); ini.Sigma=zeros(2,2,3);
        ini.mu(1,:) = [mean(X(con1,1)),mean(X(con1,2))];
        ini.mu(2,:) = [mean(X(con2,1)),mean(X(con2,2))];
        ini.mu(3,:) = [mean(X(con3,1)),mean(X(con3,2))];
        if length(con1) > 1 
           ini.Sigma(:,:,1) = cov(X(con1,1),X(con1,2));
        else ini.Sigma(:,:,1) = eye(2,2);
        end;    
    
        if length(con2) > 1
           ini.Sigma(:,:,2) = cov(X(con2,1),X(con2,2));
        else ini.Sigma(:,:,2) = eye(2,2);
        end;    
    
        if length(con3) > 1 
           ini.Sigma(:,:,3) = cov(X(con3,1),X(con3,2));
        else ini.Sigma(:,:,3) = eye(2,2);
        end;
        k=3;
        e1=eig(ini.Sigma(:,:,1)); 
        e2=eig(ini.Sigma(:,:,2));
        e3=eig(ini.Sigma(:,:,3));
        if e1(1,:) < tt || e1(2,:) < tt 
           [U,S] = eig(ini.Sigma(:,:,1));
           ini.Sigma(:,:,1)= U'*(abs(S)+eye(2)*0.001)*U;
        end
        if e2(1,:) < tt || e2(2,:) < tt
           [U,S] = eig(ini.Sigma(:,:,2));
           ini.Sigma(:,:,2)= U'*(abs(S)+eye(2)*0.001)*U;
        end
        if e3(1,:) < tt || e3(2,:) < tt
           [U,S] = eig(ini.Sigma(:,:,3));
           ini.Sigma(:,:,3)= U'*(abs(S)+eye(2)*0.001)*U;
        end
    end
  
    S = struct('PComponents',ini.PComponents,'mu',ini.mu,'Sigma',ini.Sigma);

    %% gmm test
    gm = gmdistribution.fit(X,k,'Regularize',1e-4,'Replicates',1,'Start',S,'Options',options);

    %% assigning cluster
        P = zeros(size(yy,1)*2,k);
        idxx([ind_nzero1;size(yy,1)+ind_nzero2],kk) = cluster(gm,X);
        cluster1 = 0; cluster2 = 0; cluster3 = 0; 
        cluster1 = find(idxx(:,kk) == 1);
        cluster2 = find(idxx(:,kk) == 2);
        cluster3 = find(idxx(:,kk) == 3);
        P([ind_nzero1;size(yy,1)+ind_nzero2],:) = posterior(gm,X);
        idxx([ind_zero1;size(yy,1)+ind_zero2],kk) = -9;   
    
        tab=tabulate(idxx([ind_nzero1;size(yy,1)+ind_nzero2],kk));
        if tab(1,2) > tab(3,2),
               idxss(cluster1,kk) = 0;
               idxss(cluster3,kk) = 2;
        else idxss(cluster1,kk) = 2;
             idxss(cluster3,kk) = 0;
        end
            idxss(cluster2,kk) = 1;


    %% assigning genotype to snps
    cutoff = cut;
    if k == 3
       cc1 = find(P(:,1)> cutoff);
       cc2 = find(P(:,2)> cutoff);
       cc3 = find(P(:,3)> cutoff);
       idxx(setdiff(cluster1,cc1),kk) = -9;
       idxx(setdiff(cluster2,cc2),kk) = -9;
       idxx(setdiff(cluster3,cc3),kk) = -9;
       idxss(setdiff(cluster1,cc1),kk) = -9;
       idxss(setdiff(cluster2,cc2),kk) = -9;
       idxss(setdiff(cluster3,cc3),kk) = -9;
    end;
    idx(:,ii) = idxx(1:size(yy,1),kk);
    idxs(:,ii) = idxss(1:size(yy,1),kk);
    
end

end

%% Generate Genotype
    sz = [size(yy,1), size(yy,2)+size(yy,2)/2-1];
    cc = repmat(' ', sz);
    jj = 1;
  for ii = 1:size(idx,2)
       ind0 = find(idx(:,ii) == 1);
       ind1 = find(idx(:,ii) == 2);
       ind2 = find(idx(:,ii) == 3);
       ind9 = find(idx(:,ii) == -9);
       cc(ind9,jj) = 'N'; cc(ind9,jj+1) = 'N';

       if sum(snp{1}{ii}=='AC')==2 || sum(snp{1}{ii}=='CA')==2
          cc(ind0,jj) = 'A'; cc(ind0,jj+1) = 'A';
          cc(ind1,jj) = 'A'; cc(ind1,jj+1) = 'C';
          cc(ind2,jj) = 'C'; cc(ind2,jj+1) = 'C';
       end
       if sum(snp{1}{ii}=='AT')==2 || sum(snp{1}{ii}=='TA')==2
          cc(ind0,jj) = 'A'; cc(ind0,jj+1) = 'A';
          cc(ind1,jj) = 'A'; cc(ind1,jj+1) = 'T';
          cc(ind2,jj) = 'T'; cc(ind2,jj+1) = 'T';
       end
       if sum(snp{1}{ii}=='AG')==2 || sum(snp{1}{ii}=='GA')==2
          cc(ind0,jj) = 'A'; cc(ind0,jj+1) = 'A';
          cc(ind1,jj) = 'A'; cc(ind1,jj+1) = 'G';
          cc(ind2,jj) = 'G'; cc(ind2,jj+1) = 'G'; 
       end
       if sum(snp{1}{ii}=='CT')==2 || sum(snp{1}{ii}=='TC')==2
          cc(ind0,jj) = 'C'; cc(ind0,jj+1) = 'C';
          cc(ind1,jj) = 'C'; cc(ind1,jj+1) = 'T';
          cc(ind2,jj) = 'T'; cc(ind2,jj+1) = 'T';
       end
       if sum(snp{1}{ii}=='CG')==2 || sum(snp{1}{ii}=='GC')==2
          cc(ind0,jj) = 'C'; cc(ind0,jj+1) = 'C';
          cc(ind1,jj) = 'C'; cc(ind1,jj+1) = 'G';
          cc(ind2,jj) = 'G'; cc(ind2,jj+1) = 'G';
       end
       if sum(snp{1}{ii}=='TG')==2 || sum(snp{1}{ii}=='GT')==2
          cc(ind0,jj) = 'T'; cc(ind0,jj+1) = 'T';
          cc(ind1,jj) = 'T'; cc(ind1,jj+1) = 'G';
          cc(ind2,jj) = 'G'; cc(ind2,jj+1) = 'G';
       end
       if sum(snp{1}{ii}=='DI')==2 || sum(snp{1}{ii}=='ID')==2
          cc(ind0,jj) = 'D'; cc(ind0,jj+1) = 'D';
          cc(ind1,jj) = 'D'; cc(ind1,jj+1) = 'I';
          cc(ind2,jj) = 'I'; cc(ind2,jj+1) = 'I';
       end
       jj = jj+3;
 end
     

end
 
  
  
%%
 %optical=textread('opt_geno.txt');
 
 %figure(1)
 %scatter(X_log(optical(:,93) == 0,1),X_log(optical(:,93) == 0,2),10,'b+');
 %hold on;
 %scatter(X_log(optical(:,93) == 1,1),X_log(optical(:,93) == 1,2),10,'go');
 %hold on;
 %scatter(X_log(optical(:,93) == 2,1),X_log(optical(:,93) == 2,2),10,'r*');
 %hold on;
 %scatter(X_log(optical(:,93) == -9,1),X_log(optical(:,93) == -9,2),10,'kp');
 %hold off;
 %axis([0 15000 0 15000]);
 
 
 %figure(1)
 %scatter(X_log(idxs(:,93) == 0,1),X_log(idxs(:,93) == 0,2),10,'b+');
 %hold on;
 %scatter(X_log(idxs(:,93) == 1,1),X_log(idxs(:,93) == 1,2),10,'go');
 %hold on;
 %scatter(X_log(idxs(:,93) == 2,1),X_log(idxs(:,93) == 2,2),10,'r*');
 %hold on;
 %scatter(X_log(idxs(:,93) == -9,1),X_log(idxs(:,93) == -9,2),10,'kp');
 %hold off;
 %axis([0 5000 0 5000]);
 

  


