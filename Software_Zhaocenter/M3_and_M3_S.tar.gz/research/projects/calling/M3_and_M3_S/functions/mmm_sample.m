
function [idx] = mmm_sample(file1, file2, file3, cutoff, s_train, simu, hap_bei, rr, err)

cutoff=cutoff; 
si2 = s_train;
si3 = simu;
hap_bei = hap_bei;

nname1 = [file1,'.txt'];
yy = textread(nname1);
nname2 = [file2,'.txt'];
hap = textread(nname2);
nname3 = [file3,'.txt'];
hap_id = textread(nname3);

idx=zeros(size(yy,1),size(yy,2)/2);
idxx = zeros((size(yy,1)+si3*3),size(yy,2)/2);
callrate=zeros(size(yy,2)/2,1);
iss = zeros(si2,size(yy,2)/2);
ii=0; 

for jj = (1:2:size(yy,2))
    ii=ii+1
    
    si1 =  size(hap,1); 
    iss(:,ii) =  randsample(si1,si2);
    happ = hap(iss(:,ii),:);
    hap_idd = hap_id(iss(:,ii),1);
    fef = tabulate(happ(happ(:,ii) ~= -9,ii));
       
    if sum(happ(:,ii)==2) < 3 || sum(happ(:,ii)==1) < 3 ||  sum(happ(:,ii)==0) < 3 || size(fef,1) < 3
       if ii >= size(yy,2)/2-hap_bei
          hap_n = ii-(0:hap_bei); 
       end
       if ii < size(yy,2)/2-hap_bei
          hap_n = ii+(0:hap_bei);
       end
       hap_dist = zeros(size(hap_n,2),1);
       contrast1 = zeros(si2,size(hap_n,2));
       strenth1 = zeros(si2,size(hap_n,2));
       for i = 1:size(hap_n,2)
          X_log=yy(:,(hap_n(1,i)*2-1):(hap_n(1,i)*2));
          %hap_idd = hap_id(iss(:,ii),1);
          contrast1(:,i) = (X_log(hap_idd,1)-X_log(hap_idd,2))./(X_log(hap_idd,1)+X_log(hap_idd,2)+.1);
          strenth1(:,i) = log(X_log(hap_idd,1)+X_log(hap_idd,2)+1);   
          fef1 = tabulate(happ(happ(:,hap_n(1,i)) ~= -9, hap_n(1,i)));
          if sum(happ(:,hap_n(1,i)) == 2) < 2 || sum(happ(:,hap_n(1,i)) == 1) < 2 || size(fef1,1) < 3 
             hap_dist(i,:) = 9999999999;
          end
          % Initial values for log intensity
          if sum(happ(:,hap_n(1,i)) == 2) > 1 && sum(happ(:,hap_n(1,i)) == 1) > 1 && size(fef1,1) == 3
             hap_dist(i,:) = sum(mahal(contrast1(:,1),contrast1(:,i))) ;   
          end
       end

       ff = find(hap_dist == min(hap_dist(2:size(hap_dist,1),:)));
       nnu = hap_n(1,ff);

       X1 = yy(hap_idd,(ii*2-1):(ii*2));
       X2 = yy(hap_idd,(nnu*2-1):(nnu*2));
                  
       rr1 = mean((X1(happ(:,ii)==0,1)-X1(happ(:,ii)==0,2))./(X1(happ(:,ii)==0,1)+X1(happ(:,ii)==0,2)+1));
       rr2 = mean((X2(happ(:,nnu)==0,1)-X2(happ(:,nnu)==0,2))./(X2(happ(:,nnu)==0,1)+X2(happ(:,nnu)==0,2)+1));
       
       if (rr1 < 0 && rr2 > 0) || (rr1 > 0 && rr2 < 0)
           hmu1 = mean([X1(happ(:,ii)==0,:);X2(happ(:,nnu)==2,:)]);
           hmu2 = mean([X1(happ(:,ii)==1,:);X2(happ(:,nnu)==1,:)]);
           hmu3 = mean([X1(happ(:,ii)==2,:);X2(happ(:,nnu)==0,:)]);
           sss1 = cov([X1(happ(:,ii)==0,:);X2(happ(:,nnu)==2,:)]);
           sss2 = cov([X1(happ(:,ii)==1,:);X2(happ(:,nnu)==1,:)]);
           sss3 = cov([X1(happ(:,ii)==2,:);X2(happ(:,nnu)==0,:)]);
           r1 = mvnrnd(hmu1,sss1,si3);
           r2 = mvnrnd(hmu2,sss2,si3);
           r3 = mvnrnd(hmu3,sss3,si3);
           ref1 = [X1(happ(:,ii)==0,:);X2(happ(:,nnu)==2,:)];
           ref2 = [X1(happ(:,ii)==1,:);X2(happ(:,nnu)==1,:)];
           ref3 = [X1(happ(:,ii)==2,:);X2(happ(:,nnu)==0,:)];
           ref = [r1;r2;r3];
       end;
           
       if (rr1 < 0 && rr2 < 0) || (rr1 > 0 && rr2 > 0)    
           hmu1 = mean([X1(happ(:,ii)==0,:);X2(happ(:,nnu)==0,:)]);
           hmu2 = mean([X1(happ(:,ii)==1,:);X2(happ(:,nnu)==1,:)]);
           hmu3 = mean([X1(happ(:,ii)==2,:);X2(happ(:,nnu)==2,:)]);
           sss1 = cov([X1(happ(:,ii)==0,:);X2(happ(:,nnu)==0,:)]);
           sss2 = cov([X1(happ(:,ii)==1,:);X2(happ(:,nnu)==1,:)]);
           sss3 = cov([X1(happ(:,ii)==2,:);X2(happ(:,nnu)==2,:)]);
           r1 = mvnrnd(hmu1,sss1,si3);
           r2 = mvnrnd(hmu2,sss2,si3);
           r3 = mvnrnd(hmu3,sss3,si3);
           ref1 = [X1(happ(:,ii)==0,:);X2(happ(:,nnu)==0,:)];
           ref2 = [X1(happ(:,ii)==1,:);X2(happ(:,nnu)==1,:)];
           ref3 = [X1(happ(:,ii)==2,:);X2(happ(:,nnu)==2,:)];
           ref = [r1;r2;r3];
       end;
       
       cont1 = (ref1(:,1)-ref1(:,2))./(ref1(:,1)+ref1(:,2)+1);
       cont2 = (ref2(:,1)-ref2(:,2))./(ref2(:,1)+ref2(:,2)+1);
       cont3 = (ref3(:,1)-ref3(:,2))./(ref3(:,1)+ref3(:,2)+1);
       
       ref_mu1 = mean(cont1); ref_mu2 = mean(cont2); ref_mu3 = mean(cont3);
       rq_low = ref_mu2-((ref_mu2-ref_mu1)/2);
       rq_high = ref_mu2+((ref_mu3-ref_mu2)/2);
       
       contrast2 = (ref(:,1)-ref(:,2))./(ref(:,1)+ref(:,2)+.1);
       strenth2 = log(ref(:,1)+ref(:,2)+.1);
    end;
    
    
    if sum(happ(:,ii)==2)>= 3 && sum(happ(:,ii)==0) > 3 && sum(happ(:,ii)==1) >= 3
       X1 = yy(hap_idd,(ii*2-1):(ii*2)); 
       hmu1 = mean(X1(happ(:,ii)==0,:));
       hmu2 = mean(X1(happ(:,ii)==1,:));
       hmu3 = mean(X1(happ(:,ii)==2,:));
       sss1 = cov(X1(happ(:,ii)==0,:));
       sss2 = cov(X1(happ(:,ii)==1,:));
       sss3 = cov(X1(happ(:,ii)==2,:));
       r1 = mvnrnd(hmu1,sss1,si3);
       r2 = mvnrnd(hmu2,sss2,si3);
       r3 = mvnrnd(hmu3,sss3,si3);
       ref = [r1;r2;r3];
       ref1 = [X1(happ(:,ii)==0,:)];
       ref2 = [X1(happ(:,ii)==1,:)];
       ref3 = [X1(happ(:,ii)==2,:)];
             
       cont1 = (ref1(:,1)-ref1(:,2))./(ref1(:,1)+ref1(:,2)+1);
       cont2 = (ref2(:,1)-ref2(:,2))./(ref2(:,1)+ref2(:,2)+1);
       cont3 = (ref3(:,1)-ref3(:,2))./(ref3(:,1)+ref3(:,2)+1);
       ref_mu1 = mean(cont1); ref_mu2 = mean(cont2); ref_mu3=mean(cont3);
       rq_low = ref_mu2-((ref_mu2-ref_mu1)/2);
       rq_high = ref_mu2+((ref_mu3-ref_mu2)/2);
       
       contrast2 = (ref(:,1)-ref(:,2))./(ref(:,1)+ref(:,2)+.1);
       strenth2 = log(ref(:,1)+ref(:,2)+.1);
       
       contrast1 = (X1(:,1)-X1(:,2))./(X1(:,1)+X1(:,2)+.1);
       strenth1 = log(X1(:,1)+X1(:,2)+.1);

    end;   

    X_log=yy(:,jj:(jj+1));
    ind_nzero1 = find(X_log(:,1) ~= 0);
    ind_zero1 = find(X_log(:,1) == 0);
    ind_nzero2 = find(ref(:,1) ~= 0);
    ind_zero2 = find(ref(:,1) == 0);
    X = X_log(ind_nzero1,:);
    R = ref(ind_nzero2,:);    
    X_T = [X;R];
    
    % Initial values for log intensity
    contrast = (X_T(:,1)-X_T(:,2))./(X_T(:,1)+X_T(:,2));
    strenth = log(X_T(:,1)+X_T(:,2));

    options = statset('Display','final','MaxIter',500);
    
    if (rq_low < rq_high)
        con1 = find(contrast < rq_low) ;
        con2 = find(contrast < rq_high & contrast >= rq_low) ;
        con3 = find(contrast >= rq_high) ;
    end;
    if (rq_low > rq_high)
        con1 = find(contrast < rq_high) ;
        con2 = find(contrast < rq_low & contrast >= rq_high) ;
        con3 = find(contrast >= rq_low) ;
    end;
    mu1 = mean((X_T(con1,1)-X_T(con1,2))./(X_T(con1,1)+X_T(con1,2)));
    mu2 = mean((X_T(con2,1)-X_T(con2,2))./(X_T(con2,1)+X_T(con2,2)));
    mu3 = mean((X_T(con3,1)-X_T(con3,2))./(X_T(con3,1)+X_T(con3,2)));    
     
    tot  = length(con1)+length(con2)+length(con3);
    p1 = length(con1)/tot;
    p2 = length(con2)/tot;
    p3 = length(con3)/tot;
    rr = rr; tt = err;
  
    if p1 > 0 && p2 > 0 && p3 > 0
        ini.PComponents = [p1,p2,p3]; 
        ini.mu = zeros(3,2); ini.Sigma=zeros(2,2,3);
        ini.mu(1,:) = [mean(X_T(con1,1)),mean(X_T(con1,2))];
        ini.mu(2,:) = [mean(X_T(con2,1)),mean(X_T(con2,2))];
        ini.mu(3,:) = [mean(X_T(con3,1)),mean(X_T(con3,2))];
        if length(con1) > 1 
           ini.Sigma(:,:,1) = cov(X_T(con1,1),X_T(con1,2));
        else ini.Sigma(:,:,1) = eye(2,2);
        end;    
    
        if length(con2) > 1
           ini.Sigma(:,:,2) = cov(X_T(con2,1),X_T(con2,2));
        else ini.Sigma(:,:,2) = eye(2,2);
        end;    
    
        if length(con3) > 1 
           ini.Sigma(:,:,3) = cov(X_T(con3,1),X_T(con3,2));
        else ini.Sigma(:,:,3) = eye(2,2);
        end;
        k=3;
        e1=eig(ini.Sigma(:,:,1)); 
        e2=eig(ini.Sigma(:,:,2));
        e3=eig(ini.Sigma(:,:,3));
        if e1(1,:) < tt || e1(2,:) < tt 
           ini.Sigma(:,:,1)=cholupdate(ini.Sigma(:,:,1),(ini.mu(1,:)/sqrt(rr))')'*cholupdate(ini.Sigma(:,:,1),(ini.mu(1,:)/sqrt(rr))');
        end
        if e2(1,:) < tt || e2(2,:) < tt
           ini.Sigma(:,:,2)=cholupdate(ini.Sigma(:,:,2),(ini.mu(2,:)/sqrt(rr))')'*cholupdate(ini.Sigma(:,:,2),(ini.mu(2,:)/sqrt(rr))');
        end
        if e3(1,:) < tt || e3(2,:) < tt
           ini.Sigma(:,:,3)=cholupdate(ini.Sigma(:,:,3),(ini.mu(3,:)/sqrt(rr))')'*cholupdate(ini.Sigma(:,:,3),(ini.mu(3,:)/sqrt(rr))');
        end
    end

    S = struct('PComponents',ini.PComponents,'mu',ini.mu,'Sigma',ini.Sigma);

    %% gmm test
    gm = gmdistribution.fit(X_T,k,'Regularize',1e-4,'Replicates',1,'Start',S,'Options',options);
    
    %% assigning cluster
       P=zeros(size(yy,1)+si3*3,k);
       idxx([ind_nzero1;3258+ind_nzero2],ii) = cluster(gm,X_T);
       idxx([ind_zero1;3258+ind_zero2],ii) = -9; 
       cluster1 = 0; cluster2 = 0; cluster3 = 0; 
       cluster1 = find(idxx(:,ii) == 1);
       cluster2 = find(idxx(:,ii) == 2);
       cluster3 = find(idxx(:,ii) == 3);
       P([ind_nzero1;3258+ind_nzero2],:) = posterior(gm,X_T);
       
              %% assigning genotype to snps
       
       cutoff = cutoff;
       cc1 = find(P(:,1)> cutoff);
       cc2 = find(P(:,2)> cutoff);
       cc3 = find(P(:,3)> cutoff);
       idxx(setdiff(cluster1,cc1),ii) = -9;
       idxx(setdiff(cluster2,cc2),ii) = -9;
       idxx(setdiff(cluster3,cc3),ii) = -9;

       idx(:,ii) = idxx(1:size(yy,1),ii);
       tabulate(idx(:,ii))
    

end

end
