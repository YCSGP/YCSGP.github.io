### GRAPE example with test data

######################################################################
setwd(".../GRAPE_Software/") ### set to correct directory path
source("GRAPE_Functions.R")

######################################################################
### Make balanced four tissue gene expression matrix
######################################################################
### TCGA RNASeq files of four healthy tissues
### TCGA files downloaded from: https://www.synapse.org/#!Synapse:syn300013/wiki/70804
brca_normal <- read.delim("unc.edu_BRCA_IlluminaHiSeq_RNASeqV2.geneExp.whitelist_normal",sep = "\t")
luad_normal <- read.delim("unc.edu_LUAD_IlluminaHiSeq_RNASeqV2.geneExp.whitelist_normal",sep = "\t")
kirc_normal <- read.delim("unc.edu_KIRC_IlluminaHiSeq_RNASeqV2.geneExp.whitelist_normal",sep = "\t")
hnsc_normal <- read.delim("unc.edu_HNSC_IlluminaHiSeq_RNASeqV2.geneExp.whitelist_normal",sep = "\t")

set.seed(101)
### Process data files into matrices
breast <- processTCGArawRNAseq(brca_normal, "B")
headneck <- processTCGArawRNAseq(hnsc_normal, "H")
kidney <- processTCGArawRNAseq(kirc_normal, "K")
lung <- processTCGArawRNAseq(luad_normal, "L")
### Remove outliers, see GRAPE supplementary materials for more information
breast <- breast[,-88]
headneck <- headneck[,-24] ## appears to be outlier based on col sums

### Randomly choose 35 tissues of each type
size <- 35
breast <- breast[,sample.int(ncol(breast),size)]
headneck <- headneck[,sample(1:ncol(headneck),size)]
kidney <- kidney[,sample.int(ncol(kidney),size)]
lung <- lung[,sample(1:ncol(lung),size)]

### four_tissues is the testing dataset for classification
four_tissues <- cbind(breast,headneck,kidney,lung)
labels <- as.factor(c(rep("B",size),rep("H",size),rep("K",size),rep("L",size)))

######################################################################
### Read in KEGG pathways from file
### .gmt file downloaded from: http://software.broadinstitute.org/gsea/downloads.jsp
######################################################################
kegg_pathways_file <- "c2.cp.kegg.v5.1.symbols.gmt"
### Choose example pathway
pathway <- "KEGG_FOLATE_BIOSYNTHESIS" 
path_genes <- getPathwayGenes(kegg_pathways_file,pathway)

### Get pathway expression for four tissues
pathway_four_tissues <- four_tissues[which(rownames(four_tissues)%in%path_genes),]

######################################################################
### Classification example
######################################################################
set.seed(120)
test_idc <- sample.int(ncol(pathway_four_tissues),35) 
train_mat <- pathway_four_tissues[,-test_idc]
test_mat <- pathway_four_tissues[,test_idc]
train_labels <- labels[-test_idc]
test_labels <- labels[test_idc]

yhat_grape <- predictClassGRAPE(train_mat,test_mat,train_labels,w)
yhat_dirac <- predictClassDIRAC(train_mat,test_mat,train_labels)
yhat_pc <- predictClassPC(train_mat,test_mat,train_labels)

acc_grape <- sum(diag(table(yhat_grape,test_labels)))/length(test_labels)
acc_dirac <- sum(diag(table(yhat_dirac,test_labels)))/length(test_labels)
acc_pc <- sum(diag(table(yhat_pc,test_labels)))/length(test_labels)

######################################################################
### Pathway scores example
######################################################################
### Calculate pathway score of all tissue relative to breast reference samples

pathway_breast <- pathway_four_tissues[,which(labels=="B")] ### reference samples
pathway_others <- pathway_four_tissues[,which(labels!="B")]

### scores for all samples including breast
ps_all_samples <- getPathwayScores(pathway_breast,pathway_four_tissues,w)
plot(ps_all_samples)

### scores for other samples only 
ps_others <- getPathwayScores(pathway_breast,pathway_others,w)
