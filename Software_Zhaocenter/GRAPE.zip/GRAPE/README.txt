README

Contents:
1) GRAPE_Functions.R contains the core GRAPE functions for classification and calculation of pathway scores
2) GRAPE_Example.R implements an example of GRAPE classification and calculation of pathways scores applied to TCGA RNASeq data
3) "c2.cp.kegg.v5.1.symbols.gmt" contains KEGG pathways, and is originally downloaded from: http://software.broadinstitute.org/gsea/downloads.jsp

Files 4-7 are TCGA RNASeq files, originally downloaded from https://www.synapse.org/#!Synapse:syn300013/wiki/70804
4) "unc.edu_BRCA_IlluminaHiSeq_RNASeqV2.geneExp.whitelist_normal" contains normal breast samples 
5) "unc.edu_LUAD_IlluminaHiSeq_RNASeqV2.geneExp.whitelist_normal" contains normal lung samples 
6) "unc.edu_KIRK_IlluminaHiSeq_RNASeqV2.geneExp.whitelist_normal" contains normal kidney samples 
7) "unc.edu_HNSC_IlluminaHiSeq_RNASeqV2.geneExp.whitelist_normal" contains normal head-neck samples 
 
