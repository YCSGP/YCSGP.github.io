### Source code for GRAPE
### March 16, 2016

### GRAPE is a generalization and extension of DIRAC, originally implemented in: 
### Eddy, J.A., et al., Identifying Tightly Regulated and Variably Expressed Networks by Differential Rank Conservation (DIRAC). PLoS Computational Biology, 2010. 6(5): p. e1000792.
### As a result, some of the software below has been previously published in Matlab by the DIRAC authors and can be found at: https://price.systemsbiology.org/pricelab-resources/software/
### Specifically the functions related to making templates and the function "predictClassDIRAC" are 
######################################################################

######################################################################
### Make binary template and probability template from collection of samples
######################################################################
makeBinaryTemplateAndProbabilityTemplate <- function(submat){
  ### Input: submat is matrix, columns are samples, rows are pathway genes
  ### Output: template is a list, 
  ###         template$binary_template is binary template
  ###         template$probability_template is probability template
  path_genes <- rownames(submat)
  len <- nrow(submat)
  numpairs <- len*(len-1)/2
  ### make pair names first
  pairnames <- makeTemplateNames(path_genes)
  
  ### Make binary matrix of each sample
  binary_path_mat <- matrix(NA,nrow=numpairs,ncol=ncol(submat))
  rownames(binary_path_mat) <- pairnames
  colnames(binary_path_mat) <- colnames(submat)
  for(samp in 1:ncol(binary_path_mat)){
    binary_path_mat[,samp] <- makePairwiseOrder(submat[,samp])
  }
  probability_template <- rowMeans(binary_path_mat)
  binary_template <- rep(0,numpairs)
  names(binary_template) <- pairnames
  binary_template[which(probability_template > 0.5)] <- 1
  return(list(binary_template=binary_template,probability_template=probability_template))
}

makeTemplateNames <- function(path_genes){
  ### Input: path_genes vector of pathway genes
  ### Output: pairnames is vector of names of the template, of the form "gA<gB"
  len <- length(path_genes)
  numpairs <- len*(len-1)/2
  pairnames <- rep(NA, numpairs)
  count <- 1
  for(j in 1:(len-1)){ for(k in (j+1):len){
    pairnames[count] <- paste0(path_genes[j]," < ",path_genes[k])
    count <- count + 1
  }}
  return(pairnames)
}

makePairwiseOrder <- function(onesamp){
  ### Input: onesamp is a vector of gene expression values
  ### Output: pairwise_order is a binary vector of the pairwise ranking representation of onesampe
  len <- length(onesamp)
  numpairs <- len*(len-1)/2
  pairwise_order <- vector(mode="numeric",numpairs)
  count <- 1
  for(j in 1:(len-1)){ 
    for(k in (j+1):len){
      if(onesamp[j] < onesamp[k]){pairwise_order[count] <- 1
      } else if(onesamp[j] > onesamp[k]) { pairwise_order[count] <- 0
      } else if(onesamp[j]==onesamp[k]){ ## decide tie arbitrary
        if(runif(1) > 0.5){pairwise_order[count] <- 1
        }else{pairwise_order[count] <- 0}
      }
      count <- count + 1
    }
  }
  return(pairwise_order)
}


######################################################################
### GRAPE Classification
######################################################################
### GRAPE quadratic weight function
### x can be scalar or vecor
w <- function(x){return(4*abs(x-0.5)^2)}

predictClassGRAPE <- function(trainmat, testmat, train_labels, w){
  ### Input:
  ### trainmat and testmat are matrices, columns are samples, rows are pathway genes
  ### train_labels is a vector of class labels for the training set  
  ### w is weight function
  ### Output: yhat is vector of class membership predicted by GRAPE
  if(!identical(rownames(trainmat),rownames(testmat))){print("Error: non-identical features")}
  ### Make Templates and PT using train data
  num_genes <- nrow(trainmat)
  num_pairs <- num_genes*(num_genes-1)/2
  num_classes <- length(unique(train_labels))
  classes <- sort(unique(train_labels))
  
  bin_templates <- matrix(NA,nrow=num_pairs,ncol=num_classes)
  prob_templates <- matrix(NA,nrow=num_pairs,ncol=num_classes)
  colnames(bin_templates) <- classes
  colnames(prob_templates) <- classes
  for(j in 1:num_classes){
    submat <- trainmat[,which(train_labels==classes[j])]
    temp <- makeBinaryTemplateAndProbabilityTemplate(submat)
    bin_templates[,j] <- temp$binary_template
    prob_templates[,j] <- temp$probability_template
  }
  ### we have made binary templates and probability templates for all classes
  yhat <- rep(NA, ncol(testmat)) # Vector of predicted class labels
  
  ### go through each sample in the test set
  for(smp in 1:ncol(testmat)){
    pwo <- makePairwiseOrder(testmat[,smp])
    scores <- rep(NA,num_classes)
    for(class in 1:num_classes){
      bt <- bin_templates[,class]
      pt <- prob_templates[,class]
      denominator <- sum(w(pt))
      missidc <- which(abs(pwo-bt)==1)
      scores[class] <- sum(w(pt[missidc]))/denominator
    }
    yhat[smp] <- classes[which.min(scores)]
  }
  return(yhat)  
}
######################################################################
### DIRAC Classification
######################################################################
predictClassDIRAC <- function(trainmat, testmat, train_labels){
  ### Input:
  ### trainmat and testmat are matrices, columns are samples, rows are pathway genes
  ### train_labels is a vector of class labels for the training set  
  ### Output: yhat is vector of class membership predicted by DIRAC
  if(!identical(rownames(trainmat),rownames(testmat))){print("Error: non-identical features")}
  ### Make Templates and PT using train data
  num_genes <- nrow(trainmat)
  num_pairs <- num_genes*(num_genes-1)/2
  num_classes <- length(unique(train_labels))
  classes <- sort(unique(train_labels))
  
  bin_templates <- matrix(NA,nrow=num_pairs,ncol=num_classes)
  colnames(bin_templates) <- classes
  for(j in 1:num_classes){
    submat <- trainmat[,which(train_labels==classes[j])]
    temp <- makeBinaryTemplateAndProbabilityTemplate(submat)
    bin_templates[,j] <- temp$binary_template
  } 
  ### we have made binary templates for all classes
  yhat <- rep(NA, ncol(testmat)) # Vector of predicted class labels
  
  ### go through each sample in the test set
  for(smp in 1:ncol(testmat)){
    pwo <- makePairwiseOrder(testmat[,smp])
    scores <- rep(NA,num_classes)
    for(class in 1:num_classes){
      bt <- bin_templates[,class]
      scores[class] <- sum(abs(pwo - bt))/length(bt)
    }
    yhat[smp] <- classes[which.min(scores)]
  }
  return(yhat)  
}
######################################################################
### Pathway Centroid (PC) Classification
######################################################################
predictClassPC <- function(trainmat, testmat, train_labels){
  ### Input:
  ### trainmat and testmat are matrices, columns are samples, rows are pathway genes
  ### train_labels is a vector of class labels for the training set  
  ### Output: yhat is vector of class membership predicted by PC
  if(!identical(rownames(trainmat),rownames(testmat))){print("Error: non-identical features")}
  ### Make Templates and PT using train data
  num_genes <- nrow(trainmat)
  num_classes <- length(unique(train_labels))
  classes <- sort(unique(train_labels))
  
  ### Make centroids
  centroids <- matrix(NA,nrow=nrow(trainmat),ncol=num_classes)
  colnames(centroids) <- classes
  for(j in 1:num_classes){
    submat <- trainmat[,which(train_labels==classes[j])]
    centroids[,j] <- rowMeans(submat)
  } 
  ### we have centroids for all classes
  yhat <- rep(NA, ncol(testmat)) # Vector of predicted class labels
  
  ### go through each sample in the
  for(smp in 1:ncol(testmat)){
    samp <- testmat[,smp]
    ### dirac
    scores <- rep(NA,num_classes)
    for(class in 1:num_classes){scores[class] <- sqrt(sum((centroids[,class]-samp)^2))}
    yhat[smp] <- classes[which.min(scores)]
  }
  return(yhat)  
}
######################################################################
### Pathway Score Functions
######################################################################
### Calculate reference distribution of distances from template for one pathway
refDistanceDistribution <- function(submat,w){
  ### Input: submat is matrix of n reference samples (columns) and m pathway genes
  ### w is weight function
  ### Output: dists is vector of the GRAPE distances of each reference sample to the template
  temp <- makeBinaryTemplateAndProbabilityTemplate(submat)
  bt <- temp$binary_template
  pt <- temp$probability_template
  denominator <- sum(w(pt)) 
  dists <- rep(NA,ncol(submat))
  
  for(smp in 1:ncol(submat)){
    pwo <- makePairwiseOrder(submat[,smp])
    missidc <- which(abs(pwo-bt)==1)
    goodidc <- setdiff(1:length(pwo),missidc)
    if(length(goodidc)==0)dists[smp] <- 0 ### avoid error in case of complete mismatch 
    if(length(goodidc>0)){
      accuracy <- sum(w(pt[goodidc]))/denominator
      dists[smp] <- 100*(1-accuracy)
    }
  }  
  return(dists)
}

### Calculate distances of set of samples from reference template for one pathway
getDistsFromTemplate <- function(refmat,newmat,w){
  ### Input: refmat is matrix of n reference samples (columns) and m pathway genes
  ### newmat is matrix of n non-reference (new) samples (columns) and m pathway genes
  ### w is weight function
  ### Output: dists is vector of the GRAPE distances of each new sample to the template of the reference samples
  temp <- makeBinaryTemplateAndProbabilityTemplate(refmat)
  bt <- temp$binary_template
  pt <- temp$probability_template
  denominator <- sum(w(pt)) 
  dists <- rep(NA,ncol(newmat))
  
  for(smp in 1:ncol(newmat)){
    pwo <- makePairwiseOrder(newmat[,smp])
    missidc <- which(abs(pwo-bt)==1)
    goodidc <- setdiff(1:length(pwo),missidc)
    if(length(goodidc)==0)dists[smp] <- 0 ### avoid error in case of complete mismatch 
    if(length(goodidc>0)){
      accuracy <- sum(w(pt[goodidc]))/denominator
      dists[smp] <- 100*(1-accuracy)
    }
  }  
  return(dists)
}

### Get pathway scores of single pathway
getPathwayScores <- function(refmat,newmat,w){
  ### Input: refmat is matrix of n reference samples (columns) and m pathway genes
  ### newmat is matrix of n non-reference (new) samples (columns) and m pathway genes
  ### w is weight function
  ### Output: pathway_scores is vector of the pathway scores of each new sample relative to the reference samples
  ref_dists <- refDistanceDistribution(refmat,w)
  new_dists <- getDistsFromTemplate(refmat,newmat,w)
  
  theta <- median(ref_dists) ### median
  q <- quantile(ref_dists)
  delta <- q[4] - q[2] ### inter-quartile distance
  
  pathway_scores <- (new_dists-theta)/delta
  pathway_scores[which(pathway_scores<0)] <- 0
  return(pathway_scores)
}

######################################################################
### Pathway Score Functions
######################################################################
processTCGArawRNAseq <- function(rawtcga,name_id){
  ### Input: rawtcga is the preprocessed tcga data file
  ### name_id: is the prefix to be used for naming the samples, e.g., name_id = "xy" --> samples will be named "xy1","xy2", ...
  ### Output: newtcga is matrix of gene expression with unique gene symbols as rownames
  tcga_genes <- as.character(rawtcga[,1])
  newnames <- rep(NA,length(tcga_genes))
  for(j in 1:length(tcga_genes)){
    newnames[j] <- strsplit(tcga_genes[j],'\\|')[[1]][1]
  }
  
  newtcga <- as.matrix(rawtcga[,2:ncol(rawtcga)])
  rownames(newtcga) <- newnames
  
  ### Remove no name genes 
  idc <- which(rownames(newtcga)=="?")
  newtcga <- newtcga[-idc,]
  
  ### deal with one redundant gene ### 
  temp <- table(rownames(newtcga))
  redundant <- rownames(newtcga)[which(temp>1)]
  idc <- which(rownames(newtcga) %in% redundant)
  temp <- colMeans(newtcga[idc,])
  newtcga <- newtcga[-idc,]
  newtcga <- rbind(newtcga,temp)
  rownames(newtcga)[nrow(newtcga)] <- redundant
  newtcga <- newtcga[order(rownames(newtcga)),]
  
  old_tumor_names <- colnames(newtcga)
  colnames(newtcga) <- paste0(name_id,1:ncol(newtcga))
  
  return(newtcga)
}

###################################################################################
### Function: get pathways genes from filename
###################################################################################
getPathwayGenes <- function(filename, mypath){
  ### Input: filename is .gmt pathway file, mypath is name of desired pathway
  ### Output: path_genes is vector of pathway genes
  rawpaths <- read.csv(filename)
  np <- nrow(rawpaths) 
  path_names <- rep(NA,np)
  
  for(j in 1:np){
    path <- strsplit(as.character(rawpaths[j,]),"\t")[[1]]
    path_names[j] <- path[1]
  }
  temp <- strsplit(as.character(rawpaths[which(path_names==mypath),]),'\t')[[1]]
  path_genes <- sort(temp[3:length(temp)])
  return(path_genes)
}
