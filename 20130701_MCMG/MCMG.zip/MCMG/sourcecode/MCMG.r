### load library ###
library(locfdr)
library(splines)
library(MASS)

### myfunctions ###
myiteration <- function(pivec, tol=.0001){
  likelihoodnew <- likelihood*matrix(rep(pivec,N),byrow=TRUE,nrow=N)
  conditionalprobsnew <- likelihoodnew/apply(likelihoodnew,1,sum)
  
  marginalprobsnew <- matrix(0, nrow=N, ncol=N_dis)
  for(j in 1:N_dis){
   marginalprobsnew[,j] <- apply(conditionalprobsnew[,status[,j]==1],1,sum)
  }
  
  pivecnew <- (1/N)*apply(conditionalprobsnew,2,sum)
  stopyn = "n"
  if(max(abs(pivec - pivecnew))<tol) stopyn = "y"
  return(list(conditionalprobs= conditionalprobsnew, marginalprobs=marginalprobsnew, pivec = pivecnew, stopyn = stopyn))
}

### directory of expression data and output results, name of diseases folders ###
### change to fit your data ###
dir = "/home/xc8/mirna/GMMD/testdata/exp"
dirresult = "/home/xc8/mirna/GMMD/testdata/results"
diseases = c("OV", "GBM")

#### output figure localfdr ###
pdf(paste(dirresult, "/locfdr.pdf", sep=""))

### load data calculate z scores ###
N_dis <- length(diseases)
disease = diseases[1]
ge <- read.table(paste(dir, "/", disease,"/gene.txt", sep=""), header=T, row.names=1, as.is=T)
mi <- read.table(paste(dir, "/", disease,"/mir.txt", sep=""), header=T, row.names=1, as.is=T)
nge <- nrow(ge)
nmi <- nrow(mi)

zmat <- matrix(0, ncol=N_dis, nrow=nge*nmi)
colnames(zmat) <- diseases
for(i in 1:N_dis) {
  disease = diseases[i]
  ge <- read.table(paste(dir, "/", disease,"/gene.txt", sep=""), header=T, row.names=1, as.is=T)
  mi <- read.table(paste(dir, "/", disease,"/mir.txt", sep=""), header=T, row.names=1, as.is=T)
  coc <- cor(t(ge), t(mi)) # pearson correlation
  cocp <- log((1+coc)/(1-coc))/2  # zscore
  zmat[,i] <- as.vector(unlist(cocp))
}

### local fdr calculation ###
t1 <- proc.time()

N <- nrow(zmat)
lfdr=matrix(0,N,N_dis)  #Local fdr
p0=rep(0,N_dis)         #Null prior probability   
f0=matrix(0,N,N_dis)    #Null prior density
p1f1=matrix(0,N,N_dis)    #Non-null prior density * p1

# local fdr
for(i in 1:N_dis) {
  Mfdr = locfdr(zmat[,i]);
  lfdr[,i]=Mfdr$fdr;
  p0[i]=Mfdr$fp0[3,3]
  f0[,i]=predict(interpSpline(Mfdr$mat[,1],Mfdr$mat[,6]),zmat[,i])$y
  p1f1[,i]=predict(interpSpline(Mfdr$mat[,1],Mfdr$mat[,11]),zmat[,i])$y
}

density_0 <- matrix(0, nrow = N, ncol = N_dis)
for(i in 1:N_dis){
  density_0[,i] <- lfdr[,i]/p0[i]*(p0[i]*f0[,i]+p1f1[,i]) 
}

density_1 <- matrix(0, nrow = N, ncol = N_dis)
for(i in 1:N_dis){
  density_1[,i] <- (1-lfdr[,i])/(1-p0[i])*(p0[i]*f0[,i]+p1f1[,i])
}

### Calculate likelihood of zscores ###
### initialization ###
J <- 2^N_dis
pivec <- rep(1/J,J)
likelihood <- matrix(0,nrow=N, ncol=J)
status = data.frame(c(rep(0,J/2),rep(1,J/2)))
for(coln in 2:N_dis){
   status <- cbind(status, rep(c(rep(0,J/(2^coln)),rep(1,J/(2^coln))),2^(coln-1)))
}
colnames(status) <- c(1:N_dis)

pioutput <- array(c(0, rep(1/J,J)))

for(i in 1:nrow(likelihood)) { 
    output <- matrix(0, nrow=J, ncol=N_dis)
    for(td in 1:N_dis){
      output[status[,td]==0,td] <- density_0[i,td]
      output[status[,td]==1,td] <- density_1[i,td]
    }
    likelihood[i,] <- apply(output,1, prod)
}

### iteration ###
stopyn <- FALSE
itnumber <- 1
limit <- 100

while(!stopyn & itnumber <=  limit){
  result <- myiteration(pivec)
  pivec <- result$pivec
  if(result$stopyn == "y") stopyn <- TRUE
  flush.console()
  print(itnumber)
  print(result$pivec)
  pioutput <- rbind(pioutput, c(itnumber, result$pivec))

  itnumber <- itnumber + 1
}

### force elements with positive correlation to be 0 in the output probability ###
mar <- result$marginalprobs
for(i in 1:N_dis) {
  mar[zmat[,i]>=0,i] <- 0
}

### output with gene mirna names###
gname <- rownames(ge)
mname <- rownames(mi)
gname1 <- rep(gname, length(mname))
mname1 <- as.vector(unlist(matrix(rep(mname, length(gname)), byrow=T, nrow=length(gname))))
names <- cbind(gname1, mname1)
mar <- cbind(names,mar)
colnames(mar) <- c("gene", "mirna", diseases)
write.table(mar, paste(dirresult, "/mcmgoutput.txt", sep=""), row.names=F, col.names=T,sep="\t", quote=F)

colnames(pioutput) <- 1:(J+1)
colnames(pioutput)[1] <- "itnumber"
for(i in 1:J) {
  colnames(pioutput)[i+1] <- paste("(", paste(status[i,],collapse=","), ")", sep="")
}
write.table(pioutput, paste(dirresult, "/pivectors.txt", sep=""), row.names=F, col.names=T,sep="\t", quote=F)

dev.off()

## output probability before joint analysis.
pp <- 1-lfdr
for(i in 1:N_dis) {
  pp[zmat[,i]>=0,i] <- 0
}
write.table(pp, paste(dirresult, "/prebay.txt", sep=""), row.names=F, col.names=F,sep="\t", quote=F)


