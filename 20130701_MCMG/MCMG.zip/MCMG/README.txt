Author: Xiaowei Chen @ Yale Univ.


MCMG is designed to infer the gene-microRNA pairs from joint analysis of multiple cancers.
The software is implemented in R. It is free to use and modify.

#######################
Source code file: MCMG.r

#######################
Input data format:
Input data of different cancers should be stored under one directory and each cancer has its own subdirectory. 
Gene and microRNA have separate expression files with names "gene.txt" and "mir.txt", respectively. Rows are genes or microRNAs; columns are corresponding samples in the cancer.
The expression files are pre-processed as users needs and all cancers should have the same set of genes and microRNAs in the same order in the files.

#######################
Output data:
1. mcmgoutput.txt includes the posterior probabilities of each gene-microRNA pairs for each cancer.
2. locfdr.pdf includes the plots of local fdr estimation of each cancer. Please check this file to make sure locfdr (first stage result) work properly. If not, please re-process or re-select genes in the raw files.
3. pivectors.txt includes the iterative results of pi vectors (probabilities of joint status) 

#######################
Testdata folder includes the preprocessed TCGA OV and GBM expression files. They are ready for the target calculation.

#######################
Targets information:
Two pre-created target files (predicted.txt and validated.txt) are stored in /targets/.
The files can be used to check the posterior probabilities of predicted and validated targets.
Predicted.txt includes all gene and microRNA pairs predicted by TargetScan6.1.
Validated.txt includes all gene and microRNA pairs recorded in Tarbase5.0.
