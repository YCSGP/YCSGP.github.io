Q1df <- function(theta){#### theta[1] c: equilibrium binding freq piB
 pis <- c(1-theta[1], theta[1]) # equilibrium frequency
 
 Q <- matrix(c(-theta[1], theta[1], 1-theta[1], theta[1]-1), nrow=2, byrow=TRUE)
 
  return(list("Q" = Q, "pis" = pis, "tt" = theta[-1]))
}

Q3df <- function(theta){#### theta[1:3] a, piN, piB
 piG <- 1-theta[2]-theta[3]
 piN <- theta[2]
 piB <- theta[3]
 pis <- c(piG, piN, piB) # equilibrium frequency
 Q <- matrix(c( - theta[1]*theta[2] - theta[1]*theta[3], theta[1]*theta[2], theta[1]*theta[3], 
             theta[1]*piG, - theta[1]*piG - theta[3], theta[3], 
             theta[1]*piG, theta[2], - theta[1]*piG - theta[2] ), nrow=3, byrow=TRUE)
 
 
 return(list("Q" = Q, "pis" = pis, "tt" = theta[-c(1:3)]))
}


Q4df <- function(theta){### theta[1:4]: a, b, piN, piB
 piG <- 1-theta[3]-theta[4]
 piN <- theta[3]
 piB <- theta[4]
 pis <- c(piG, piN, piB) # equilibrium frequency
 Q <- matrix(c( - theta[1]*theta[3] - theta[2]*theta[4], theta[1]*theta[3], theta[2]*theta[4], 
             theta[1]*piG, - theta[1]*piG - theta[4], theta[4], 
             theta[2]*piG, theta[3], - theta[2]*piG - theta[3] ), nrow=3, byrow=TRUE)
 
  return(list("Q" = Q, "pis" = pis, "tt" = theta[-c(1:4)]))
}


Pmat2 <- function(Q, pis, tt){
## calcutaing P=exp(Qt)
## using eigendecomposition formulae in Hobolth 2005 appendix
   #equilibrium frequencies of three states
  m <- length(pis)
  Dpi1 <- diag(x=pis^(0.5), m, m)
  Dpi2 <- diag(x=pis^(-0.5), m, m)
   
  S <- Dpi1 %*% Q %*% Dpi2
  V <- eigen(S)$vectors
  DD <- diag(x=exp(tt*eigen(S)$values), m, m)  ## only this term requires info on branch length
  pmat <- Dpi2 %*% V %*%  DD %*% t(V) %*% Dpi1
  return(list("pmat"=pmat, "eigenvectors"=V, "eigenvalues"=eigen(S)$values, "Pis"=pis, "Qmat"=Q))
  
}

 
Felsenstein.peeling <- function(tip.states, ftree, ftheta, Qdf){
## Felsenstein Peeling algorithm for a certain tree with known branch length, rate parameters, and tip node states at a single site
## report the log-likelihood of the entire tree for a single site and 
## for each node, calculate three conditional likelihood as defined below
    if (Qdf == 1){

    Q <- Q1df(ftheta)$Q; pis <- Q1df(ftheta)$pis; tt <- Q1df(ftheta)$tt;
    
    }else if (Qdf == 3){

    Q <- Q3df(ftheta)$Q; pis <- Q3df(ftheta)$pis; tt <- Q3df(ftheta)$tt;
    
    }else if (Qdf == 4){
    
     Q <- Q4df(ftheta)$Q; pis <- Q4df(ftheta)$pis; tt <- Q4df(ftheta)$tt;
    
    }
    
    if (sum(ftree$edge.length[-1] - tt) != 0 ) {
    cat("WARNING: tree branch lengths do not match theta! will replace branch length by theta.\n")
    cat("tree branch lengths: ", ftree$edge.length, "\n");
    cat("theta: ", tt, "\n");
    ftree$edge.length <- c(1, tt)
    }else if (is.null(ftree$edge.length)){
    cat("WARNING: input tree do not have branch lengths! will replace branch length by theta.\n")
    ftree$edge.length <- c(1, tt)
    }
    
    ## number of states
    m <- length(pis)
    
    Lmat <- Rmat <- Dmat <- matrix(0, nrow = ftree$Nnode, ncol = m)  # rows: internal nodes, cols: states
    #Lmat: conditional probability Ln(i) of the left subtree rooted at node n given node n is in state i;
    #Rmat: conditional probability Rn(i) of the rght subtree rooted at node n given node n is in state i;
    #Dmat: conditional probability Dn(i) of the subtree rooted at node n given node n is in state i;
        
    if (length(ftree$tip.label) != length(tip.states)) cat("ERROR: tip states do not match number of tip nodes in the tree!\n")
    nspec <- length(tip.states)
    nedge <- dim(ftree$edge)[1]
    bedge <- floor(nedge/2)
    
    for (i in 1: bedge){     #follow the order of tree$edge to go from tip nodes to root node
     node <- ftree$edge[(2*i),1] # left and right branches share the same ancestral node
     des.nodes <- ftree$edge[(2*i-1):(2*i),2]     #recode left and right descendent nodes
     pmat.left <- Pmat2(Q, pis, ftree$edge.length[(2*i-1)])
     pmat.rght <- Pmat2(Q, pis, ftree$edge.length[(2*i)])
     
     for (anc.state in 1:m){
     for (des.state in 1:m){
      
      if (des.nodes[1] <= nspec) {# left child is a tip
       Lmat[(node-nspec),anc.state] <- Lmat[(node-nspec),anc.state] + pmat.left$pmat[anc.state, des.state] * I(tip.states[des.nodes[1]] == des.state)
       }else{
       Lmat[(node-nspec),anc.state] <- Lmat[(node-nspec),anc.state] + pmat.left$pmat[anc.state, des.state] * Dmat[(des.nodes[1]-nspec), des.state]
      }
      if (des.nodes[2] <= nspec) {# rght child is a tip
      Rmat[(node-nspec),anc.state] <- Rmat[(node-nspec),anc.state] + pmat.rght$pmat[anc.state, des.state] * I(tip.states[des.nodes[2]] == des.state)
      }else{
      Rmat[(node-nspec),anc.state] <- Rmat[(node-nspec),anc.state] + pmat.rght$pmat[anc.state, des.state] * Dmat[(des.nodes[2]-nspec), des.state]
      }
    }#for des.state
    Dmat[(node-nspec),anc.state] <- Lmat[(node-nspec), anc.state] * Rmat[(node-nspec), anc.state]
     
    }#for anc.states
    }# for i
    
   
    
    root <- ftree$edge[nedge,1]     #root node is the last ancestral node listed in tree$edge
    
    if (nedge > (bedge *2) ){#unrooted tree 
    
    anc.node <- ftree$edge[nedge,2]    
    pmat.last <- Pmat2(Q, pis, ftree$edge.length[nedge])
    
    ppi <- rep(0,m)
       
     for (des.state in 1:m){
     for (anc.state in 1:m){
        ppi[des.state] <- ppi[des.state]  + pmat.last$pmat[anc.state, des.state] * I(tip.states[anc.node] == anc.state)    
     }#for states of the last tip node
    }
    
    ftree.logl <- log(sum (Dmat[(root-nspec), ] * ppi * pis[tip.states[anc.node]]))
    
    }else{ # rooted tree
    
     ftree.logl <- log(sum (Dmat[(root-nspec), ] * pis))     #log-likelihood of the entire tree is the root node state probability times its prior state probability

    }
    
    
    return(ftree.logl)
}



nopeeling <- function(tip.states, tree, theta, Qdf){
## for each combination of internal node status, calculate and store the tree likelihood

    if (Qdf == 1){

    Q <- Q1df(theta)$Q; pis <- Q1df(theta)$pis; tt <- Q1df(theta)$tt;
    
    }else if (Qdf == 3){
    Q <- Q3df(theta)$Q; pis <- Q3df(theta)$pis; tt <- Q3df(theta)$tt;
    
    }else if (Qdf == 4){
    
    Q <- Q4df(theta)$Q; pis <- Q4df(theta)$pis; tt <- Q4df(theta)$tt;
    
    }
    
    if (sum(tree$edge.length[-1] - tt) != 0 ) {
    cat("WARNING: tree branch lengths do not match theta! will replace branch length by theta.\n")
    cat("tree branch lengths: ", tree$edge.length, "\n");
    cat("theta: ", tt, "\n");
    tree$edge.length <- c(1, tt)
    }
    
    
    nn <- tree$Nnode # number of internal nodes, unrooted tree has 3 internal nodes
    m <- length(pis) # number of states
    
    Dmat <- matrix(0, nrow = m^nn, ncol = nn + 1 )  
    # on each row, store the configuration of internal nodes, and the probability of observing the entire tree given the configuration
    
    for (j in 1:nn)  Dmat[,j] <- rep(1:m,times=m^(j-1), each=m^(nn-j))#enumerate configuration of internal nodes
    Dmat[,(nn+1)] <- 1
    
    nedge <- dim(tree$edge)[1]
    
    pmat <- Pmat2(Q, pis, 1)
    V <- pmat$eigenvectors; l <- pmat$eigenvalues
      
    Dpi1 <- diag(x=pis^(0.5), m, m)
    Dpi2 <- diag(x=pis^(-0.5), m, m)
   
    for (j in 1:nedge){ #follow the order of tree$edge to go from tip nodes to root node
     
    DD <- diag(x=exp(tree$edge.length[j]*l), m, m)  ## only this term requires info on branch length
    pmat.tt <- Dpi2 %*% V %*%  DD %*% t(V) %*% Dpi1
  
     for (i in 1:m^nn){ # for each internal nodes confguration
     
      confg <- c(tip.states, Dmat[i,1:nn])
      ai <- confg[tree$edge[j,1]]; di <- confg[tree$edge[j,2]]
      Dmat[i,(nn+1)] <- Dmat[i,(nn+1)] * pmat.tt[ai,di]        
    
     }#each confg
    
     }# for jth branch
    
      # assign prior probability to the root node, here assuming reversibility and use equilibrium freq as root prior probability
     for (i in 1:m) Dmat[Dmat[,1]==i,(nn+1)] <- Dmat[Dmat[,1]==i,(nn+1)] * pis[i]
    
 
    
    return(Dmat)
   
}

allikelihood <- function(state.cunt, tree, theta, Qdf, method="peeling"){
 logl <- 0
 nspec <- dim(state.cunt)[2] -1
 for (site in 1:dim(state.cunt)[1]){
 tip.states <- state.cunt[site,1:nspec]
 
 if (method == "peeling"){
 # use peeling algorithm
 singlel <- Felsenstein.peeling(tip.states,tree, theta, Qdf)
 logl <- logl + state.cunt[site,nspec+1] * singlel
  
 }else{
 # use no peeling algorithm
 Dmat <- nopeeling(tip.states, tree, theta, Qdf)
 logl <- logl + state.cunt[site,nspec+1] * logb(sum(Dmat[,nspec]))
 
 }
 
 }
return(logl)
}

pat.likelihood <- function(tree, theta, Qdf, unobs=FALSE){
## calculate the likelihood of each pattern given the current tree and rate parameters  
  nn <- length(tree$tip.label) # number of tip nodes / species
  
  if (Qdf > 1){# 3 states, 
   sitepattern <- matrix(0, nrow = 3^nn, ncol = nn + 1 )  
  # on each row, store the configuration of tip nodes, and the probability of observing the entire tree given the configuration
  for (j in 1:nn)  sitepattern[,j] <- rep(1:3,times=3^(j-1), each=3^(nn-j))
  
  for (siter in 1: (3^nn))  sitepattern[siter, (nn+1)]  <- exp(Felsenstein.peeling(sitepattern[siter, 1:nn], tree, theta, Qdf))
  
  } else if (Qdf == 1){
   sitepattern <- matrix(1, 1, ncol=nn+1)
   sitepattern[1, (nn+1)]  <- exp(Felsenstein.peeling(rep(1, nn), tree, theta, Qdf))
  }
  
  if (unobs==TRUE){
  unobs.idx <- grep("3", apply(sitepattern[,1:nn], 1, paste, collapse=""), , invert=TRUE)
  sitepattern <- sitepattern[unobs.idx, ]
  } 
  return(sitepattern)
}


two.part.integral <- function(aa, bb, cc, dd, V, l, pis, t0){
 l <- round(l, 8)
 m <- length(l)
 V <- round(V, 8)
 tempsum1 <- 0
   for (ii in 1:m){
   tempsum2 <- 0
   for (jj in 1:m){
   if (l[ii]==l[jj]) {
    Jij <- t0*exp(t0*l[ii])
   
    } else{ 
    Jij <-  (exp(t0*l[ii]) - exp(t0*l[jj]))/(l[ii]- l[jj]) 
    
    } #integral limit should be t0=1 when we consider rate matrix Q changes to tt*Q
   tempsum2 <- tempsum2 + V[cc, jj]*V[dd, jj]*Jij 
    }#jj
   tempsum1 <- tempsum1 + tempsum2 * V[aa, ii]*V[bb, ii] 
   }#ii
  integral <-  sqrt(pis[dd]*pis[bb]/(pis[aa]*pis[cc])) * tempsum1 
  return( integral)
}

three.part.integral <- function(aa, bb, cc, dd, ee, ff, V, l, pis, t0){
 l <- round(l, 8)
 m <- length(l)
 V <- round(V, 8)
 
 tempsum1 <- 0
   for (ii in 1:m){
   tempsum2 <- 0
   for (jj in 1:m){
   tempsum3 <- 0
   for (kk in 1:m){
    
    Iijk <- 0
    
    if (l[ii]==l[jj] && l[jj]==l[kk]) {
    
    Iijk <- t0^2 * exp(t0*l[ii])/2
  #  cat("case 1", ii, jj, kk, Iijk, "\n")
    
    } else if (l[ii]==l[jj] && l[ii]!=l[kk]){ 
    
    Iijk <- ( exp(t0*l[kk]) - exp(t0*l[ii]) )/(l[ii] - l[kk])^2 + t0*exp(t0*l[ii])/(l[ii] - l[kk])
   # cat("case 2", ii, jj, kk, Iijk, "\n")
    
    } else if (l[ii]!=l[jj] && l[ii]==l[kk]){
    
    Iijk <- t0*exp(t0*l[kk])/(l[ii] - l[jj]) - (exp(t0*l[jj]) - exp(t0*l[kk]))/((l[ii] - l[jj])*(l[jj] - l[kk]))
  #  cat("case 3", ii, jj, kk, Iijk, "\n")
    
    } else if (l[ii]!=l[jj] && l[jj]==l[kk]){
    
    Iijk <- (exp(t0*l[ii]) - exp(t0*l[kk]))/((l[ii] - l[jj])*(l[ii] - l[kk])) - t0*exp(t0*l[kk])/(l[ii] - l[jj])
   # cat("case 4", ii, jj, kk, Iijk, "\n")
    
    } else if (l[ii]!=l[jj] && l[jj]!=l[kk]){
    
    Iijk <- (exp(t0*l[ii]) - exp(t0*l[kk]))/((l[ii] - l[jj])*(l[ii] - l[kk])) - (exp(t0*l[jj]) - exp(t0*l[kk]))/((l[ii] - l[jj])*(l[jj] - l[kk]))
    #cat("case 5", ii, jj, kk, Iijk, "\n")
    
    }#integral limit should be t0
   
   tempsum3 <- tempsum3 + V[ee, kk]*V[ff, kk]*Iijk
   
   }#kk
   tempsum2 <- tempsum2 + tempsum3 * V[cc, jj]*V[dd, jj] 
    
   }#jj
   tempsum1 <- tempsum1 + tempsum2 * V[aa, ii]*V[bb, ii] 
   
   }#ii
  integral <-  sqrt((pis[bb]*pis[dd]*pis[ff])/(pis[aa]*pis[cc]*pis[ee])) * tempsum1 
   
 return( integral)
}

cond.mean <- function(anc, des, tt, pmi){
 V <- round(pmi$eigenvectors, 8)
 l <- round(pmi$eigenvalues, 8)
 pis <- pmi$Pis
 m <- length(l)
 
 Dpi1 <- diag(x=pis^(0.5), m,m)
 Dpi2 <- diag(x=pis^(-0.5), m,m)
 DD <- diag(x=exp(tt*l), m, m)  ## only this term requires info on branch length
 pmat.tt <- Dpi2 %*% V %*%  DD %*% t(V) %*% Dpi1
 
 
 ER <- rep(0, m^2)
 for (j in 1:m){#row
  for (k in 1:m){#col
   integral <- two.part.integral(anc, j, k, des, V, tt*l, pis, 1)
  if (j==k){ER[m*(j-1)+k] <- integral/pmat.tt[anc, des]}else{ ER[m*(j-1)+k] <- tt*pmi$Qmat[j,k]*integral/pmat.tt[anc, des]}  
  
   }#k col
 }#j row
return(ER) 
}



cond.var <- function(anc.state, des.state, tt, pmat2){
### this is to calculate E_theta0[RiRi*|y,a(i), d(i)], a 9 by 9 matrix
### given a branch with ancestral node in state a, descdent node in state b
### calculate the conditional covaraince matrix of Ri given observed data, using the current parameter estimates
### a, b are all integers in 1:3
### tt specifies the integral limit T, which is usually 1 in our case 
### pmat2 is the output list from Pmat2 function 

 V <- round(pmat2$eigenvectors, 8)
 l <- round(pmat2$eigenvalues, 8)
 pis <- pmat2$Pis
 m <- length(l)
 
 
 Dpi1 <- Dpi2 <- matrix(0, nrow=m, ncol=m)
 Dpi1[row(Dpi1)==col(Dpi1)] = pis^(0.5)
 Dpi2[row(Dpi2)==col(Dpi2)] = pis^(-0.5)
 DD <- matrix(0, nrow=m, ncol=m)
 DD[row(DD)==col(DD)] = exp(tt*l) ## only this term requires info on branch length
 pmat.tt <- Dpi2 %*% V %*%  DD %*% t(V) %*% Dpi1
 
 t0 <- 1
 ## specify the order of elements in the ER matrix, sort by row, to match qtheta
 ele <- matrix("N", m, m)
 ele[row(ele)==col(ele)] <- "T"
 elements <- data.frame("type"= as.character(ele), "from"=as.numeric(col(ele)), "to"=as.numeric(row(ele)))

 ERR <- matrix(0, m^2, m^2)
 
  
 for (erow in 1:(m^2)){
  for (ecol in 1:(m^2)){
    
    j <- k <- ll <- j1 <- k1 <- j2 <- k2 <- 0
      
    if (elements[erow, 1] == "T" && elements[ecol, 1] == "T"){
     j <- elements[erow,2]; k<- elements[ecol,2]
     
     ERR[erow, ecol] <- ( three.part.integral(anc.state, j, j, k, k, des.state, V, tt*l, pis, 1) + 
                         three.part.integral(anc.state, k, k, j, j, des.state, V, tt*l, pis, 1) ) / pmat.tt[anc.state, des.state] 
                       
    }else if (elements[erow, 1] == "T" && elements[ecol, 1] == "N"){
     j <- elements[ecol,2]; k<- elements[ecol,3]; ll<- elements[erow,2]
      
     ERR[erow, ecol] <- tt * pmat2$Qmat[j, k] * ( three.part.integral(anc.state, j, k, ll, ll, des.state, V, tt*l, pis, 1) + 
                        three.part.integral(anc.state, ll, ll, j, k, des.state, V, tt*l, pis, 1) ) / pmat.tt[anc.state, des.state]  
                       
    }else if (elements[erow, 1] == "N" && elements[ecol, 1] == "T"){
     j <- elements[erow,2]; k<- elements[erow,3]; ll<- elements[ecol,2]

     ERR[erow, ecol] <- tt * pmat2$Qmat[j, k] * ( three.part.integral(anc.state, j, k, ll, ll, des.state, V, tt*l, pis, 1) + 
                  three.part.integral(anc.state, ll, ll, j, k, des.state, V, tt*l, pis, 1) ) / pmat.tt[anc.state, des.state]  
                         
    }else if (elements[erow, 1] == "N" && elements[ecol, 1] == "N"){
     j1 <- elements[erow, 2]; k1 <- elements[erow, 3]; j2 <- elements[ecol, 2]; k2 <- elements[ecol, 3];  
     
     ERR[erow, ecol] <- ( I(erow == ecol) * tt * pmat2$Qmat[j1,k1] * two.part.integral(anc.state, j1, k1, des.state, V, tt*l, pis, 1) + 
     tt^2 * pmat2$Qmat[j1,k1] * pmat2$Qmat[j2,k2] * ( three.part.integral(anc.state, j1, k1, j2, k2, des.state, V, tt*l, pis, 1) + 
     three.part.integral(anc.state, j2, k2, j1, k1, des.state, V, tt*l, pis, 1)) )/ pmat.tt[anc.state, des.state]
                        
    }
    
 
  }#ecol
 }#erow
return(ERR) # a m^2 by m^2 matrix
}


tree.cond.mean <- function(tcm.tip.states, tcm.tree, tcm.theta, Qdf = 3){
## this function calculates 8*9 matrix of ERi representing conditional means for each of the 8 branches
## need to store them separately to update theta
## this is for a single site (tip.states pattern)
## theta is the vector of all parameters: 
    if (Qdf == 1){
    
    Q <- Q1df(tcm.theta)$Q; pis <- Q1df(tcm.theta)$pis; tt <- Q1df(tcm.theta)$tt;
    
    }else if (Qdf == 3){
    
    Q <- Q3df(tcm.theta)$Q; pis <- Q3df(tcm.theta)$pis; tt <- Q3df(tcm.theta)$tt;
    
    }else if (Qdf == 4){
    
    Q <- Q4df(tcm.theta)$Q; pis <- Q4df(tcm.theta)$pis; tt <- Q4df(tcm.theta)$tt;
    
    }
    
    if (sum(tcm.tree$edge.length[-1] - tt) != 0 ) {
    cat("WARNING: tree branch lengths do not match theta! will replace branch length by theta.\n")
    cat("tree branch lengths: ", tree$edge.length, "\n");
    cat("theta: ", tt, "\n");
    tree$edge.length <- c(1, tt)
    }
   
 Dmat <- nopeeling(tcm.tip.states, tcm.tree, tcm.theta, Qdf)
 lc <- dim(Dmat)[2]
 pb <- sum(Dmat[,lc])
 
 nedge <- dim(tcm.tree$edge)[1] #number of tree edges
 dimq <- dim(Q)[1]
 nspec <- length(tcm.tip.states)
 
 eri.tree <- matrix(0, nedge, dimq^2)
 
 pmi <- Pmat2(Q, pis, 1)
 
 
 for (branch in 1:nedge){
  anc.node <- tcm.tree$edge[branch,1]
  des.node <- tcm.tree$edge[branch,2]
 
  for (a in 1:dimq){
  for (b in 1:dimq){
  
   eri <- cond.mean(a, b, tcm.tree$edge.length[branch], pmi)
   
   if ((des.node <= nspec) ){
    pab <- sum(Dmat[which(Dmat[,(anc.node-nspec)]==a),lc]) * I(tcm.tip.states[des.node] == b)/pb
   }else if (des.node > nspec){
    pab <- sum(Dmat[intersect(which(Dmat[,(anc.node-nspec)]==a), which(Dmat[,(des.node-nspec)]==b)),lc])/pb 
   }
 
   eri.tree[branch, ] <- eri.tree[branch, ] + eri*pab
  }#for b
 }#for a

}# branch
 
return(eri.tree)
}


tree.cond.var <- function(tip.states, tree, theta, Qdf){
## this function calculates m*m*9*9 array of E(RiRj|y) representing conditional var(covar)s for branches i and j (from 1 to m)
## this is for a single site (tip.states pattern)
## theta is the vector of all parameters:  c, g, k, plus (m-1) branch lengths t2...tm
    if (Qdf == 1){
    
    Q <- Q1df(theta)$Q; pis <- Q1df(theta)$pis; tt <- Q1df(theta)$tt;
    
    }else if (Qdf == 3){
    
    Q <- Q3df(theta)$Q; pis <- Q3df(theta)$pis; tt <- Q3df(theta)$tt;
    
    }else if (Qdf == 4){
    
    Q <- Q4df(theta)$Q; pis <- Q4df(theta)$pis; tt <- Q4df(theta)$tt;
    
    }

    
    if (sum(tree$edge.length[-1] - tt) != 0 ) {
    cat("WARNING: tree branch lengths do not match theta! will replace branch length by theta.\n")
    cat("tree branch lengths: ", tree$edge.length, "\n");
    cat("theta: ", tt, "\n");
    tree$edge.length <- c(1, tt)
    }
   
 m <- dim(tree$edge)[1] #number of tree edges
 dimq <- dim(Q)[1]  # number of states 
 erirj <- array(0, dim=c(m, m, dimq^2, dimq^2))
 
 Dmat <- nopeeling(tip.states, tree, theta, Qdf)
 lc <- dim(Dmat)[2]
 pb <- sum(Dmat[,lc])
 pmi <- Pmat2(Q, pis, 1)

nspec <- length(tip.states)

for (i in 1:m){
for (j in 1:m){
 
 
 anci <- tree$edge[i,1]
 desi <- tree$edge[i,2]
 ancj <- tree$edge[j,1]
 desj <- tree$edge[j,2]
  
 if (i == j){
  for (a in 1:dimq){
  for (b in 1:dimq){
  
   err <- cond.var(a, b, tree$edge.length[i], pmi)
   
   if ((desi <= nspec) ){
    pab <- sum(Dmat[which(Dmat[,(anci-nspec)]==a),lc]) * I(tip.states[desi] == b)/pb
   }else if (desi > nspec){
    pab <- sum(Dmat[intersect(which(Dmat[,(anci-nspec)]==a), which(Dmat[,(desi-nspec)]==b)),lc])/pb 
   }
   
   erirj[i,j,,] <- erirj[i,j,,] + err*pab
   }#for b
   }#for a
 
 }else{## if i!=j
  
  for (a in 1:dimq){
  for (b in 1:dimq){
  for (cc in 1:dimq){
  for (d in 1:dimq){
   err <- cond.mean(a, b, tree$edge.length[i], pmi) %*% t(cond.mean(cc,d, tree$edge.length[j], pmi))
   
   if ((desi <= nspec) && (desj <= nspec) ){
    pabcd <- sum(Dmat[intersect(which(Dmat[,(anci-nspec)]==a), which(Dmat[,(ancj-nspec)]==cc)),lc]) * I(tip.states[desi] == b)* I(tip.states[desj] == d)/pb
   }else if (desi > nspec && desj > nspec){
    selc <- intersect(which(Dmat[,(anci-nspec)]==a), which(Dmat[,(desi-nspec)]==b))
    selc <- intersect(selc, which(Dmat[,ancj-nspec]==cc))
    selc <- intersect(selc, which(Dmat[,(desj-nspec)]==d))
    pabcd <- sum(Dmat[selc,lc])/pb 
   }else if (desi <= nspec && desj > nspec){
    selc <- intersect(which(Dmat[,(ancj-nspec)]==cc), which(Dmat[,(desj-nspec)]==d))
    selc <- intersect(selc, which(Dmat[,anci-nspec]==a))
    pabcd <- sum(Dmat[selc,lc])* I(tip.states[desi] == b)/pb
   }else if (desi > nspec && desj <= nspec){
    selc <- intersect(which(Dmat[,(anci-nspec)]==a), which(Dmat[,(desi-nspec)]==b))
    selc <- intersect(selc, which(Dmat[,ancj-nspec]==cc))
    pabcd <- sum(Dmat[selc,lc])* I(tip.states[desj] == d)/pb
   }
   
   erirj[i,j,,] <- erirj[i,j,,] + err*pabcd
   }#for d
   }#for cc
   }#for b
   }#for a
 
 
 }# if i==j or not
}#for j
}#for i

  
return(erirj) # an array 

}


EM1df <- function(start.tree = NULL, start.theta = NULL, obsdata = NULL, maxiter = 1000, stop.threshold = 0.00001, incomplete = TRUE, Qdf=1){
########################
### initialize parameters: 1 rates and 7 branch length, branch 1 has a fixed length 1 
########################
theta <- start.theta
tree <- start.tree 
npar <- length(theta)
nedge <- dim(tree$edge)[1]
nspec <- dim(obsdata)[2] - 1
nsite <- sum(obsdata[, nspec+1])

tree$edge.length <- c(1, theta[-1])
smallp <- 0.000001

####################################
### iterations 
####################################

for (iter in 1:maxiter){

cat("start iteration ", iter, "\n")

cat("Current parameter estimates: ", theta, "\n")

logl <- allikelihood(obsdata, tree, theta, Qdf)

cat("Current logL: ", logl, "\n" )


## E-step: calculate conditional means of ER for each branch and each site pattern
## and then weighted average over all site patterns

alleri <- matrix(0, nedge, 4) # corresponds to number of elements in the 2 by 2 matrix

for (pat in 1:dim(obsdata)[1]){#observed data part
 tip.states <- obsdata[pat,1:nspec]
 alleri <- alleri + obsdata[pat, nspec+1] * tree.cond.mean(tip.states, tree, theta, Qdf)
}

cond.logl <- NULL
if (incomplete == TRUE){
unobs.l <- pat.likelihood(tree, theta, Qdf, unobs=TRUE)
L0 <- unobs.l[1,nspec+1]
cond.logl <- logl - nsite * log(1-L0)
cat("Current conditional logL: ", cond.logl, "\n") 
tip.states <- unobs.l[1,1:nspec]
alleri <- alleri +  nsite * unobs.l[1,nspec+1] * tree.cond.mean(tip.states, tree, theta, Qdf) / (1-L0)
}

## M-step: update branch lengths and theta iteratively
bl <- c(1, theta[-1])
A1 = sum(alleri[,1] * bl)
A2 = sum(alleri[,2])
A3 = sum(alleri[,3])
A4 = sum(alleri[,4] * bl)


## update  c
AA = A4 - A1
BB = A1 - A4 + A2 + A3
newc <-  max((-BB + sqrt(BB^2 + 4*AA*A2))/ (2*AA), smallp)
newc <- min(newc, 1-smallp) ## limit newc in the range of (0,1)


## update branch length
newbl <- apply(alleri[,c(2,3)], 1, sum)/( alleri[,1]*newc + alleri[,4]*(1-newc) ) # one redundant branch length
newbl[1] <- 1

newtheta <- c(newc, newbl[-1])
newtree <- tree 
newtree$edge.length <- newbl 

# outer cycle stopping rule: theta stablizes
if (max(abs( (newtheta - theta) / theta)) < stop.threshold) break;

theta <- newtheta
tree <- newtree

}#out cycle

### scale the branch lengths and Q
sf <- 1/ (2*theta[1]*(1-theta[1]))

if (incomplete){
 return(list("theta" = theta, "scale.factor" = sf, "logl" = logl, "cond.logl" = cond.logl, "iteration" = iter))
}else{
 return(list("theta" = theta, "scale.factor" = sf, "logl" = logl, "iteration" = iter))
}

}#end of EM1df function


EM3df <- function(start.tree = NULL, start.theta = NULL, obsdata = NULL, maxiter = 1000, stop.threshold = 0.00001, incomplete = TRUE, Qdf=3, rateonly = FALSE, verbose = FALSE){
########################
### initialize parameters: 3 rates and 6 branch length, branch 1 has a fixed length 1 
########################

theta <- start.theta
fixbl <- theta[-c(1:3)]

testpi <- theta[2] + theta[3]
if (testpi > 0.99){ #if \pi_N and \pi_B starting points not good, adjust to something that satisfies constraint
 cat("piN and piB starting points are not sensible: ", theta[2],"\t", theta[3],  "\n")
 theta[3] <- theta[3] / (2*testpi)
 theta[2] <- theta[2] / (2*testpi)
 cat("adjust to new starting points: ", theta[2],"\t", theta[3],  "\n")
 }

tree <- start.tree 
npar <- length(theta)
nedge <- dim(tree$edge)[1]
nspec <- dim(obsdata)[2] - 1
nsite <- sum(obsdata[, nspec+1])

tree$edge.length <- c(1, theta[-c(1:3)])
smallp <- 0.000001

####################################
### iterations 
####################################

for (iter in 1:maxiter){

cat("start iteration ", iter, "\n")

cat("Current parameter estimates: ", theta, "\n")

logl <- allikelihood(obsdata, tree, theta, Qdf)

cat("Current logL: ", logl, "\n" )


## E-step: calculate conditional means of ER for each branch and each site pattern
## and then weighted average over all site patterns

alleri <- matrix(0, nedge, 9)

for (pat in 1:dim(obsdata)[1]){#observed data part
 tip.states <- obsdata[pat,1:nspec]
 alleri <- alleri + obsdata[pat, (nspec+1)] * tree.cond.mean(tip.states, tree, theta, Qdf)
}

cond.logl <- NULL
if (incomplete == TRUE){
unobs.l <- pat.likelihood(tree, theta, Qdf, unobs=TRUE)
L0 <- sum(unobs.l[, (nspec+1)])
cond.logl <- logl - nsite * log(1-L0)
cat("Current conditional logL: ", cond.logl, "\n") 

for (pat in 1:dim(unobs.l)[1]){#unobserved data part
 tip.states <- unobs.l[pat,1:nspec]
 alleri <- alleri +  nsite * unobs.l[pat, (nspec+1)] * tree.cond.mean(tip.states, tree, theta, Qdf) / (1-L0)
}

}

## M-step: update branch lengths and a, b, pis iteratively
A <- rep(0, 9)
for (i in c(2, 3, 4, 6, 7, 8)){
 A[i] = sum(alleri[,i])
}

if (rateonly) {
 bl <- c(1, fixbl)
 } else{
 bl <- c(1, theta[-c(1:Qdf)])
 }
 
abpi <- theta[1:Qdf]
## keep a, pin, pib in boundary
a <- max(abpi[1], smallp)
piN <- max(abpi[2], smallp)
piB <- max(abpi[3], smallp)
piG <- max(1-piN-piB, smallp)
piN <- min(piN, 1-smallp)
piB <- min(piB, 1-smallp)
piG <- min(piG, 1-smallp)

for (inner.iter in 1:100){# iterate between updating abpi and updating branch lengths


## update  a, b, pis
for (i in c(1, 5, 9)){
 A[i] = sum(alleri[,i] * bl)
}

## keep a, pin, pib in boundary

a <- max((A[2] + A[4] + A[3] + A[7]) / (A[1]*(piN + piB) + (A[5] + A[9])*piG), smallp)


pinb.f <- function(X, a, A){
 eq3 <- a*(A[5] - A[1]) + A[9]*(a - 1) + (A[2] + A[8])/X[1] - (A[4] + A[7])/(1 - X[1] - X[2])
 eq4 <- a*(A[9] - A[1]) + A[5]*(a - 1) + (A[3] + A[6])/X[2] - (A[4] + A[7])/(1 - X[1] - X[2])
 return(eq3^2 + eq4^2)
}

npi <- optim(c(piN, piB), pinb.f,  a=a, A=A)$par
piN <- max(npi[1], smallp)
piB <- max(npi[2], smallp)
piG <- max( 1 - piN - piB, smallp)
piN <- min(piN, 1-smallp)
piB <- min(piB, 1-smallp)
piG <- min(piG, 1-smallp)


## update branch length
if (rateonly){newbl <- bl
}else{
newbl <- apply(alleri[,c(2, 3, 4, 6, 7, 8)], 1, sum)/( a*(piN + piB)*alleri[,1] + (a*piG + piB)*alleri[,5] + (a*piG + piN)*alleri[,9]) # one redundant branch length
newbl[1] <- 1
}
newabpi <- c(a, piN, piB)

if (verbose) cat("inner iteration: ", inner.iter, "parameter estimation: ", c(newabpi, newbl[-1]), "\n")

# inner cycle stopping rule: theta stabilizes
if (max(abs( (newabpi - abpi) / abpi)) < stop.threshold) break;

abpi <- newabpi

} #inner cycle

newtheta <- c(newabpi, newbl[-1])
newtree <- tree 
newtree$edge.length <- newbl 

# outer cycle stopping rule: theta stablizes
if (max(abs( (newtheta - theta) / theta)) < stop.threshold) break;

theta <- newtheta
tree <- newtree

}#out cycle

### scale the branch lengths and Q
sf <-  1/(2*theta[1]*piN*piG + 2*theta[1]*piB*piG + 2*piN*piB)


if (incomplete){
 return(list("theta" = theta, "scale.factor" = sf, "logl" = logl, "cond.logl" = cond.logl, "iteration" = iter))
}else{
 return(list("theta" = theta, "scale.factor" = sf, "logl" = logl, "iteration" = iter))
}

}#end of EM3df function


EM4df <- function(start.tree = NULL, start.theta = NULL, obsdata = NULL, maxiter = 1000, stop.threshold = 0.00001, incomplete = TRUE, Qdf=4, rateonly = FALSE, verbose=FALSE){
########################
### initialize parameters: 4 rates and 6 branch length, branch 1 has a fixed length 1 
########################
theta <- start.theta
fixbl <- theta[-c(1:4)]

testpi <- theta[3] + theta[4]
if (testpi > 0.99){ #if \pi_N and \pi_B starting points not good, adjust to something that satisfies constraint
 cat("piN and piB starting points are not sensible: ", theta[3],"\t", theta[4],  "\n")
 theta[3] <- theta[3] / (2*testpi)
 theta[4] <- theta[4] / (2*testpi)
 cat("adjust to new starting points: ", theta[3],"\t", theta[4],  "\n")
 }

tree <- start.tree 
npar <- length(theta)
nedge <- dim(tree$edge)[1]
nspec <- dim(obsdata)[2] - 1
nsite <- sum(obsdata[, nspec+1])

tree$edge.length <- c(1, theta[-c(1:Qdf)])
smallp <- 0.000001

####################################
### iterations 
####################################

for (iter in 1:maxiter){

cat("start iteration ", iter, "\n")

cat("Current parameter estimates: ", theta, "\n")

logl <- allikelihood(obsdata, tree, theta, Qdf)

cat("Current logL: ", logl, "\n" )


## E-step: calculate conditional means of ER for each branch and each site pattern
## and then weighted average over all site patterns

alleri <- matrix(0, nedge, 9)

for (pat in 1:dim(obsdata)[1]){#observed data part
 tip.states <- obsdata[pat,1:nspec]
 alleri <- alleri + obsdata[pat, (nspec+1)] * tree.cond.mean(tip.states, tree, theta, Qdf)
}

cond.logl <- NULL
if (incomplete){
unobs.l <- pat.likelihood(tree, theta, Qdf, unobs=TRUE)
L0 <- sum(unobs.l[, (nspec+1)])
cond.logl <- logl - nsite * log(1-L0)
cat("Current conditional logL: ", cond.logl, "\n") 

for (pat in 1:dim(unobs.l)[1]){#unobserved data part
 tip.states <- unobs.l[pat,1:nspec]
 alleri <- alleri +  nsite * unobs.l[pat, (nspec+1)] * tree.cond.mean(tip.states, tree, theta, Qdf) / (1-L0)
}

}#correct for ascertaiment bias part

## M-step: update branch lengths and a, b, pis iteratively
A <- rep(0, 9)
for (i in c(2, 3, 4, 6, 7, 8)){
 A[i] = sum(alleri[,i])
}

if (rateonly) {
 bl <- c(1, fixbl)
 } else{
 bl <- c(1, theta[-c(1:Qdf)])
 }
 

abpi <- theta[1:Qdf]
## keep a, b, pin, pib in boundary
a <- max(abpi[1], smallp)
b <- max(abpi[2], smallp)
piN <- max(abpi[3], smallp)
piB <- max(abpi[4], smallp)
piG <- max(1-piN-piB, smallp)
piN <- min(piN, 1-smallp)
piB <- min(piB, 1-smallp)
piG <- min(piG, 1-smallp)

for (inner.iter in 1:100){# iterate between updating abpi and updating branch lengths


## update  a, b, pis
for (i in c(1, 5, 9)){
 A[i] = sum(alleri[,i] * bl)
}

## keep a, b, pin, pib in boundary

a <- max((A[2] + A[4]) / (A[1]*piN + A[5]*piG), smallp)
b <- max((A[3] + A[7]) / (A[1]*piB + A[9]*piG), smallp)

pinb.f <- function(X, a, b, A){
 eq3 <- a*(A[5] - A[1]) + A[9]*(b - 1) + (A[2] + A[8])/X[1] - (A[4] + A[7])/(1 - X[1] - X[2])
 eq4 <- b*(A[9] - A[1]) + A[5]*(a - 1) + (A[3] + A[6])/X[2] - (A[4] + A[7])/(1 - X[1] - X[2])
 return(eq3^2 + eq4^2)
}

npi <- optim(c(piN, piB), pinb.f,  a=a, b=b, A=A,hessian = FALSE)$par
piN <- max(npi[1], smallp)
piB <- max(npi[2], smallp)
piG <- max( 1 - piN - piB, smallp)
piN <- min(piN, 1-smallp)
piB <- min(piB, 1-smallp)
piG <- min(piG, 1-smallp)


## update branch length
if (rateonly){
newbl <- bl
}else{
newbl <- apply(alleri[,c(2, 3, 4, 6, 7, 8)], 1, sum)/( (a*piN + b*piB)*alleri[,1] + (a*piG + piB)*alleri[,5] + (b*piG + piN)*alleri[,9]) # one redundant branch length
newbl[1] <- 1
}
newabpi <- c(a, b, piN, piB)

if (verbose)  cat("inner iteration: ", inner.iter, "parameter estimation: ", c(newabpi, newbl[-1]), "\n")

# inner cycle stopping rule: theta stabilizes
if (max(abs( (newabpi - abpi) / abpi)) < stop.threshold) break;

abpi <- newabpi
bl <- newbl

} #inner cycle

newtheta <- c(newabpi, newbl[-1])
newtree <- tree 
newtree$edge.length <- newbl 

# outer cycle stopping rule: theta stablizes
if (max(abs( (newtheta - theta) / theta)) < stop.threshold) break;

theta <- newtheta
tree <- newtree

}#out cycle

### scale the branch lengths and Q
piN <- theta[3]
piB <- theta[4]
piG <- 1- piN - piB
sf <- 1/(2*theta[1]*piN*piG + 2*theta[2]*piB*piG + 2*piN*piB)

if (incomplete){
 return(list("theta" = theta, "scale.factor" = sf, "logl" = logl, "cond.logl" = cond.logl, "iteration" = iter))
}else{
 return(list("theta" = theta, "scale.factor" = sf, "logl" = logl, "iteration" = iter))
}

}#end of EM4df function

fisher <- function(state.cunt, finaltheta, finaltree, Qdf, rateonly = TRUE){

require(numDeriv)

if (sum(finaltree$edge.length[-1] - finaltheta[(Qdf+1):(Qdf+6)]) != 0 ) {
    cat("WARNING: tree branch lengths do not match theta! will replace branch length by theta.\n")
    cat("tree branch lengths: ", finaltree$edge.length, "\n");
    cat("theta: ", finaltheta[(Qdf+1):(Qdf+6)], "\n");
    finaltree$edge.length <- c(1, finaltheta[(Qdf+1):(Qdf+6)])
    }else if (is.null(finaltree$edge.length)){
    cat("WARNING: input tree do not have branch lengths! will replace branch length by theta.\n")
    finaltree$edge.length <- c(1, finaltheta[(Qdf+1):(Qdf+6)])
    }

 npar <- length(finaltheta)
 if (rateonly == TRUE) npar <- npar - 6 
 nedge <- length(finaltree$edge.length)
 nspec <- dim(state.cunt)[2] - 1


 fi <- matrix(0, npar, npar)

 for (pat in 1:dim(state.cunt)[1]){#observed data part
 
   tip.states <- state.cunt[pat,1:nspec]

   er <- tree.cond.mean(tip.states, finaltree, finaltheta, Qdf)
   err <- tree.cond.var(tip.states, finaltree, finaltheta, Qdf)

    ####### calculate first part E[hessian(Lc0)], we need the negative of this value
    eit <- hessian(qithetaER, finaltheta[1:npar], finaltree = finaltree, er = er, expo = FALSE, method.args=list(zero.tol=1e-7))
    
    ####### calculate second part E[S(theta;R)S*(theta;R)|y] at pattern p
    sres <- matrix(0, npar, npar) # this holds E[S(theta;R)S*(theta;R)|y] at a single site
    for (i in 1:nedge){
     for (j in 1:nedge){
    sres <- sres + qithet.grad(finaltheta, i, rateonly) %*% err[i,j,,] %*% t(qithet.grad(finaltheta, j, rateonly))
      }
    }
    
    ####### calculate third part E[S(theta;R)]E[S(theta;R)]* at pattern p
    estheta <- 0
    for (i in 1:nedge) {
     estheta <- estheta + qithet.grad(finaltheta, i, rateonly) %*% er[i,]
      }
    est <- estheta %*% t(estheta)
 

fi <- fi + state.cunt[pat, nspec+1] * (-eit + sres + est) 
 }#observed part

inv.fisherI <- solve(fi, diag(x = 1, npar, npar))
sqrt(diag(inv.fisherI))

return(list("FisherI" = fi, "sd" = sqrt(diag(inv.fisherI))) ) # the standard deviation of finaltheta

}#end of function fisher


####################################################################         
### write down the closed form of first derivative of q(theta)*, and evaluate at finaltheta
####################################################################         
qithet.grad <- function(x, index, rateonly){
#index controls which branch t1,...t7 we are considering 
 m <- length(x) - 6 * rateonly # length of parameter vector
 ss <- I(m==7)*2 + I(m!=7)*3 # number of states, 2 or 3
 res <- matrix(0, m, ss^2)
 
 if (m == 7){
 #1df case 
  bt <- x[index]*I(index > 1) + I(index == 1) 
 #qitheta <- qitheta <- c(-x[1]*bt, log(x[1]*bt), log((1-x[1])*bt), (x[1]-1)*bt)
 # row 1: dc
 res[1,] <- c(-bt, 1/x[1], 1/(x[1]-1), bt)
 # if index > 1, row (index): dti
 if (index > 1) res[index,] <- c(-x[1], 1/bt, 1/bt, x[1]-1)
 
 }else if (m == 9){
 #3df case 
  bt <- x[index+2]*I(index > 1) + I(index == 1) 
 #qitheta <- c(-bt*(x[1]*x[2]+x[1]*x[3]), log(x[1]*x[2]*bt), log(x[1]*x[3]*bt), 
 #                     log(x[1]*(1-x[2]-x[3])*bt), -(x[1]*(1-x[2]-x[3])+x[3])*bt, log(x[3]*bt), 
 #                     log(x[1]*(1-x[2]-x[3])*bt), log(x[2]*bt),  -(x[1]*(1-x[2]-x[3])+x[2])*bt)
 
 # row 1: da
 res[1,] <- c(-bt*(x[2]+x[3]), 1/x[1], 1/x[1], 1/x[1], -bt*(1-x[2]-x[3]), 0, 1/x[1], 0, -bt*(1-x[2]-x[3]))
 # row 2: dpiN
 res[2,] <- c(-bt*x[1], 1/x[2], 0, -1/(1-x[2]-x[3]), bt*x[1], 0, -1/(1-x[2]-x[3]), 1/x[2], bt*(x[1]-1))
 # row 3: dpiB
 res[3,] <- c(-bt*x[1], 0, 1/x[3], -1/(1-x[2]-x[3]), bt*(x[1]-1), 1/x[3], -1/(1-x[2]-x[3]), 0, bt*x[1])
 # if index > 1, row (index+2): dti
 if (index > 1) res[(index+2),] <- c(-(x[1]*x[2]+x[1]*x[3]), 1/bt, 1/bt, 1/bt, -(x[1]*(1-x[2]-x[3])+x[3]), 1/bt, 1/bt, 1/bt, -(x[1]*(1-x[2]-x[3])+x[2]))
 
 }else if (m == 10){
 #4df case
  bt <- x[index+3]*I(index > 1) + I(index == 1) 
 #qitheta <- c(-bt*(x[1]*x[3]+x[2]*x[4]), log(x[1]*x[3]*bt), log(x[2]*x[4]*bt), 
 #                     log(x[1]*(1-x[3]-x[4])*bt), -(x[1]*(1-x[3]-x[4])+x[4])*bt, log(x[4]*bt), 
 #                     log(x[2]*(1-x[3]-x[4])*bt), log(x[3]*bt),  -(x[2]*(1-x[3]-x[4])+x[3])*bt)
 
 # row 1: da
 res[1,] <- c(-bt*x[3], 1/x[1], 0, 1/x[1], -bt*(1-x[3]-x[4]), 0, 0, 0, 0)
 # row 2: db
 res[2,] <- c(-bt*x[4], 0, 1/x[2], 0, 0, 0, 1/x[2], 0, -bt*(1-x[3]-x[4]))
 # row 3: dpin
 res[3,] <- c(-bt*x[1], 1/x[3], 0, -1/(1-x[3]-x[4]), bt*x[1], 0, -1/(1-x[3]-x[4]), 1/x[3], bt*x[2])
 # row 4: dpib
 res[4,] <- c(-bt*x[2], 0, 1/x[4], -1/(1-x[3]-x[4]), bt*(x[1]-1), 1/x[4], -1/(1-x[3]-x[4]), 0, bt*x[2])
 # if index > 1, row (index+3): dti
 if (index > 1) res[(index+3),] <- c(-(x[1]*x[3]+x[2]*x[4]), 1/bt, 1/bt, 1/bt, -(x[1]*(1-x[3]-x[4])+x[4]), 1/bt, 1/bt, 1/bt, -(x[2]*(1-x[3]-x[4])+x[3]) )
 
 }else if (m == 3){
 #3df case with rateonly == TRUE 
  bt <- x[index+2]*I(index > 1) + I(index == 1) 
 #qitheta <- c(-bt*(x[1]*x[2]+x[1]*x[3]), log(x[1]*x[2]*bt), log(x[1]*x[3]*bt), 
 #                     log(x[1]*(1-x[2]-x[3])*bt), -(x[1]*(1-x[2]-x[3])+x[3])*bt, log(x[3]*bt), 
 #                     log(x[1]*(1-x[2]-x[3])*bt), log(x[2]*bt),  -(x[1]*(1-x[2]-x[3])+x[2])*bt)
 
 # row 1: da
 res[1,] <- c(-bt*(x[2]+x[3]), 1/x[1], 1/x[1], 1/x[1], -bt*(1-x[2]-x[3]), 0, 1/x[1], 0, -bt*(1-x[2]-x[3]))
 # row 2: dpiN
 res[2,] <- c(-bt*x[1], 1/x[2], 0, -1/(1-x[2]-x[3]), bt*x[1], 0, -1/(1-x[2]-x[3]), 1/x[2], bt*(x[1]-1))
 # row 3: dpiB
 res[3,] <- c(-bt*x[1], 0, 1/x[3], -1/(1-x[2]-x[3]), bt*(x[1]-1), 1/x[3], -1/(1-x[2]-x[3]), 0, bt*x[1])
 
 }else if (m == 4){
 #4df case with rateonly == TRUE
  bt <- x[index+3]*I(index > 1) + I(index == 1) 
 #qitheta <- c(-bt*(x[1]*x[3]+x[2]*x[4]), log(x[1]*x[3]*bt), log(x[2]*x[4]*bt), 
 #                     log(x[1]*(1-x[3]-x[4])*bt), -(x[1]*(1-x[3]-x[4])+x[4])*bt, log(x[4]*bt), 
 #                     log(x[2]*(1-x[3]-x[4])*bt), log(x[3]*bt),  -(x[2]*(1-x[3]-x[4])+x[3])*bt)
 
 # row 1: da
 res[1,] <- c(-bt*x[3], 1/x[1], 0, 1/x[1], -bt*(1-x[3]-x[4]), 0, 0, 0, 0)
 # row 2: db
 res[2,] <- c(-bt*x[4], 0, 1/x[2], 0, 0, 0, 1/x[2], 0, -bt*(1-x[3]-x[4]))
 # row 3: dpin
 res[3,] <- c(-bt*x[1], 1/x[3], 0, -1/(1-x[3]-x[4]), bt*x[1], 0, -1/(1-x[3]-x[4]), 1/x[3], bt*x[2])
 # row 4: dpib
 res[4,] <- c(-bt*x[2], 0, 1/x[4], -1/(1-x[3]-x[4]), bt*(x[1]-1), 1/x[4], -1/(1-x[3]-x[4]), 0, bt*x[2])
 
 }
 
 return(res)
} 

qithetaER <- function(x, finaltree, er, expo=FALSE){

allres <- 0

for ( i in 1:dim(finaltree$edge)[1] ){
 
 bti <- finaltree$edge.length[i] 
 ERi <- er[i,]
 
 if (length(x) %in% c(1, 7)){ 
 ## 1-df case
         if (length(x) == 7) bti <- x[i]*I(i!=1) + I(i==1) 
         qitheta <- c(-x[1]*bti, log(x[1]*bti), log((1-x[1])*bti), (x[1]-1)*bti)
         res <- sum(qitheta * ERi) 
         allres <- allres + res

 }else if (length(x) %in% c(3, 9)){ 
 ## 3-df case          
         if (length(x) == 9) bti <- x[i+2]*I(i!=1) + I(i==1) 
         qitheta <- c(-bti*(x[1]*x[2]+x[1]*x[3]), log(x[1]*x[2]*bti), log(x[1]*x[3]*bti), 
                      log(x[1]*(1-x[2]-x[3])*bti), -(x[1]*(1-x[2]-x[3])+x[3])*bti, log(x[3]*bti), 
                      log(x[1]*(1-x[2]-x[3])*bti), log(x[2]*bti),  -(x[1]*(1-x[2]-x[3])+x[2])*bti)
         res <- sum(qitheta * ERi) 
         allres <- allres + res
         
 }else if (length(x) %in% c(4, 10)){
 ## 4-df case
         if (length(x) == 10) bti <- x[i+3]*I(i!=1) + I(i==1) 
         qitheta <- c(-bti*(x[1]*x[3]+x[2]*x[4]), log(x[1]*x[3]*bti), log(x[2]*x[4]*bti), 
                      log(x[1]*(1-x[3]-x[4])*bti), -(x[1]*(1-x[3]-x[4])+x[4])*bti, log(x[4]*bti), 
                      log(x[2]*(1-x[3]-x[4])*bti), log(x[3]*bti),  -(x[2]*(1-x[3]-x[4])+x[3])*bti)
         res <- sum(qitheta * ERi) 
         allres <- allres + res
 }

}# for i : sum over all branches
 if (expo) allres <- exp(allres)  
 return(allres)
}#return a scalar function of x

pred_obs_plot <- function(finaltheta, finaltree, Qdf, obscount, incomplete=TRUE, plotflag = 1, label = TRUE){

finaltree$edge.length <- c(1, finaltheta[-c(1:Qdf)])
if (Qdf == 3) {
 finalQ <- Q3df(finaltheta)
 }else if (Qdf == 4){
 finalQ <- Q4df(finaltheta)
 }

nspec <- dim(obscount)[2] - 1 
nsite <- sum(obscount[,(nspec + 1)])

pred.cunt <- pat.l <- pat.likelihood(finaltree, finaltheta, Qdf)

if (incomplete){
 unobs <- grep("3", apply(pat.l[,1:nspec], 1, paste, collapse=""), invert=TRUE)
 L0 <- sum(pat.l[unobs, nspec+1])
 nsite <- round(nsite / (1-L0))
 pred.cunt <- pat.l <- pat.l[setdiff(1:3^nspec, unobs), ]
}
   
pred.cunt[,(nspec+1)] <- round(nsite * pat.l[,(nspec+1)])
pred.cunt <- pred.cunt[pred.cunt[,(nspec+1)]>0,]


obspat <- apply(obscount[,1:nspec], 1, paste, collapse="")
predpat <- apply(pred.cunt[,1:nspec], 1, paste, collapse="")

allpat <- intersect(obspat, predpat) #only plot for nonzero patterns in both pred and observed

obscount <- obscount[obspat %in% allpat, ]
pred.cunt <- pred.cunt[predpat %in% allpat, ]
obspat <- apply(obscount[,1:nspec], 1, paste, collapse="")
predpat <- apply(pred.cunt[,1:nspec], 1, paste, collapse="")

obscunt <- predcunt <- rep(0, length(allpat))
obscunt[match(obspat, allpat)] <- obscount[,(nspec+1)]
predcunt[match(predpat, allpat)] <- pred.cunt[,(nspec+1)]

x <- log(obscunt)
y <- log(predcunt)
low <- min(x, y)
hig <- max(x, y)

library(calibrate)

if (plotflag == 1){
plot(x, y, cex=0.5, xlim=c(low, hig), ylim=c(low, hig), xlab="log observed counts", ylab="log predicted counts")
abline(0,1)
if (label) textxy(x, y, labs=allpat)
}
return(data.frame(allpat, obscunt, predcunt))

}

##########################
## given a series of candidate start.theta, choose a starting point that gives the best log likelihood after one iteration
##########################
choose.start <- function(fit.tree, cand.theta, patcount, Qdf, incomplete = TRUE, rateonly = FALSE){
 
 if (dim(cand.theta)[2] !=  dim(fit.tree$edge)[1] + Qdf -1) stop("parameter lengths do not match!\n theta: ", dim(cand.theta)[2], "\n", "Qdf: ", Qdf, "\n")
 
 clogl <- rep(0, dim(cand.theta)[1]) #record cond.logl for each candidate cand.theta
 theta <- cand.theta
 
 for (i in 1:dim(cand.theta)[1]){
   if (Qdf == 3){
    EMres <- EM3df(start.tree = fit.tree, cand.theta[i,], patcount, maxiter = 1,  stop.threshold = 0.0001, incomplete = incomplete, rateonly=rateonly)
    if (incomplete) {clogl[i] <- EMres$cond.logl} else{clogl[i] <- EMres$logl}
    theta[i, ] <- EMres$theta
    
   }else if (Qdf == 4){
    EMres <- EM4df(start.tree = fit.tree, cand.theta[i,], patcount, maxiter = 1,  stop.threshold = 0.0001, incomplete = incomplete, rateonly=rateonly)
    if (incomplete) {clogl[i] <- EMres$cond.logl} else{clogl[i] <- EMres$logl}
    theta[i, ] <- EMres$theta
    }
  
 }#for i

 res <- cbind(clogl, theta, 1:dim(cand.theta)[1])
 res <- res[order(res[,1], decreasing = TRUE), ] #sort cand.theta by decreasing cond.logl, record current theta and an index to identify original cand.theta
 
 return(res)
 
}


bootstrapCI <- function(EMresult, finaltree, obsdata, maxiter = 20, stop.threshold = 0.01, incomplete = TRUE, rateonly=TRUE, nsample=100){
 bootresult <- NULL
 npar <- length(EMresult$theta)
 ocol <- dim(obsdata)[2] 
 resample.mat <- obsdata
 resample.mat[ ,ocol] <-0
 
 for (boot in 1:nsample){
  ## resample original data
  resample.count <- table(sample(1:dim(obsdata)[1], size=sum(obsdata[,ocol]), replace=TRUE, prob=obsdata[,ocol]/sum(obsdata[,ocol])))
  resample.mat[as.numeric(names(resample.count)),ocol] <- as.numeric(resample.count)
  
  ## randomize initiation values
   if (rateonly){
    stheta <- EMresult$theta + c(rnorm(npar-6, sd=EMresult$theta[1:(npar-6)]/10), rep(0, 6))
   }else{
    stheta <- EMresult$theta + rnorm(npar, sd=EMresult$theta/10)
   }
  
  ## 
  if (npar == 10){#4-df case
  EMrs4 <- EM4df(start.tree = finaltree, start.theta = stheta, obsdata = resample.mat, maxiter = maxiter, stop.threshold = stop.threshold, incomplete = incomplete, rateonly = rateonly)
  bootresult <- rbind(bootresult, c(EMrs4$theta, EMrs4$logl, EMrs4$cond.logl, EMrs4$scale.factor, EMrs4$iteration))
  } else if (npar == 9){#3-df case
  EMrs3 <- EM3df(start.tree = finaltree, start.theta = stheta, obsdata = resample.mat, maxiter = maxiter, stop.threshold = stop.threshold, incomplete = incomplete, rateonly = rateonly)
  bootresult <- rbind(bootresult, c(EMrs3$theta, EMrs3$logl, EMrs3$cond.logl, EMrs3$scale.factor, EMrs3$iteration))
  }else{
  stop(paste("cannot determine Qdf from number of parameters: ", npar, "\n"))
  }
  }##boot
 
 return(list("sd" = apply(bootresult[,1:npar], 2, sd), "bootresult" = bootresult))
}


